<?php
/** @var ContainerBuilder $container */

use SunMedia\Core\Infrastructure\Delivery\Monolog\Prod;
use Symfony\Component\DependencyInjection\ContainerBuilder;

try {
    new Prod($container);
} catch (JsonException $e) {
    throw new RuntimeException('Error to load monolog prod', 500);
}