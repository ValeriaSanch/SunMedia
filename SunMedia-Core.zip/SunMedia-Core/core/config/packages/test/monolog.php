<?php
/** @var ContainerBuilder $container */

use SunMedia\Core\Infrastructure\Delivery\Monolog\Dev;
use Symfony\Component\DependencyInjection\ContainerBuilder;

try {
    new Dev($container);
} catch (JsonException $e) {
    throw new RuntimeException('Error to load monolog test', 500);
}