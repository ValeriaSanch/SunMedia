<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetRequest;

use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Core\Domain\Model\User\UserTokenResetPassword;
use SunMedia\Core\Domain\Service\Mail\MailService;
use SunMedia\Core\Infrastructure\Delivery\Mailer\MailerService;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\User\UserTokenResetPasswordGenerator;
use Symfony\Component\Mailer\Exception\TransportExceptionInterface;

class UserPasswordResetRequestService
{
    /** @var MailerService */
    private $mailService;

    /** @var UserRepository */
    private $userRepository;

    /** @var UserTokenResetPasswordGenerator */
    private $userTokenResetPasswordGenerator;

    /** @var int */
    private $jwtTokenResetPasswordTtl;

    public function __construct(
        MailService $mailService,
        UserRepository $userRepository,
        UserTokenResetPasswordGenerator $userTokenResetPasswordGenerator,
        int $jwtTokenResetPasswordTtl
    ) {
        $this->mailService = $mailService;
        $this->userRepository = $userRepository;
        $this->userTokenResetPasswordGenerator = $userTokenResetPasswordGenerator;
        $this->jwtTokenResetPasswordTtl = $jwtTokenResetPasswordTtl;
    }

    /**
     * @throws DomainException
     * @throws TransportExceptionInterface
     */
    public function execute(User $user): void
    {
        $userTokenResetPassword = new UserTokenResetPassword($this->userTokenResetPasswordGenerator->create(
            $user->id(),
            $this->jwtTokenResetPasswordTtl
        ));

        $user->updateTokenResetPassword($user->id(), $userTokenResetPassword);

        $this->mailService->sendUserPasswordReset($user);
        $this->userRepository->save($user);
    }
}
