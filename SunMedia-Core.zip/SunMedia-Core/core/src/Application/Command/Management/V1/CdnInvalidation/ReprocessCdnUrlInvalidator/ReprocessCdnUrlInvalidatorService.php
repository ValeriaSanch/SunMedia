<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\CdnInvalidation\ReprocessCdnUrlInvalidator;

use Exception;
use Psr\Log\LoggerInterface;
use SunMedia\Core\Domain\Model\CdnInvalidation\CdnInvalidation;
use SunMedia\Core\Domain\Model\CdnInvalidation\CdnInvalidationRepository;
use SunMedia\Core\Domain\Model\CdnInvalidation\HttpCdnInvalidationRepository;
use SunMedia\Core\Domain\Service\Mail\MailService;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Criteria\Expr\ExpressionBuilder;
use SunMedia\Shared\Domain\Model\User\UserId;
use Symfony\Component\Mailer\Exception\TransportExceptionInterface;

class ReprocessCdnUrlInvalidatorService
{
    private const MAX_TRIES = 3;

    /** @var LoggerInterface */
    private $logger;

    /** @var MailService */
    private $mailService;

    /** @var HttpCdnInvalidationRepository */
    private $httpCdnInvalidationRepository;

    /** @var CdnInvalidationRepository */
    private $cdnInvalidationRepository;

    public function __construct(
        LoggerInterface $logger,
        MailService $mailService,
        HttpCdnInvalidationRepository $httpCdnInvalidationRepository,
        CdnInvalidationRepository $cdnInvalidationRepository
    ) {
        $this->logger = $logger;
        $this->mailService = $mailService;
        $this->httpCdnInvalidationRepository = $httpCdnInvalidationRepository;
        $this->cdnInvalidationRepository = $cdnInvalidationRepository;
    }

    /**
     * @throws TransportExceptionInterface
     * @throws Exception
     */
    public function execute(
        string $authorId,
        string $context,
        string $status
    ): void {
        $expression = new ExpressionBuilder();
        $comparison = $expression->andX(
            $expression->eq('status', $status),
            $expression->eq('context', $context)
        );

        $items = $this->cdnInvalidationRepository->byCriteria(new Criteria($comparison));
        /** @var CdnInvalidation $item */
        foreach ($items as $item) {
            $newStatus = 'SUCCESS';
            list($isSent, $error) = $this->sendInvalidation($item->urls(), true, $context);
            if (!$isSent) {
                $newStatus = 'FAIL';
                $this->mailService->sendInvalidationErrorEmail($item->urls(), $error);
            }
            $item->updated(new UserId($authorId), $newStatus, $error);

            $this->cdnInvalidationRepository->save($item);
        }
    }

    private function sendInvalidation(array $urls, bool $ban, string $context): array
    {
        $cont = 0;
        $isSent = false;
        $error = '';
        do {
            try {
                $this->httpCdnInvalidationRepository->invalidate($urls, $ban);
                $isSent = true;
                $this->logger->info('Invalidation successful');
            } catch (Exception $exception) {
                $error = sprintf('[%s]Fail in Invalidation: %s', $context, $exception->getMessage());
                $this->logger->alert($error);
            }
            ++$cont;
        } while (false === $isSent && $cont < self::MAX_TRIES);

        return [$isSent, $error];
    }
}
