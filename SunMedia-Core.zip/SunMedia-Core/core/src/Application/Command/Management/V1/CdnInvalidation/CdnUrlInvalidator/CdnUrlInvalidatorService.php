<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\CdnInvalidation\CdnUrlInvalidator;

use Exception;
use Psr\Log\LoggerInterface;
use SunMedia\Core\Domain\Model\CdnInvalidation\CdnInvalidation;
use SunMedia\Core\Domain\Model\CdnInvalidation\CdnInvalidationRepository;
use SunMedia\Core\Domain\Model\CdnInvalidation\HttpCdnInvalidationRepository;
use SunMedia\Core\Domain\Service\Mail\MailService;
use SunMedia\Shared\Domain\Model\User\UserId;
use Symfony\Component\Mailer\Exception\TransportExceptionInterface;

class CdnUrlInvalidatorService
{
    private const MAX_TRIES = 3;

    /** @var LoggerInterface */
    private $logger;

    /** @var MailService */
    private $mailService;

    /** @var HttpCdnInvalidationRepository */
    private $httpCdnInvalidationRepository;

    /** @var CdnInvalidationRepository */
    private $cdnInvalidationRepository;

    public function __construct(
        LoggerInterface $logger,
        MailService $mailService,
        HttpCdnInvalidationRepository $httpCdnInvalidationRepository,
        CdnInvalidationRepository $cdnInvalidationRepository
    ) {
        $this->logger = $logger;
        $this->mailService = $mailService;
        $this->httpCdnInvalidationRepository = $httpCdnInvalidationRepository;
        $this->cdnInvalidationRepository = $cdnInvalidationRepository;
    }

    /**
     * @throws TransportExceptionInterface
     * @throws Exception
     */
    public function execute(
        string $authorId,
        string $id,
        string $context,
        array $urls,
        bool $ban
    ): void {
        $status = 'SUCCESS';
        list($isSent, $error) = $this->sendInvalidation($urls, $ban, $context);
        if (!$isSent) {
            $status = 'FAIL';
            $this->mailService->sendInvalidationErrorEmail($urls, $error);
            //throw new Exception($error, 400);
        }
        $cdnInvalidation = CdnInvalidation::created(new UserId($authorId), $id, $context, $status, $urls, $error);

        $this->cdnInvalidationRepository->save($cdnInvalidation);
    }

    private function sendInvalidation(array $urls, bool $ban, string $context): array
    {
        $cont = 0;
        $isSent = false;
        $error = '';
        do {
            try {
                $this->httpCdnInvalidationRepository->invalidate($urls, $ban);
                $isSent = true;
                $this->logger->info('Invalidation successful');
            } catch (Exception $exception) {
                $error = sprintf('[%s]Fail in Invalidation: %s', $context, $exception->getMessage());
                $this->logger->alert($error);
            }
            ++$cont;
        } while (false === $isSent && $cont < self::MAX_TRIES);

        return [$isSent, $error];
    }
}
