<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Salesforce\SalesforceUserUpdater;

use JsonException;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;

class SalesforceUserUpdaterCommandHandler
{
    /** @var SalesforceUserUpdaterService */
    private $userSalesforceUpdaterService;

    /** @var SalesforceUserUpdaterValidation */
    private $userSalesforceUpdaterValidation;

    public function __construct(
        SalesforceUserUpdaterService $service,
        SalesforceUserUpdaterValidation $userSalesforceUpdaterValidation
    ) {
        $this->userSalesforceUpdaterService = $service;
        $this->userSalesforceUpdaterValidation = $userSalesforceUpdaterValidation;
    }

    /**
     * @throws DomainException
     * @throws JsonException
     * @throws UserNotFound
     */
    public function __invoke(SalesforceUserUpdaterCommand $userSalesforceUpdaterCommand): void
    {
        $this->userSalesforceUpdaterService->execute(
            ...$this->userSalesforceUpdaterValidation->validate($userSalesforceUpdaterCommand)
        );
    }
}
