<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserProfileUpdater;

use SunMedia\Core\Domain\Model\User\Exception\InvalidUserNameLength;
use SunMedia\Core\Domain\Model\User\Exception\UserEmailAlreadyExists;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserName;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\Email\Email;
use SunMedia\Shared\Domain\Model\User\UserId;

class UserProfileUpdaterValidation
{
    /** @var UserValidation */
    private $userValidation;

    private $userRepository;

    public function __construct(UserValidation $userValidation, UserRepository $userRepository)
    {
        $this->userValidation = $userValidation;
        $this->userRepository = $userRepository;
    }

    /**
     * @throws DomainException
     * @throws EmailNotValid
     * @throws EmptyValue
     * @throws InvalidUserNameLength
     * @throws UserEmailAlreadyExists
     * @throws UserNotFound
     */
    public function validate(UserProfileUpdaterCommand $userCreatorCommand): array
    {
        $authorId = new UserId($userCreatorCommand->authorId());
        $author = $this->userRepository->byId($authorId, new Criteria());

        if (null === $author) {
            throw new UserNotFound($authorId);
        }

        $name = new UserName($userCreatorCommand->name());
        $email = new Email($userCreatorCommand->email());

        $this->userValidation->checkEmailNotExistsForUser($email, $authorId);

        return [$author, $name, $email];
    }
}
