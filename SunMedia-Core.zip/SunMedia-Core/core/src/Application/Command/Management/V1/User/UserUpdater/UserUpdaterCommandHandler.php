<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserUpdater;

use SunMedia\Core\Domain\Model\Advertiser\Exception\AdvertiserNotFound;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNotFound;
use SunMedia\Core\Domain\Model\Publisher\Exception\PublisherNotFound;
use SunMedia\Core\Domain\Model\SalesforceUser\Exception\SalesforceUserIdNotEmpty;
use SunMedia\Core\Domain\Model\SalesforceUser\Exception\SalesforceUserNotFound;
use SunMedia\Core\Domain\Model\User\Exception\AdvertiserNotBelongsToClient;
use SunMedia\Core\Domain\Model\User\Exception\InvalidUserNameLength;
use SunMedia\Core\Domain\Model\User\Exception\MandatoryParameterNotFound;
use SunMedia\Core\Domain\Model\User\Exception\PublisherNotBelongsToClient;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\Role\Exception\InvalidRole;

class UserUpdaterCommandHandler
{
    /** @var UserUpdaterValidation */
    private $userUpdaterValidation;

    /** @var UserUpdaterService */
    private $userUpdaterService;

    public function __construct(UserUpdaterValidation $userUpdaterValidation, UserUpdaterService $userUpdaterService)
    {
        $this->userUpdaterValidation = $userUpdaterValidation;
        $this->userUpdaterService = $userUpdaterService;
    }

    /**
     * @throws AdvertiserNotBelongsToClient
     * @throws AdvertiserNotFound
     * @throws ClientNotFound
     * @throws DomainException
     * @throws EmailNotValid
     * @throws EmptyValue
     * @throws InvalidRole
     * @throws InvalidUserNameLength
     * @throws MandatoryParameterNotFound
     * @throws PublisherNotBelongsToClient
     * @throws PublisherNotFound
     * @throws UserNotFound
     * @throws SalesforceUserIdNotEmpty
     * @throws SalesforceUserNotFound
     */
    public function __invoke(UserUpdaterCommand $updaterCommand)
    {
        $this->userUpdaterService->execute(...$this->userUpdaterValidation->validate($updaterCommand));
    }
}
