<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedRemover;

use SunMedia\Core\Domain\Model\Feed\Exception\FeedInUse;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedNotFound;
use SunMedia\Core\Domain\Model\Feed\FeedId;
use SunMedia\Core\Domain\Model\Feed\FeedValidation;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\User\UserId;

class FeedRemoverValidation
{
    /** @var FeedValidation */
    private $feedValidation;

    /** @var UserRepository */
    private $userRepository;

    public function __construct(FeedValidation $feedValidation, UserRepository $userRepository)
    {
        $this->feedValidation = $feedValidation;
        $this->userRepository = $userRepository;
    }

    /**
     * @throws FeedNotFound
     * @throws UserNotFound
     * @throws FeedInUse
     * @throws DomainException
     */
    public function validate(FeedRemoverCommand $userRemoverCommand): array
    {
        $authorId = new UserId($userRemoverCommand->authorId());
        $author = $this->userRepository->byId($authorId, new Criteria());

        if (null === $author) {
            throw new UserNotFound($authorId);
        }

        $feedId = new FeedId($userRemoverCommand->feedId());
        $feed = $this->feedValidation->ensureFeedIdExists($feedId);

        $this->feedValidation->checkIsUsed($feed);

        return [$author, $feed];
    }
}
