<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedCreator;

use SunMedia\Core\Domain\Model\Client\Exception\ClientNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileEmpty;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidCallbackUrl;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidFileType;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidHourInterval;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmptyValue;

class FeedCreatorCommandHandler
{
    /** @var FeedCreatorValidation */
    private $feedCreatorValidation;

    /** @var FeedCreatorService */
    private $feedCreatorService;

    public function __construct(FeedCreatorValidation $feedCreatorValidation, FeedCreatorService $feedCreatorService)
    {
        $this->feedCreatorValidation = $feedCreatorValidation;
        $this->feedCreatorService = $feedCreatorService;
    }

    /**
     * @throws ClientNotFound
     * @throws DomainException
     * @throws EmptyValue
     * @throws FeedFileEmpty
     * @throws FeedFileNotFound
     * @throws InvalidCallbackUrl
     * @throws InvalidFileType
     * @throws InvalidHourInterval
     * @throws UserNotFound
     */
    public function __invoke(FeedCreatorCommand $feedCreatorCommand)
    {
        $this->feedCreatorService->execute(...$this->feedCreatorValidation->validate($feedCreatorCommand));
    }
}
