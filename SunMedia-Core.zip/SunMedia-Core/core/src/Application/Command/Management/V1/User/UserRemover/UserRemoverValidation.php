<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserRemover;

use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\User\UserId;

class UserRemoverValidation
{
    /** @var UserValidation */
    private $userValidation;

    /** @var UserRepository */
    private $userRepository;

    public function __construct(UserValidation $userValidation, UserRepository $userRepository)
    {
        $this->userValidation = $userValidation;
        $this->userRepository = $userRepository;
    }

    /**
     * @throws DomainException
     * @throws UserNotFound
     */
    public function validate(UserRemoverCommand $userRemoverCommand): array
    {
        $authorId = new UserId($userRemoverCommand->authorId());
        $author = $this->userRepository->byId($authorId, new Criteria());

        if (null === $author) {
            throw new UserNotFound($authorId);
        }

        $userId = new UserId($userRemoverCommand->id());
        $user = $this->userValidation->ensureUserExists($author, $userId);

        return [$author, $user];
    }
}
