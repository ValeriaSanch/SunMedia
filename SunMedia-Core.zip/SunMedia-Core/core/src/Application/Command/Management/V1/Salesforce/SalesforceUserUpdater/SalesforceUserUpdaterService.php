<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Salesforce\SalesforceUserUpdater;

use JsonException;
use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUser;
use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUserRepository;
use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Service\Salesforce\User\GetSalesforceUsers;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Exception\DomainException;

class SalesforceUserUpdaterService
{
    /** @var GetSalesforceUsers */
    private $getSalesforceUsersService;

    /** @var SalesforceUserRepository */
    private $userSalesforceRepository;

    public function __construct(
        GetSalesforceUsers $getSalesforceUsersService,
        SalesforceUserRepository $userSalesforceRepository
    ) {
        $this->getSalesforceUsersService = $getSalesforceUsersService;
        $this->userSalesforceRepository = $userSalesforceRepository;
    }

    /**
     * @throws DomainException
     * @throws JsonException
     */
    public function execute(User $author): void
    {
        $userSalesForces = $this->getSalesforceUsersService->execute();

        /** @var SalesforceUser $userSalesForce */
        foreach ($userSalesForces as $userSalesForce) {
            $existingUser = $this->userSalesforceRepository->byId($userSalesForce->id(), new Criteria());
            if (false === is_null($existingUser)) {
                $existingUser->updateSalesForceUser($author, $existingUser);
                $userSalesForce = $existingUser;
            } else {
                $userSalesForce->createSalesForceUser($author, $userSalesForce);
            }

            $this->userSalesforceRepository->save($userSalesForce);
        }
    }
}
