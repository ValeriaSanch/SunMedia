<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetNotLogged;

use SunMedia\Core\Domain\Model\User\Exception\UserTokenResetPasswordNotExists;
use SunMedia\Shared\Domain\Model\User\Exception\InvalidUserPassword;
use SunMedia\Shared\Domain\Model\User\Exception\PasswordMismatch;

class NotLoggedUserPasswordResetCommandHandler
{
    /** @var NotLoggedUserPasswordResetValidation */
    private $validation;

    /** @var NotLoggedUserPasswordResetService */
    private $service;

    public function __construct(
        NotLoggedUserPasswordResetValidation $validation,
        NotLoggedUserPasswordResetService $service
    ) {
        $this->validation = $validation;
        $this->service = $service;
    }

    /**
     * @throws InvalidUserPassword
     * @throws PasswordMismatch
     * @throws UserTokenResetPasswordNotExists
     */
    public function __invoke(NotLoggedUserPasswordResetCommand $command)
    {
        $this->service->execute(...$this->validation->validate($command));
    }
}
