<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserCreator;

use SunMedia\Core\Domain\Model\Advertiser\AdvertiserCollection;
use SunMedia\Core\Domain\Model\Client\ClientCollection;
use SunMedia\Core\Domain\Model\Publisher\PublisherCollection;
use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUserCollection;
use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Model\User\UserEnabled;
use SunMedia\Core\Domain\Model\User\UserName;
use SunMedia\Core\Domain\Model\User\UserPassword;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Context\Context;
use SunMedia\Shared\Domain\Model\ContextRoleSettings\ContextRoleSettings;
use SunMedia\Shared\Domain\Model\Email\Email;
use SunMedia\Shared\Domain\Model\Role\Role as UserRole;
use SunMedia\Shared\Domain\Model\User\ContextRole;
use SunMedia\Shared\Domain\Model\User\ContextRoleCollection;
use SunMedia\Shared\Domain\Model\User\UserId;

class UserCreatorService
{
    /** @var UserRepository */
    private $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    /**
     * @throws DomainException
     */
    public function execute(
        User $loggedUser,
        UserId $id,
        UserName $name,
        Email $email,
        UserPassword $password,
        UserEnabled $enabled,
        ContextRoleCollection $contextRoleCollection,
        ClientCollection $clientCollection,
        AdvertiserCollection $advertiserCollection,
        SalesforceUserCollection $userSalesforceCollection,
        PublisherCollection $publisherCollection,
        UserRole $userRole,
        ?User $user
    ): void {
        if (null === $contextRoleCollection->get(Context::CORE)) {
            $contextRoleCollection->addContextRole(ContextRole::create(
                Context::core(),
                new UserRole(UserRole::ROLE_USER),
                new ContextRoleSettings([])
            ));
        }

        if ($user) {
            $saveUser = $user;
            $saveUser->updatePassword($user->id(), $password);
            $saveUser->updateUser($loggedUser, $name, $email, $contextRoleCollection, $userRole, $enabled);
        } else {
            $saveUser = $loggedUser->makeUser(
                $id,
                $name,
                $email,
                $password,
                $contextRoleCollection,
                $userRole,
                $enabled
            );
        }

        $saveUser->linkClients($loggedUser, $clientCollection);
        $saveUser->linkAdvertisers($loggedUser, $advertiserCollection);
        $saveUser->linkSalesforceUser($loggedUser, $userSalesforceCollection);
        $saveUser->linkPublishers($loggedUser, $publisherCollection);

        $this->userRepository->save($saveUser);
    }
}
