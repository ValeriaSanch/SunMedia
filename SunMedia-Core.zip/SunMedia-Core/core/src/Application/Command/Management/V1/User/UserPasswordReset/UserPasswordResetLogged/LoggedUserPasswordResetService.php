<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetLogged;

use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Model\User\UserPassword;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Shared\Domain\Exception\DomainException;

class LoggedUserPasswordResetService
{
    /** @var UserRepository */
    private $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    /**
     * @throws DomainException
     */
    public function execute(User $user, UserPassword $password): void
    {
        $user->updatePassword($user->id(), $password);

        $this->userRepository->save($user);
    }
}
