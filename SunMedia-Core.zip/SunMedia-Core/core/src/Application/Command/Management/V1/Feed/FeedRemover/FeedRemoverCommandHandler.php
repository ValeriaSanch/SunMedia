<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedRemover;

use SunMedia\Core\Domain\Model\Feed\Exception\FeedInUse;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedNotFound;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;

class FeedRemoverCommandHandler
{
    /** @var FeedRemoverValidation */
    private $feedRemoverValidation;

    /** @var FeedRemoverService */
    private $feedRemoverService;

    public function __construct(FeedRemoverValidation $feedRemoverValidation, FeedRemoverService $feedRemoverService)
    {
        $this->feedRemoverValidation = $feedRemoverValidation;
        $this->feedRemoverService = $feedRemoverService;
    }

    /**
     * @throws DomainException
     * @throws FeedInUse
     * @throws FeedNotFound
     * @throws UserNotFound
     */
    public function __invoke(FeedRemoverCommand $feedRemoverCommand)
    {
        $this->feedRemoverService->execute(...$this->feedRemoverValidation->validate($feedRemoverCommand));
    }
}
