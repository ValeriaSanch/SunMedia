<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\CdnInvalidation\ReprocessCdnUrlInvalidator;

use SunMedia\Shared\Domain\Bus\SyncCommand;

final class ReprocessCdnUrlInvalidatorCommand implements SyncCommand
{
    public const ACTION = 'REPROCESS_CDN_INVALID_URLS';

    /** @var string */
    private $authorId;

    /** @var string */
    private $context;

    /** @var string */
    private $status;

    public function __construct(
        string $authorId,
        string $context,
        string $status
    ) {
        $this->authorId = $authorId;
        $this->context = $context;
        $this->status = $status;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }

    public function context(): string
    {
        return $this->context;
    }

    public function status(): string
    {
        return $this->status;
    }
}
