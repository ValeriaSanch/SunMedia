<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedCreator;

use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileEmpty;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidCallbackUrl;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidFileType;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidHourInterval;
use SunMedia\Core\Domain\Model\Feed\FeedCallbackUrl;
use SunMedia\Core\Domain\Model\Feed\FeedDictionary;
use SunMedia\Core\Domain\Model\Feed\FeedHourInterval;
use SunMedia\Core\Domain\Model\Feed\FeedId;
use SunMedia\Core\Domain\Model\Feed\FeedName;
use SunMedia\Core\Domain\Model\Feed\FeedType;
use SunMedia\Core\Domain\Model\Feed\FeedUrl;
use SunMedia\Core\Domain\Model\Feed\FeedValidation;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\User\UserId;

class FeedCreatorValidation
{
    /** @var FeedValidation */
    private $feedValidation;

    /** @var UserValidation */
    private $userValidation;

    public function __construct(FeedValidation $feedValidation, UserValidation $userValidation)
    {
        $this->feedValidation = $feedValidation;
        $this->userValidation = $userValidation;
    }

    /**
     * @throws ClientNotFound
     * @throws DomainException
     * @throws EmptyValue
     * @throws FeedFileEmpty
     * @throws FeedFileNotFound
     * @throws InvalidCallbackUrl
     * @throws InvalidFileType
     * @throws InvalidHourInterval
     * @throws UserNotFound
     */
    public function validate(FeedCreatorCommand $feedCreatorCommand): array
    {
        $type = new FeedType($feedCreatorCommand->type());
        $hourInterval = new FeedHourInterval($feedCreatorCommand->hourInterval());
        $url = new FeedUrl($feedCreatorCommand->url());

        $user = $this->userValidation->checkAuthor(new UserId($feedCreatorCommand->authorId()));
        $this->validateClient($feedCreatorCommand->clientId());
        $clientId = new ClientId($feedCreatorCommand->clientId());
        $this->userValidation->checkClientExists($user, $clientId);

        $this->feedValidation->validateHourInterval($type, $hourInterval, $url);

        return [
            $user,
            new FeedId($feedCreatorCommand->id()),
            $clientId,
            new FeedName($feedCreatorCommand->name()),
            $type,
            $hourInterval,
            $url,
            new FeedCallbackUrl($feedCreatorCommand->callbackUrl()),
            new FeedDictionary($feedCreatorCommand->dictionary()),
        ];
    }

    /**
     * @throws EmptyValue
     */
    private function validateClient(string $clientId): void
    {
        if (!trim($clientId)) {
            throw new EmptyValue('clientId');
        }
    }
}
