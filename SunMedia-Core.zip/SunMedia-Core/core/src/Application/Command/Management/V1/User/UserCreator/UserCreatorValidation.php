<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserCreator;

use SunMedia\Core\Domain\Model\Advertiser\Exception\AdvertiserNotFound;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNotFound;
use SunMedia\Core\Domain\Model\Publisher\Exception\PublisherNotFound;
use SunMedia\Core\Domain\Model\SalesforceUser\Exception\SalesforceUserIdNotEmpty;
use SunMedia\Core\Domain\Model\SalesforceUser\Exception\SalesforceUserNotFound;
use SunMedia\Core\Domain\Model\User\Exception\AdvertiserNotBelongsToClient;
use SunMedia\Core\Domain\Model\User\Exception\InvalidUserContextRolesQuantity;
use SunMedia\Core\Domain\Model\User\Exception\InvalidUserNameLength;
use SunMedia\Core\Domain\Model\User\Exception\MandatoryParameterNotFound;
use SunMedia\Core\Domain\Model\User\Exception\PublisherNotBelongsToClient;
use SunMedia\Core\Domain\Model\User\Exception\UserEmailAlreadyExists;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Model\User\UserEnabled;
use SunMedia\Core\Domain\Model\User\UserName;
use SunMedia\Core\Domain\Model\User\UserPassword;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Core\Domain\Service\Validation\Context\AbstractValidator;
use SunMedia\Core\Domain\Service\Validation\Context\UserContextValidation;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\Context\Context;
use SunMedia\Shared\Domain\Model\Email\Email;
use SunMedia\Shared\Domain\Model\Role\Exception\InvalidRole;
use SunMedia\Shared\Domain\Model\Role\Role;
use SunMedia\Shared\Domain\Model\User\Exception\InvalidUserPassword;
use SunMedia\Shared\Domain\Model\User\PasswordEncoder;
use SunMedia\Shared\Domain\Model\User\UserId;

class UserCreatorValidation
{
    /** @var UserValidation */
    private $userValidation;

    /** @var PasswordEncoder */
    private $passwordEncoder;

    /** @var UserContextValidation */
    private $userContextValidation;

    public function __construct(
        UserValidation $userValidation,
        PasswordEncoder $passwordEncoder,
        UserContextValidation $userContextValidation
    ) {
        $this->userValidation = $userValidation;
        $this->passwordEncoder = $passwordEncoder;
        $this->userContextValidation = $userContextValidation;
    }

    /**
     * @throws AdvertiserNotBelongsToClient
     * @throws AdvertiserNotFound
     * @throws ClientNotFound
     * @throws DomainException
     * @throws EmailNotValid
     * @throws EmptyValue
     * @throws InvalidRole
     * @throws InvalidUserContextRolesQuantity
     * @throws InvalidUserNameLength
     * @throws InvalidUserPassword
     * @throws MandatoryParameterNotFound
     * @throws PublisherNotBelongsToClient
     * @throws PublisherNotFound
     * @throws UserEmailAlreadyExists
     * @throws UserNotFound
     * @throws SalesforceUserIdNotEmpty
     * @throws SalesforceUserNotFound
     */
    public function validate(UserCreatorCommand $userCreatorCommand): array
    {
        $author = $this->userValidation->checkAuthor(new UserId($userCreatorCommand->authorId()));

        $password = $userCreatorCommand->password();
        $this->userValidation->checkSafePassword($password);

        $id = new UserId($userCreatorCommand->id());
        $name = new UserName($userCreatorCommand->name());
        $email = new Email($userCreatorCommand->email());

        $password = new UserPassword($this->passwordEncoder->encode($password));
        $enabled = new UserEnabled($userCreatorCommand->enabled());

        $user = null;
        $contextRole = $userCreatorCommand->contextRoles();
        if (!$author->isAdmin(Context::core())) {
            $user = $this->validateContextRoleByEmail($email, $contextRole);
        }

        if (is_null($user)) {
            $this->userValidation->ensureEmailNotExists($email);
            $this->userValidation->ensureUserIdNotExists($id);
        }

        $this->userContextValidation->validateContextRoles($author, $contextRole);
        $roleUser = new Role($this->userContextValidation->roleUser());

        return [
            $author,
            $id,
            $name,
            $email,
            $password,
            $enabled,
            $this->userContextValidation->contextRoleCollection(),
            $this->userContextValidation->clientCollection(),
            $this->userContextValidation->advertiserCollection(),
            $this->userContextValidation->salesforceUserCollection(),
            $this->userContextValidation->publisherCollection(),
            $roleUser,
            $user,
        ];
    }

    private function validateContextRoleByEmail(Email $email, array &$contextRoles): ?User
    {
        $user = $this->userValidation->userEmailExists($email);

        if ($user) {
            $userContextRoles = [];
            foreach ($user->contextRoleCollection() as $contextRole) {
                $userContextRoles[] = [
                    AbstractValidator::COLUMN_CONTEXT => $contextRole->context()->value(),
                    AbstractValidator::COLUMN_ROLE => $contextRole->role()->value(),
                    AbstractValidator::COLUMN_SETTINGS => $contextRole->contextRoleSettings()->value(),
                ];
            }

            $auxUCR = array_column($userContextRoles, AbstractValidator::COLUMN_CONTEXT);
            $auxCR = array_column($contextRoles, AbstractValidator::COLUMN_CONTEXT);

            if (array_diff($auxCR, $auxUCR)) {
                foreach ($userContextRoles as $userContextRole) {
                    if (in_array($userContextRole[AbstractValidator::COLUMN_CONTEXT], $auxCR, true)) {
                        continue;
                    }
                    $contextRoles[] = $userContextRole;
                }
            } else {
                $user = null;
            }
        }

        return $user;
    }
}
