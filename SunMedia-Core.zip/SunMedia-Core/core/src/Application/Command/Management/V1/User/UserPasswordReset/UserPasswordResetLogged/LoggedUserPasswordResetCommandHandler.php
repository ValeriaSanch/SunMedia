<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetLogged;

use SunMedia\Core\Domain\Model\User\Exception\PasswordSame;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\User\Exception\InvalidUserPassword;
use SunMedia\Shared\Domain\Model\User\Exception\PasswordMismatch;

class LoggedUserPasswordResetCommandHandler
{
    /** @var LoggedUserPasswordResetValidation */
    private $validation;

    /** @var LoggedUserPasswordResetService */
    private $service;

    public function __construct(LoggedUserPasswordResetValidation $validation, LoggedUserPasswordResetService $service)
    {
        $this->validation = $validation;
        $this->service = $service;
    }

    /**
     * @throws DomainException
     * @throws InvalidUserPassword
     * @throws PasswordMismatch
     * @throws PasswordSame
     * @throws UserNotFound
     */
    public function __invoke(LoggedUserPasswordResetCommand $command)
    {
        $this->service->execute(...$this->validation->validate($command));
    }
}
