<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\CurrencyRate\CurrencyRateCreator;

use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRate;
use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRateRepository;

class CurrencyRateCreatorService
{
    /** @var CurrencyRateRepository */
    private $currencyRateRepository;

    public function __construct(CurrencyRateRepository $currencyRateRepository)
    {
        $this->currencyRateRepository = $currencyRateRepository;
    }

    public function execute(CurrencyRate $currencyRate): void
    {
        $this->currencyRateRepository->save($currencyRate);
    }
}
