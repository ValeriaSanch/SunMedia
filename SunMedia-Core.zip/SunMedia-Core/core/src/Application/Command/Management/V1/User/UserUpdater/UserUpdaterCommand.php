<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserUpdater;

use SunMedia\Shared\Domain\Bus\SyncCommand;

class UserUpdaterCommand implements SyncCommand
{
    public const ACTION = 'MANAGEMENT_USER_EDIT';

    /** @var string */
    private $id;

    /** @var string */
    private $name;

    /** @var string */
    private $email;

    /** @var string */
    private $authorId;

    /** @var array */
    private $contextRoles;

    /** @var bool */
    private $enabled;

    public function __construct(string $authorId, string $id, string $name, string $email, array $contextRoles, bool $enabled)
    {
        $this->id = $id;
        $this->name = $name;
        $this->email = $email;
        $this->contextRoles = $contextRoles;
        $this->authorId = $authorId;
        $this->enabled = $enabled;
    }

    public function id(): string
    {
        return $this->id;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function email(): string
    {
        return $this->email;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }

    public function contextRoles(): array
    {
        return $this->contextRoles;
    }

    public function enabled(): bool
    {
        return $this->enabled;
    }
}
