<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserUpdater;

use SunMedia\Core\Domain\Model\Advertiser\AdvertiserCollection;
use SunMedia\Core\Domain\Model\Client\ClientCollection;
use SunMedia\Core\Domain\Model\Publisher\PublisherCollection;
use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUserCollection;
use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Model\User\UserEnabled;
use SunMedia\Core\Domain\Model\User\UserName;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Context\Context;
use SunMedia\Shared\Domain\Model\ContextRoleSettings\ContextRoleSettings;
use SunMedia\Shared\Domain\Model\Email\Email;
use SunMedia\Shared\Domain\Model\Role\Role as UserRole;
use SunMedia\Shared\Domain\Model\User\ContextRole;
use SunMedia\Shared\Domain\Model\User\ContextRoleCollection;

class UserUpdaterService
{
    /** @var UserRepository */
    private $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    /**
     * @throws DomainException
     */
    public function execute(
        User $author,
        User $user,
        UserName $userName,
        Email $email,
        UserEnabled $enabled,
        ContextRoleCollection $contextRoleCollection,
        ClientCollection $clientCollection,
        AdvertiserCollection $advertiserCollection,
        SalesforceUserCollection $userSalesforceCollection,
        PublisherCollection $publisherCollection,
        UserRole $userRole
    ): void {
        if (null === $contextRoleCollection->get(Context::CORE)) {
            $contextRoleCollection->addContextRole(ContextRole::create(
                Context::core(),
                new UserRole(UserRole::ROLE_USER),
                new ContextRoleSettings([])
            ));
        }

        $user->updateUser($author, $userName, $email, $contextRoleCollection, $userRole, $enabled);

        $user->linkClients($author, $clientCollection);
        $user->linkAdvertisers($author, $advertiserCollection);
        $user->linkSalesforceUser($author, $userSalesforceCollection);
        $user->linkPublishers($author, $publisherCollection);

        $this->userRepository->save($user);
    }
}
