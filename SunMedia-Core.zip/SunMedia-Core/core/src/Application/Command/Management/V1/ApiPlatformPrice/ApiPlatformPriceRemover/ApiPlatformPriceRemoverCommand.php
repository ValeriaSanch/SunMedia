<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\ApiPlatformPrice\ApiPlatformPriceRemover;

use SunMedia\Shared\Domain\Bus\BackgroundCommand;

class ApiPlatformPriceRemoverCommand implements BackgroundCommand
{
    /** @var array */
    private $removeDates;

    public function __construct(array $removeDates)
    {
        $this->removeDates = $removeDates;
    }

    public function removeDates(): array
    {
        return $this->removeDates;
    }
}
