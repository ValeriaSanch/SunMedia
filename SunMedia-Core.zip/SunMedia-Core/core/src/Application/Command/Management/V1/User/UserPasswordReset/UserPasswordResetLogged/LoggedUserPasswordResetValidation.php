<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetLogged;

use SunMedia\Core\Domain\Model\User\Exception\PasswordSame;
use SunMedia\Core\Domain\Model\User\Exception\PasswordTooSimple;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserPassword;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\User\Exception\InvalidUserPassword;
use SunMedia\Shared\Domain\Model\User\Exception\PasswordMismatch;
use SunMedia\Shared\Domain\Model\User\PasswordEncoder;
use SunMedia\Shared\Domain\Model\User\UserId;

class LoggedUserPasswordResetValidation
{
    /** @var UserRepository */
    private $userRepository;

    /** @var UserValidation */
    private $userValidation;

    /** @var PasswordEncoder */
    private $passwordEncoder;

    public function __construct(
        UserRepository $userRepository,
        UserValidation $userValidation,
        PasswordEncoder $passwordEncoder
    ) {
        $this->userRepository = $userRepository;
        $this->userValidation = $userValidation;
        $this->passwordEncoder = $passwordEncoder;
    }

    /**
     * @throws DomainException
     * @throws InvalidUserPassword
     * @throws PasswordMismatch
     * @throws PasswordSame
     * @throws UserNotFound
     * @throws PasswordTooSimple
     * @throws EmptyValue
     */
    public function validate(LoggedUserPasswordResetCommand $command): array
    {
        if ($command->newPassword1() !== $command->newPassword2()) {
            throw new PasswordMismatch('Passwords are not the same.');
        }

        $userId = new UserId($command->userId());
        $user = $this->userRepository->byId($userId, new Criteria());

        if (null === $user) {
            throw new UserNotFound($userId);
        }

        $this->passwordEncoder->verify($command->oldPassword(), $user->password()->value());
        $this->userValidation->checkSafePassword($command->newPassword1());
        $userPassword = new UserPassword($this->passwordEncoder->encode($command->newPassword1()));

        if ($user->password()->equalsTo($userPassword->value())) {
            throw new PasswordSame('The passwords are the same');
        }

        return [$user, $userPassword];
    }
}
