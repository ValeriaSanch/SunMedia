<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Salesforce\SalesforceUserUpdater;

use SunMedia\Shared\Domain\Bus\Command;

class SalesforceUserUpdaterCommand implements Command
{
    public const ACTION = 'MANAGEMENT_USERS_SALESFORCE_EDIT';

    /** @var string */
    private $authorId;

    public function __construct(string $authorId)
    {
        $this->authorId = $authorId;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }
}
