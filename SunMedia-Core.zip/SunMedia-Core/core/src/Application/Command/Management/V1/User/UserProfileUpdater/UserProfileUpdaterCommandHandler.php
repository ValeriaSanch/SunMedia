<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserProfileUpdater;

use SunMedia\Core\Domain\Model\User\Exception\InvalidUserNameLength;
use SunMedia\Core\Domain\Model\User\Exception\UserEmailAlreadyExists;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Exception\EmptyValue;

class UserProfileUpdaterCommandHandler
{
    /** @var UserProfileUpdaterValidation */
    private $userCreatorValidation;

    /** @var UserProfileUpdaterService */
    private $userCreatorService;

    public function __construct(
        UserProfileUpdaterValidation $userCreatorValidation,
        UserProfileUpdaterService $userCreatorService
    ) {
        $this->userCreatorValidation = $userCreatorValidation;
        $this->userCreatorService = $userCreatorService;
    }

    /**
     * @throws DomainException
     * @throws EmailNotValid
     * @throws EmptyValue
     * @throws InvalidUserNameLength
     * @throws UserEmailAlreadyExists
     * @throws UserNotFound
     */
    public function __invoke(UserProfileUpdaterCommand $userCreatorCommand)
    {
        $this->userCreatorService->execute(...$this->userCreatorValidation->validate($userCreatorCommand));
    }
}
