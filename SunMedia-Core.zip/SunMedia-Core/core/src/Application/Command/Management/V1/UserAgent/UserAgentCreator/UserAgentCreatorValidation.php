<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\UserAgent\UserAgentCreator;

use SunMedia\Core\Domain\Model\UserAgent\Exception\UserAgentExists;
use SunMedia\Core\Domain\Model\UserAgent\UserAgentId;
use SunMedia\Core\Domain\Model\UserAgent\UserAgentName;
use SunMedia\Core\Domain\Model\UserAgent\UserAgentValidation;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Browser\Browser;
use SunMedia\Shared\Domain\Model\Browser\BrowserFamily;
use SunMedia\Shared\Domain\Model\Browser\BrowserVersion;
use SunMedia\Shared\Domain\Model\Device\Device;
use SunMedia\Shared\Domain\Model\Device\DeviceBrand;
use SunMedia\Shared\Domain\Model\Device\DeviceFamily;
use SunMedia\Shared\Domain\Model\Device\DeviceModel;
use SunMedia\Shared\Domain\Model\OperatingSystem\OperatingSystem;
use SunMedia\Shared\Domain\Model\OperatingSystem\OperatingSystemFamily;
use SunMedia\Shared\Domain\Model\OperatingSystem\OperatingSystemVersion;

class UserAgentCreatorValidation
{
    /** @var UserAgentValidation */
    private $userAgentValidation;

    public function __construct(UserAgentValidation $userAgentValidation)
    {
        $this->userAgentValidation = $userAgentValidation;
    }

    /**
     * @throws UserAgentExists
     * @throws DomainException
     */
    public function validate(UserAgentCreatorCommand $userAgentCreatorCommand): array
    {
        $userAgentId = new UserAgentId($userAgentCreatorCommand->id());
        $userAgentName = new UserAgentName($userAgentCreatorCommand->name());

        $this->userAgentValidation->checkIfUserAgentExists($userAgentName);

        $browser = new Browser(
            new BrowserFamily($userAgentCreatorCommand->browserFamily()),
            new BrowserVersion($userAgentCreatorCommand->browserVersion())
        );

        $device = new Device(
            new DeviceFamily($userAgentCreatorCommand->deviceFamily()),
            new DeviceBrand($userAgentCreatorCommand->deviceBrand()),
            new DeviceModel($userAgentCreatorCommand->deviceModel())
        );

        $operatingSystem = new OperatingSystem(
            new OperatingSystemFamily($userAgentCreatorCommand->osFamily()),
            new OperatingSystemVersion($userAgentCreatorCommand->osVersion())
        );

        return [
            $userAgentId,
            $userAgentName,
            $browser,
            $device,
            $operatingSystem,
            $userAgentCreatorCommand->isMobile(),
            $userAgentCreatorCommand->isTablet(),
            $userAgentCreatorCommand->isTouchCapable(),
            $userAgentCreatorCommand->isPc(),
            $userAgentCreatorCommand->isBot(),
        ];
    }
}
