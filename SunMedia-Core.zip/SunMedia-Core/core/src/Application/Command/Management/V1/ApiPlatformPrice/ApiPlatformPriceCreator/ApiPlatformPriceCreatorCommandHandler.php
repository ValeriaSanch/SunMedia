<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\ApiPlatformPrice\ApiPlatformPriceCreator;

use Exception;
use SunMedia\Core\Domain\Model\ApiPlatformPrice\ApiPlatformPriceDate;
use SunMedia\Core\Domain\Model\ApiPlatformPrice\ApiPlatformPriceValidation;
use SunMedia\Core\Domain\Model\ApiPlatformPrice\Exception\ApiPlatformPriceEmptyValue;
use SunMedia\Core\Infrastructure\Domain\PlatformV2\DownloadService\SMPlatformRequest;

class ApiPlatformPriceCreatorCommandHandler
{
    /** @var SMPlatformRequest */
    private $SMPlatformRequest;

    /** @var ApiPlatformPriceValidation */
    private $apiPlatformPriceValidation;

    public function __construct(
        SMPlatformRequest $SMPlatformRequest,
        ApiPlatformPriceValidation $apiPlatformPriceValidation
    ) {
        $this->SMPlatformRequest = $SMPlatformRequest;
        $this->apiPlatformPriceValidation = $apiPlatformPriceValidation;
    }

    /**
     * @throws ApiPlatformPriceEmptyValue
     * @throws Exception
     */
    public function __invoke(ApiPlatformPriceCreatorCommand $command)
    {
        ini_set('memory_limit', '1024M');
        $date = new ApiPlatformPriceDate($command->date());

        $handler = $this->SMPlatformRequest->execute($date);

        if (!is_bool($handler) && $handler) {
            $this->apiPlatformPriceValidation->create($handler, $date);
        }
    }
}
