<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserProfileUpdater;

use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Model\User\UserName;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Email\Email;

class UserProfileUpdaterService
{
    /** @var UserRepository */
    private $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    /**
     * @throws DomainException
     */
    public function execute(User $author, UserName $name, Email $email): void
    {
        $author->updateProfile($name, $email);

        $this->userRepository->save($author);
    }
}
