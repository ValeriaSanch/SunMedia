<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserCreator;

use SunMedia\Core\Domain\Model\Advertiser\Exception\AdvertiserNotFound;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNotFound;
use SunMedia\Core\Domain\Model\Publisher\Exception\PublisherNotFound;
use SunMedia\Core\Domain\Model\SalesforceUser\Exception\SalesforceUserIdNotEmpty;
use SunMedia\Core\Domain\Model\SalesforceUser\Exception\SalesforceUserNotFound;
use SunMedia\Core\Domain\Model\User\Exception\AdvertiserNotBelongsToClient;
use SunMedia\Core\Domain\Model\User\Exception\InvalidUserContextRolesQuantity;
use SunMedia\Core\Domain\Model\User\Exception\InvalidUserNameLength;
use SunMedia\Core\Domain\Model\User\Exception\MandatoryParameterNotFound;
use SunMedia\Core\Domain\Model\User\Exception\PublisherNotBelongsToClient;
use SunMedia\Core\Domain\Model\User\Exception\UserEmailAlreadyExists;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\Role\Exception\InvalidRole;
use SunMedia\Shared\Domain\Model\User\Exception\InvalidUserPassword;

class UserCreatorCommandHandler
{
    /** @var UserCreatorValidation */
    private $userCreatorValidation;

    /** @var UserCreatorService */
    private $userCreatorService;

    public function __construct(
        UserCreatorValidation $userCreatorValidation,
        UserCreatorService $userCreatorService
    ) {
        $this->userCreatorValidation = $userCreatorValidation;
        $this->userCreatorService = $userCreatorService;
    }

    /**
     * @throws AdvertiserNotBelongsToClient
     * @throws AdvertiserNotFound
     * @throws ClientNotFound
     * @throws DomainException
     * @throws EmailNotValid
     * @throws EmptyValue
     * @throws InvalidRole
     * @throws InvalidUserContextRolesQuantity
     * @throws InvalidUserNameLength
     * @throws InvalidUserPassword
     * @throws MandatoryParameterNotFound
     * @throws PublisherNotBelongsToClient
     * @throws PublisherNotFound
     * @throws UserEmailAlreadyExists
     * @throws UserNotFound
     * @throws SalesforceUserIdNotEmpty
     * @throws SalesforceUserNotFound
     */
    public function __invoke(UserCreatorCommand $userCreatorCommand)
    {
        $this->userCreatorService->execute(...$this->userCreatorValidation->validate($userCreatorCommand));
    }
}
