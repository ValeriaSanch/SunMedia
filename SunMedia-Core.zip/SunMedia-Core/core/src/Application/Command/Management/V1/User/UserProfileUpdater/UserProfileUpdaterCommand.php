<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserProfileUpdater;

use SunMedia\Shared\Domain\Bus\SyncCommand;

class UserProfileUpdaterCommand implements SyncCommand
{
    public const ACTION = 'MANAGEMENT_USER_EDIT';

    /** @var string */
    private $name;

    /** @var string */
    private $email;

    /** @var string */
    private $authorId;

    public function __construct(string $authorId, string $name, string $email)
    {
        $this->name = $name;
        $this->email = $email;
        $this->authorId = $authorId;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function email(): string
    {
        return $this->email;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }
}
