<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\CurrencyRate\CurrencyRateCreator;

use SunMedia\Shared\Domain\Bus\Command;

class CurrencyRateCreatorCommand implements Command
{
    /** @var string */
    private $destinyCurrency;

    /** @var string */
    private $baseCurrency;

    /** @var string */
    private $date;

    /** @var float */
    private $rateAmount;

    public function __construct(
        string $baseCurrency,
        string $destinyCurrency,
        string $date,
        float $rateAmount
    ) {
        $this->baseCurrency = $baseCurrency;
        $this->destinyCurrency = $destinyCurrency;
        $this->date = $date;
        $this->rateAmount = $rateAmount;
    }

    public function destinyCurrency(): string
    {
        return $this->destinyCurrency;
    }

    public function baseCurrency(): string
    {
        return $this->baseCurrency;
    }

    public function date(): string
    {
        return $this->date;
    }

    public function rateAmount(): float
    {
        return $this->rateAmount;
    }
}
