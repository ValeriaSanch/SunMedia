<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedUpdaterBackground;

use SunMedia\Shared\Domain\Bus\BackgroundCommand;

class FeedUpdaterBackgroundCommand implements BackgroundCommand
{
    public const ACTION = 'MANAGEMENT_FEED_UPDATE';

    /** @var string */
    private $authorId;

    public function __construct(string $authorId)
    {
        $this->authorId = $authorId;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }
}
