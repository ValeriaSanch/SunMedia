<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetRequest;

use Exception;
use SunMedia\Core\Domain\Model\User\Exception\UserEmailNotExists;
use SunMedia\Core\Domain\Model\User\Exception\UserTokenResetPasswordIsValid;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Model\Email\Email;
use SunMedia\Shared\Domain\Model\User\Token\Token;
use SunMedia\Shared\Domain\Model\User\UserTokenValidator;

class UserPasswordResetRequestValidation
{
    /** @var UserValidation */
    private $userValidation;

    /** @var UserTokenValidator */
    private $tokenValidator;

    public function __construct(UserTokenValidator $tokenValidator, UserValidation $userValidation)
    {
        $this->userValidation = $userValidation;
        $this->tokenValidator = $tokenValidator;
    }

    /**
     * @throws EmailNotValid
     * @throws UserEmailNotExists
     * @throws UserTokenResetPasswordIsValid
     */
    public function validate(UserPasswordResetRequestCommand $command): array
    {
        $email = new Email($command->email());
        $user = $this->userValidation->ensureEmailExists($email);

        // Si el token aun es valido no se puede reenviar el email
        if ($user && null !== $user->tokenResetPassword()->value()) {
            $token = new Token($user->tokenResetPassword()->value());

            try {
                $isValid = $this->tokenValidator->validate($token);
            } catch (Exception $exception) {
                $isValid = false;
            }

            if (false !== $isValid) {
                throw new UserTokenResetPasswordIsValid();
            }
        }

        return [$user];
    }
}
