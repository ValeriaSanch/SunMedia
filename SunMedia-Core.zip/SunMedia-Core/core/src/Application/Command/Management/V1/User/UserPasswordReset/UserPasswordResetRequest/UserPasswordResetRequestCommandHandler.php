<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetRequest;

use SunMedia\Core\Domain\Model\User\Exception\UserEmailNotExists;
use SunMedia\Core\Domain\Model\User\Exception\UserTokenResetPasswordIsValid;
use SunMedia\Shared\Domain\Exception\EmailNotValid;

class UserPasswordResetRequestCommandHandler
{
    /** @var UserPasswordResetRequestService */
    private $service;

    /** @var UserPasswordResetRequestValidation */
    private $validation;

    public function __construct(
        UserPasswordResetRequestService $service,
        UserPasswordResetRequestValidation $validation
    ) {
        $this->service = $service;
        $this->validation = $validation;
    }

    /**
     * @throws EmailNotValid
     * @throws UserEmailNotExists
     * @throws UserTokenResetPasswordIsValid
     */
    public function __invoke(UserPasswordResetRequestCommand $command)
    {
        $this->service->execute(...$this->validation->validate($command));
    }
}
