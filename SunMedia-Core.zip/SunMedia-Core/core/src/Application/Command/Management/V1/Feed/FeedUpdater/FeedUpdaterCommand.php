<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedUpdater;

use SunMedia\Shared\Domain\Bus\Command;

class FeedUpdaterCommand implements Command
{
    public const ACTION = 'MANAGEMENT_FEED_EDIT';

    /** @var string */
    private $authorId;

    /** @var string */
    private $id;

    /** @var string */
    private $name;

    /** @var string */
    private $type;

    /** @var string */
    private $url;

    /** @var int */
    private $hourInterval;

    /** @var array */
    private $callbackUrl;

    /** @var array */
    private $dictionary;

    public function __construct(
        string $authorId,
        string $id,
        string $name,
        string $type,
        string $url,
        int $hourInterval,
        array $callbackUrl,
        array $dictionary
    ) {
        $this->authorId = $authorId;
        $this->id = $id;
        $this->name = $name;
        $this->type = $type;
        $this->url = $url;
        $this->hourInterval = $hourInterval;
        $this->callbackUrl = $callbackUrl;
        $this->dictionary = $dictionary;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }

    public function id(): string
    {
        return $this->id;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function type(): string
    {
        return $this->type;
    }

    public function url(): string
    {
        return $this->url;
    }

    public function hourInterval(): int
    {
        return $this->hourInterval;
    }

    public function callbackUrl(): array
    {
        return $this->callbackUrl;
    }

    public function dictionary(): array
    {
        return $this->dictionary;
    }
}
