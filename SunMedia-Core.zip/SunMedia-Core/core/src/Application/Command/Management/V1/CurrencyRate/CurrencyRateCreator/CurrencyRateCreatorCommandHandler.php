<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\CurrencyRate\CurrencyRateCreator;

use SunMedia\Shared\Domain\Exception\DomainException;

class CurrencyRateCreatorCommandHandler
{
    /** @var CurrencyRateCreatorService */
    private $service;

    /** @var CurrencyRateCreatorValidation */
    private $validation;

    public function __construct(CurrencyRateCreatorService $service, CurrencyRateCreatorValidation $validation)
    {
        $this->service = $service;
        $this->validation = $validation;
    }

    /**
     * @throws DomainException
     */
    public function __invoke(CurrencyRateCreatorCommand $command)
    {
        $this->service->execute($this->validation->validate($command));
    }
}
