<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\CdnInvalidation\ReprocessCdnUrlInvalidator;

use Symfony\Component\Mailer\Exception\TransportExceptionInterface;

final class ReprocessCdnUrlInvalidatorCommandHandler
{
    /** @var ReprocessCdnUrlInvalidatorService */
    private $cdnInvalidationUrlService;

    public function __construct(
        ReprocessCdnUrlInvalidatorService $cdnInvalidationUrlService
    ) {
        $this->cdnInvalidationUrlService = $cdnInvalidationUrlService;
    }

    /**
     * @throws TransportExceptionInterface
     */
    public function __invoke(ReprocessCdnUrlInvalidatorCommand $cdnInvalidationUrlCommand): void
    {
        $this->cdnInvalidationUrlService->execute(
            $cdnInvalidationUrlCommand->authorId(),
            $cdnInvalidationUrlCommand->context(),
            $cdnInvalidationUrlCommand->status()
        );
    }
}
