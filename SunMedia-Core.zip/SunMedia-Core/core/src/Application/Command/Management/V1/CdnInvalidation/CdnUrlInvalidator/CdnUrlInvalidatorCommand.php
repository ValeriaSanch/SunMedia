<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\CdnInvalidation\CdnUrlInvalidator;

use SunMedia\Core\Domain\Model\Bus\CdnCommand;

final class CdnUrlInvalidatorCommand //implements CdnCommand
{
    /** @var string */
    private $authorId;

    /** @var string */
    private $id;

    /** @var string */
    private $context;

    /** @var string */
    private $urls;

    /** @var bool */
    private $ban;

    public function __construct(
        string $authorId,
        string $id,
        string $context,
        array $url,
        bool $ban
    ) {
        $this->authorId = $authorId;
        $this->context = $context;
        $this->urls = $url;
        $this->ban = $ban;
        $this->id = $id;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }

    public function id(): string
    {
        return $this->id;
    }

    public function context(): string
    {
        return $this->context;
    }

    public function urls(): array
    {
        return $this->urls;
    }

    public function ban(): bool
    {
        return $this->ban;
    }
}
