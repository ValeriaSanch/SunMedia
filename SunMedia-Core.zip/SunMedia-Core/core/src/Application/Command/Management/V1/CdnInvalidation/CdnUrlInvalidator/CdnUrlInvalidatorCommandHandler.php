<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\CdnInvalidation\CdnUrlInvalidator;

use Symfony\Component\Mailer\Exception\TransportExceptionInterface;

final class CdnUrlInvalidatorCommandHandler
{
    /** @var CdnUrlInvalidatorService */
    private $cdnInvalidationUrlService;

    public function __construct(
        CdnUrlInvalidatorService $cdnInvalidationUrlService
    ) {
        $this->cdnInvalidationUrlService = $cdnInvalidationUrlService;
    }

    /**
     * @throws TransportExceptionInterface
     */
    public function __invoke(CdnUrlInvalidatorCommand $cdnInvalidationUrlCommand): void
    {
        $this->cdnInvalidationUrlService->execute(
            $cdnInvalidationUrlCommand->authorId(),
            $cdnInvalidationUrlCommand->id(),
            $cdnInvalidationUrlCommand->context(),
            $cdnInvalidationUrlCommand->urls(),
            $cdnInvalidationUrlCommand->ban()
        );
    }
}
