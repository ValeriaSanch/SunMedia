<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedUpdater;

use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileEmpty;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidCallbackUrl;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidFileType;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidHourInterval;
use SunMedia\Core\Domain\Model\Feed\FeedCallbackUrl;
use SunMedia\Core\Domain\Model\Feed\FeedDictionary;
use SunMedia\Core\Domain\Model\Feed\FeedHourInterval;
use SunMedia\Core\Domain\Model\Feed\FeedId;
use SunMedia\Core\Domain\Model\Feed\FeedName;
use SunMedia\Core\Domain\Model\Feed\FeedType;
use SunMedia\Core\Domain\Model\Feed\FeedUrl;
use SunMedia\Core\Domain\Model\Feed\FeedValidation;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\User\UserId;

class FeedUpdaterValidation
{
    /** @var FeedValidation */
    private $feedValidation;

    /** @var UserValidation */
    private $userValidation;

    public function __construct(FeedValidation $feedValidation, UserValidation $userValidation)
    {
        $this->feedValidation = $feedValidation;
        $this->userValidation = $userValidation;
    }

    /**
     * @throws DomainException
     * @throws EmptyValue
     * @throws FeedFileEmpty
     * @throws FeedFileNotFound
     * @throws FeedNotFound
     * @throws InvalidCallbackUrl
     * @throws InvalidFileType
     * @throws InvalidHourInterval
     * @throws UserNotFound
     */
    public function validate(FeedUpdaterCommand $feedUpdaterCommand): array
    {
        $type = new FeedType($feedUpdaterCommand->type());
        $hourInterval = new FeedHourInterval($feedUpdaterCommand->hourInterval());
        $feedId = new FeedId($feedUpdaterCommand->id());
        $feed = $this->feedValidation->ensureFeedIdExists($feedId);

        if (!$feedUpdaterCommand->url() && $feed->type()->equalsTo(FeedType::FEED_TYPE_FILE)) {
            $url = new FeedUrl($feedUpdaterCommand->url(), true);
            $type = $feed->type();
        } else {
            $url = new FeedUrl($feedUpdaterCommand->url());
        }

        $this->feedValidation->validateHourInterval($type, $hourInterval, $url);

        return [
            $this->userValidation->checkAuthor(new UserId($feedUpdaterCommand->authorId())),
            $feed,
            new FeedName($feedUpdaterCommand->name()),
            $type,
            $hourInterval,
            $url,
            new FeedCallbackUrl($feedUpdaterCommand->callbackUrl()),
            new FeedDictionary($feedUpdaterCommand->dictionary()),
        ];
    }
}
