<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedUpdaterBackground;

use SunMedia\Core\Domain\Model\Feed\FeedRepository;
use SunMedia\Core\Domain\Model\Feed\FeedType;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Criteria\Expr\ExpressionBuilder;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\User\UserId;

class FeedUpdaterBackgroundValidation
{
    /** @var UserValidation */
    private $userValidation;

    /** @var FeedRepository */
    private $feedRepository;

    public function __construct(UserValidation $userValidation, FeedRepository $feedRepository)
    {
        $this->userValidation = $userValidation;
        $this->feedRepository = $feedRepository;
    }

    /**
     * @throws DomainException
     * @throws UserNotFound
     */
    public function validate(FeedUpdaterBackgroundCommand $feedUpdaterCommand): array
    {
        $expressionBuilder = new ExpressionBuilder();
        $expression = $expressionBuilder->eq('type', FeedType::FEED_TYPE_URL);

        return [
            $this->userValidation->checkAuthor(new UserId($feedUpdaterCommand->authorId())),
            $this->feedRepository->byCriteria(new Criteria($expression)),
        ];
    }
}
