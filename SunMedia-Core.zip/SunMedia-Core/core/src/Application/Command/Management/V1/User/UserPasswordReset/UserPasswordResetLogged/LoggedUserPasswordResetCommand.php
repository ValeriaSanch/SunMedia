<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetLogged;

use SunMedia\Shared\Domain\Bus\SyncCommand;

class LoggedUserPasswordResetCommand implements SyncCommand
{
    public const ACTION = 'MANAGEMENT_LOGGED_USER_PASSWORD_RESET';

    /** @var string */
    private $userId;

    /** @var string */
    private $newPassword1;

    /** @var string */
    private $oldPassword;

    /** @var string */
    private $newPassword2;

    public function __construct(string $userId, string $oldPassword, string $newPassword1, string $newPassword2)
    {
        $this->userId = $userId;
        $this->oldPassword = $oldPassword;
        $this->newPassword1 = $newPassword1;
        $this->newPassword2 = $newPassword2;
    }

    public function userId(): string
    {
        return $this->userId;
    }

    public function oldPassword(): string
    {
        return $this->oldPassword;
    }

    public function newPassword1(): string
    {
        return $this->newPassword1;
    }

    public function newPassword2(): string
    {
        return $this->newPassword2;
    }
}
