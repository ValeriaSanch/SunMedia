<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetNotLogged;

use SunMedia\Shared\Domain\Bus\SyncCommand;

class NotLoggedUserPasswordResetCommand implements SyncCommand
{
    public const ACTION = 'MANAGEMENT_NOT_LOGGED_USER_PASSWORD_RESET';

    /** @var string */
    private $token;

    /** @var string */
    private $newPassword1;

    /** @var string */
    private $newPassword2;

    public function __construct(string $token, string $newPassword1, string $newPassword2)
    {
        $this->token = $token;
        $this->newPassword1 = $newPassword1;
        $this->newPassword2 = $newPassword2;
    }

    public function token(): string
    {
        return $this->token;
    }

    public function newPassword1(): string
    {
        return $this->newPassword1;
    }

    public function newPassword2(): string
    {
        return $this->newPassword2;
    }
}
