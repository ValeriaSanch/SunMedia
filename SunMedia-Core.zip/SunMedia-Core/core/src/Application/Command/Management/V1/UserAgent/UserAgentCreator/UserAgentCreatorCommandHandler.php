<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\UserAgent\UserAgentCreator;

use SunMedia\Core\Domain\Model\UserAgent\Exception\UserAgentExists;
use SunMedia\Shared\Domain\Exception\DomainException;

class UserAgentCreatorCommandHandler
{
    private $userAgentCreatorValidation;

    private $userAgentCreatorService;

    public function __construct(
        UserAgentCreatorValidation $userAgentCreatorValidation,
        UserAgentCreatorService $userAgentCreatorService
    ) {
        $this->userAgentCreatorValidation = $userAgentCreatorValidation;
        $this->userAgentCreatorService = $userAgentCreatorService;
    }

    /**
     * @throws UserAgentExists
     * @throws DomainException
     */
    public function __invoke(UserAgentCreatorCommand $command)
    {
        $this->userAgentCreatorService->execute(...$this->userAgentCreatorValidation->validate($command));
    }
}
