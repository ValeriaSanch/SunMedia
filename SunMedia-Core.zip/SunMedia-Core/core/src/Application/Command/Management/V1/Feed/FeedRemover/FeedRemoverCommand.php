<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedRemover;

use SunMedia\Shared\Domain\Bus\SyncCommand;

class FeedRemoverCommand implements SyncCommand
{
    public const ACTION = 'MANAGEMENT_FEED_DELETE';

    /** @var string */
    private $authorId;

    /** @var string */
    private $feedId;

    public function __construct(string $authorId, string $feedId)
    {
        $this->authorId = $authorId;
        $this->feedId = $feedId;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }

    public function feedId(): string
    {
        return $this->feedId;
    }
}
