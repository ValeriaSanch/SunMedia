<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\CurrencyRate\CurrencyRateCreator;

use Exception;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Currency\CurrencyId;
use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRate;
use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRateAmount;
use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRateId;
use SunMedia\Shared\Domain\Model\Date\SMDate;

class CurrencyRateCreatorValidation
{
    /**
     * @throws DomainException
     * @throws Exception
     */
    public function validate(CurrencyRateCreatorCommand $command): CurrencyRate
    {
        return CurrencyRate::create(
            CurrencyRateId::random(),
            new CurrencyId($command->baseCurrency()),
            new CurrencyId($command->destinyCurrency()),
            SMDate::fromString($command->date()),
            new CurrencyRateAmount($command->rateAmount()),
        );
    }
}
