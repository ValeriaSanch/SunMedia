<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\ApiPlatformPrice\ApiPlatformPriceCreator;

use SunMedia\Shared\Domain\Bus\BackgroundCommand;

class ApiPlatformPriceCreatorCommand implements BackgroundCommand
{
    /** @var string */
    private $date;

    public function __construct(string $date)
    {
        $this->date = $date;
    }

    public function date(): string
    {
        return $this->date;
    }
}
