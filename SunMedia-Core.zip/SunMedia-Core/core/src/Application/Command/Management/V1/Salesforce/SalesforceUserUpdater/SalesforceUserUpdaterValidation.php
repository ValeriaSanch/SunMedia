<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Salesforce\SalesforceUserUpdater;

use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\User\UserId;

class SalesforceUserUpdaterValidation
{
    /** @var UserValidation */
    private $userValidation;

    public function __construct(UserValidation $userValidation)
    {
        $this->userValidation = $userValidation;
    }

    /**
     * @throws DomainException
     * @throws UserNotFound
     */
    public function validate(SalesforceUserUpdaterCommand $command): array
    {
        return [$this->userValidation->checkAuthor(new UserId($command->authorId()))];
    }
}
