<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetRequest;

use SunMedia\Shared\Domain\Bus\SyncCommand;

class UserPasswordResetRequestCommand implements SyncCommand
{
    public const ACTION = 'MANAGEMENT_USER_PASSWORD_RESET_REQUEST';

    /** @var string */
    private $email;

    public function __construct(string $email)
    {
        $this->email = $email;
    }

    public function email(): string
    {
        return $this->email;
    }
}
