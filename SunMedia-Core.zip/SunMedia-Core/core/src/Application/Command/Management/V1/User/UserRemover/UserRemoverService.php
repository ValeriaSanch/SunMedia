<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserRemover;

use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Model\User\UserRepository;

class UserRemoverService
{
    /** @var UserRepository */
    private $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function execute(User $author, User $user): void
    {
        $user->removeByUser($author);

        $this->userRepository->save($user);
    }
}
