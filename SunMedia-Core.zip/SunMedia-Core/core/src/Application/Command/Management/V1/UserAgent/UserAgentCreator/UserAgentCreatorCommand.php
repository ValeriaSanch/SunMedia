<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\UserAgent\UserAgentCreator;

use SunMedia\Shared\Domain\Bus\Command;

class UserAgentCreatorCommand implements Command
{
    public const ACTION = 'MANAGEMENT_USER_AGENT_CREATE';

    /** @var string */
    private $id;

    /** @var string */
    private $name;

    /** @var string */
    private $authorId;

    /** @var string */
    private $browserFamily;

    /** @var string */
    private $browserVersion;

    /** @var string */
    private $osFamily;

    /** @var string */
    private $osVersion;

    /** @var string */
    private $deviceFamily;

    /** @var string */
    private $deviceBrand;

    /** @var string */
    private $deviceModel;

    /** @var bool */
    private $isMobile;

    /** @var bool */
    private $isTablet;

    /** @var bool */
    private $isTouchCapable;

    /** @var bool */
    private $isPc;

    /** @var bool */
    private $isBot;

    public function __construct(
        string $authorId,
        string $id,
        string $name,
        string $browserFamily,
        string $browserVersion,
        string $osFamily,
        string $osVersion,
        string $deviceFamily,
        string $deviceBrand,
        string $deviceModel,
        bool $isMobile,
        bool $isTablet,
        bool $isTouchCapable,
        bool $isPc,
        bool $isBot
    ) {
        $this->id = $id;
        $this->name = $name;
        $this->authorId = $authorId;
        $this->browserFamily = $browserFamily;
        $this->browserVersion = $browserVersion;
        $this->osFamily = $osFamily;
        $this->osVersion = $osVersion;
        $this->deviceFamily = $deviceFamily;
        $this->deviceBrand = $deviceBrand;
        $this->deviceModel = $deviceModel;
        $this->isMobile = $isMobile;
        $this->isTablet = $isTablet;
        $this->isTouchCapable = $isTouchCapable;
        $this->isPc = $isPc;
        $this->isBot = $isBot;
    }

    public function id(): string
    {
        return $this->id;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }

    public function browserFamily(): string
    {
        return $this->browserFamily;
    }

    public function browserVersion(): string
    {
        return $this->browserVersion;
    }

    public function osFamily(): string
    {
        return $this->osFamily;
    }

    public function osVersion(): string
    {
        return $this->osVersion;
    }

    public function deviceFamily(): string
    {
        return $this->deviceFamily;
    }

    public function deviceBrand(): string
    {
        return $this->deviceBrand;
    }

    public function deviceModel(): string
    {
        return $this->deviceModel;
    }

    public function isMobile(): bool
    {
        return $this->isMobile;
    }

    public function isTablet(): bool
    {
        return $this->isTablet;
    }

    public function isTouchCapable(): bool
    {
        return $this->isTouchCapable;
    }

    public function isPc(): bool
    {
        return $this->isPc;
    }

    public function isBot(): bool
    {
        return $this->isBot;
    }
}
