<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserRemover;

use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;

class UserRemoverCommandHandler
{
    /** @var UserRemoverValidation */
    private $userRemoverValidation;

    /** @var UserRemoverService */
    private $userRemoverService;

    public function __construct(UserRemoverValidation $userRemoverValidation, UserRemoverService $userRemoverService)
    {
        $this->userRemoverValidation = $userRemoverValidation;
        $this->userRemoverService = $userRemoverService;
    }

    /**
     * @throws DomainException
     * @throws UserNotFound
     */
    public function __invoke(UserRemoverCommand $userRemoverCommand)
    {
        $this->userRemoverService->execute(...$this->userRemoverValidation->validate($userRemoverCommand));
    }
}
