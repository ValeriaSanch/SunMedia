<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserRemover;

use SunMedia\Shared\Domain\Bus\SyncCommand;

class UserRemoverCommand implements SyncCommand
{
    public const ACTION = 'MANAGEMENT_USER_DELETE';

    /** @var string */
    private $id;

    /** @var string */
    private $authorId;

    public function __construct(string $authorId, string $id)
    {
        $this->id = $id;
        $this->authorId = $authorId;
    }

    public function id(): string
    {
        return $this->id;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }
}
