<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedUpdater;

use SunMedia\Core\Domain\Model\Feed\Feed;
use SunMedia\Core\Domain\Model\Feed\FeedCallbackUrl;
use SunMedia\Core\Domain\Model\Feed\FeedDictionary;
use SunMedia\Core\Domain\Model\Feed\FeedHourInterval;
use SunMedia\Core\Domain\Model\Feed\FeedInput;
use SunMedia\Core\Domain\Model\Feed\FeedName;
use SunMedia\Core\Domain\Model\Feed\FeedOutput;
use SunMedia\Core\Domain\Model\Feed\FeedRepository;
use SunMedia\Core\Domain\Model\Feed\FeedType;
use SunMedia\Core\Domain\Model\Feed\FeedUrl;
use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Service\Feed\TransformDataFeed;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmptyValue;

class FeedUpdaterService
{
    /** @var FeedRepository */
    private $feedRepository;

    /** @var TransformDataFeed */
    private $transformDataFeed;

    public function __construct(FeedRepository $feedRepository, TransformDataFeed $transformDataFeed)
    {
        $this->feedRepository = $feedRepository;
        $this->transformDataFeed = $transformDataFeed;
    }

    /**
     * @throws DomainException
     * @throws EmptyValue
     */
    public function execute(
        User $author,
        Feed $feed,
        FeedName $name,
        FeedType $type,
        FeedHourInterval $hourInterval,
        FeedUrl $url,
        FeedCallbackUrl $callbackUrl,
        FeedDictionary $dictionary
    ): void {
        $output = [];
        $input = [];

        [$url, $dictionary2] = $this->transformDataFeed->generateData(
            $callbackUrl,
            $url,
            $type,
            $dictionary,
            $input,
            $output,
            $feed->input()
        );

        $pathInput = $url;
        if ($type->equalsTo(FeedType::FEED_TYPE_FILE)) {
            if (!$dictionary2 && isset($feed->dictionary()->value()[FeedDictionary::DICTIONARY_FILE])) {
                $dictionary2 = $feed->dictionary()->value()[FeedDictionary::DICTIONARY_FILE];
            }
            $pathInput = $this->transformDataFeed->transformFile()->createCSV($feed->id(), $input, 'input');
            unset($input);
        }
        $pathOutput = $this->transformDataFeed->transformFile()->createCSV($feed->id(), $output, 'output');

        $dictionary = new FeedDictionary([
            FeedDictionary::DICTIONARY_FILE => $dictionary2,
            FeedDictionary::DICTIONARY_FEED => $dictionary->value(),
        ]);
        unset($dictionary2);

        $feed->update(
            $author,
            $feed->id(),
            $name,
            $type,
            $hourInterval,
            $url,
            $callbackUrl,
            new FeedInput($pathInput->value()),
            new FeedOutput($pathOutput->value()),
            $dictionary
        );

        $this->feedRepository->save($feed);

        $this->transformDataFeed->sendData($callbackUrl, $output);
        unset($output);
    }
}
