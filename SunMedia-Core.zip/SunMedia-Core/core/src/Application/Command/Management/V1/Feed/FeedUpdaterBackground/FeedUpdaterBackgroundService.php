<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedUpdaterBackground;

use DateTimeInterface;
use Exception;
use Psr\Log\LoggerInterface;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidFileType;
use SunMedia\Core\Domain\Model\Feed\Feed;
use SunMedia\Core\Domain\Model\Feed\FeedCollection;
use SunMedia\Core\Domain\Model\Feed\FeedDictionary;
use SunMedia\Core\Domain\Model\Feed\FeedInput;
use SunMedia\Core\Domain\Model\Feed\FeedOutput;
use SunMedia\Core\Domain\Model\Feed\FeedRepository;
use SunMedia\Core\Domain\Model\Feed\FeedUrl;
use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Service\Feed\TransformDataFeed;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class FeedUpdaterBackgroundService
{
    /** @var FeedRepository */
    private $feedRepository;

    /** @var TransformDataFeed */
    private $transformDataFeed;

    /** @var LoggerInterface */
    private $logger;

    public function __construct(
        FeedRepository $feedRepository,
        TransformDataFeed $transformDataFeed,
        LoggerInterface $logger
    ) {
        $this->feedRepository = $feedRepository;
        $this->transformDataFeed = $transformDataFeed;
        $this->logger = $logger;
    }

    /**
     * @throws DomainException
     * @throws EmptyValue
     * @throws InvalidFileType
     * @throws Exception
     */
    public function execute(User $author, FeedCollection $feedCollection): void
    {
        /** @var Feed $feed */
        foreach ($feedCollection as $feed) {
            $dictionary = $feed->dictionary()->value()[FeedDictionary::DICTIONARY_FEED] ?? [];
            if (!$dictionary || !$feed->updatedAt() || !$feed->callbackUrl()->value()) {
                continue;
            }

            $minutes = 0;
            $serverDate = SMDatetime::now()->format(DateTimeInterface::ATOM);
            $feedDate = $feed->updatedAt()->format(DateTimeInterface::ATOM);
            $this->minutesElapsed($feedDate, $serverDate, $minutes);
            $minutesInterval = 60 * $feed->hourInterval()->value();
            $this->logger->info(
                'Feed Interval Time',
                [
                    'feed' => $feed->id()->value(),
                    'feed_date' => $feedDate,
                    'server_date' => $serverDate,
                    'minutes_elapsed' => $minutes,
                    'minutes_interval' => $minutesInterval,
                    'hour_interval' => $feed->hourInterval()->value(),
                ]
            );

            if ($minutes < $minutesInterval) {
                continue;
            }

            $output = [];
            $input = [];

            if (preg_match('/.*\.(csv)$/', $feed->url()->value())) {
                $this->transformDataFeed->csvToArray($input, $feed->url());
            } elseif (preg_match('/.*\.(xml)$/', $feed->url()->value())) {
                $this->transformDataFeed->xmlToArray($input, $feed->url());
            } else {
                throw new InvalidFileType(FeedUrl::TYPES);
            }

            $this->transformDataFeed->convertData($output, $input, new FeedDictionary($dictionary));
            $pathOutput = $this->transformDataFeed->transformFile()->createCSV($feed->id(), $output, 'output');

            $feed->updateBackground(
                $author,
                new FeedInput($feed->url()->value()),
                new FeedOutput($pathOutput->value())
            );

            $this->feedRepository->save($feed);

            $this->logger->info('Feed update background', ['feed' => $feed->id()->value()]);

            $this->transformDataFeed->sendData($feed->callbackUrl(), $output);
        }
    }

    private function minutesElapsed(string $timeI, string $timeE, &$minutes): void
    {
        $minutes = (strtotime($timeI) - strtotime($timeE)) / 60;
        $minutes = (int) floor(abs($minutes));
    }
}
