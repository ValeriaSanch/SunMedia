<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\ApiPlatformPrice\ApiPlatformPriceRemover;

use Psr\Log\LoggerInterface;
use SunMedia\Core\Domain\Model\ApiPlatformPrice\ApiPlatformPriceRepository;

class ApiPlatformPriceRemoverCommandHandler
{
    /** @var ApiPlatformPriceRepository */
    private $apiPlatformPriceRepository;

    /** @var LoggerInterface */
    private $logger;

    public function __construct(ApiPlatformPriceRepository $apiPlatformPriceRepository, LoggerInterface $logger)
    {
        $this->apiPlatformPriceRepository = $apiPlatformPriceRepository;
        $this->logger = $logger;
    }

    public function __invoke(ApiPlatformPriceRemoverCommand $command)
    {
        if ($this->apiPlatformPriceRepository->delete($command->removeDates())) {
            $this->logger->info(sprintf(
                'Delete api platform price records (%s)',
                implode(', ', $command->removeDates())
            ));
        }
    }
}
