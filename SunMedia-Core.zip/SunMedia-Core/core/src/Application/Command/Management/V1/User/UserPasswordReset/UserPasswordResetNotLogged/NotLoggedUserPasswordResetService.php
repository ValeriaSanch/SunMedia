<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetNotLogged;

use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Model\User\UserPassword;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Core\Domain\Model\User\UserTokenResetPassword;

class NotLoggedUserPasswordResetService
{
    /** @var UserRepository */
    private $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function execute(User $user, UserPassword $password): void
    {
        $user->updatePassword($user->id(), $password);

        $user->updateTokenResetPassword($user->id(), new UserTokenResetPassword(null));

        $this->userRepository->save($user);
    }
}
