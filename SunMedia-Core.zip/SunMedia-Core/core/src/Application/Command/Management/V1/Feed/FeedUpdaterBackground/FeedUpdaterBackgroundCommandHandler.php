<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedUpdaterBackground;

use SunMedia\Core\Domain\Model\Feed\Exception\InvalidFileType;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmptyValue;

class FeedUpdaterBackgroundCommandHandler
{
    /** @var FeedUpdaterBackgroundValidation */
    private $feedUpdaterValidation;

    /** @var FeedUpdaterBackgroundService */
    private $feedUpdaterService;

    public function __construct(
        FeedUpdaterBackgroundValidation $feedUpdaterValidation,
        FeedUpdaterBackgroundService $feedUpdaterService
    ) {
        $this->feedUpdaterValidation = $feedUpdaterValidation;
        $this->feedUpdaterService = $feedUpdaterService;
    }

    /**
     * @throws DomainException
     * @throws EmptyValue
     * @throws InvalidFileType
     * @throws UserNotFound
     */
    public function __invoke(FeedUpdaterBackgroundCommand $feedUpdaterCommand)
    {
        $this->feedUpdaterService->execute(...$this->feedUpdaterValidation->validate($feedUpdaterCommand));
    }
}
