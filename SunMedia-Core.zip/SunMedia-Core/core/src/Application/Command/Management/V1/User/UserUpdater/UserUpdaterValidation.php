<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserUpdater;

use SunMedia\Core\Domain\Model\Advertiser\Exception\AdvertiserNotFound;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNotFound;
use SunMedia\Core\Domain\Model\Publisher\Exception\PublisherNotFound;
use SunMedia\Core\Domain\Model\SalesforceUser\Exception\SalesforceUserIdNotEmpty;
use SunMedia\Core\Domain\Model\SalesforceUser\Exception\SalesforceUserNotFound;
use SunMedia\Core\Domain\Model\User\Exception\AdvertiserNotBelongsToClient;
use SunMedia\Core\Domain\Model\User\Exception\InvalidUserNameLength;
use SunMedia\Core\Domain\Model\User\Exception\MandatoryParameterNotFound;
use SunMedia\Core\Domain\Model\User\Exception\PublisherNotBelongsToClient;
use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserEnabled;
use SunMedia\Core\Domain\Model\User\UserName;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Core\Domain\Service\Validation\Context\UserContextValidation;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\Email\Email;
use SunMedia\Shared\Domain\Model\Role\Exception\InvalidRole;
use SunMedia\Shared\Domain\Model\Role\Role;
use SunMedia\Shared\Domain\Model\User\UserId;

class UserUpdaterValidation
{
    /** @var UserValidation */
    private $userValidation;

    /** @var UserContextValidation */
    private $userContextValidation;

    public function __construct(UserValidation $userValidation, UserContextValidation $userContextValidation)
    {
        $this->userValidation = $userValidation;
        $this->userContextValidation = $userContextValidation;
    }

    /**
     * @throws AdvertiserNotBelongsToClient
     * @throws AdvertiserNotFound
     * @throws ClientNotFound
     * @throws DomainException
     * @throws EmailNotValid
     * @throws EmptyValue
     * @throws InvalidRole
     * @throws InvalidUserNameLength
     * @throws MandatoryParameterNotFound
     * @throws PublisherNotBelongsToClient
     * @throws PublisherNotFound
     * @throws UserNotFound
     * @throws SalesforceUserIdNotEmpty
     * @throws SalesforceUserNotFound
     */
    public function validate(UserUpdaterCommand $userUpdaterCommand): array
    {
        $author = $this->userValidation->checkAuthor(new UserId($userUpdaterCommand->authorId()));

        $id = new UserId($userUpdaterCommand->id());
        $name = new UserName($userUpdaterCommand->name());
        $email = new Email($userUpdaterCommand->email());
        $enabled = new UserEnabled($userUpdaterCommand->enabled());

        $user = $this->userValidation->ensureUserExists($author, $id);
        if ($user->email()->value() !== $author->email()->value()
            && !in_array($author->role()->value(), [Role::ROLE_ADMIN_SYSTEM, Role::ROLE_ADMIN])
        ) {
            $this->userValidation->ensureEmailNotExists($email);
        }

        $this->userContextValidation->validateContextRoles($author, $userUpdaterCommand->contextRoles());
        $roleUser = new Role($this->userContextValidation->roleUser());

        return [
            $author,
            $user,
            $name,
            $email,
            $enabled,
            $this->userContextValidation->contextRoleCollection(),
            $this->userContextValidation->clientCollection(),
            $this->userContextValidation->advertiserCollection(),
            $this->userContextValidation->salesforceUserCollection(),
            $this->userContextValidation->publisherCollection(),
            $roleUser,
        ];
    }
}
