<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserPasswordReset\UserPasswordResetNotLogged;

use SunMedia\Core\Domain\Model\User\Exception\PasswordTooSimple;
use SunMedia\Core\Domain\Model\User\Exception\UserTokenResetPasswordNotExists;
use SunMedia\Core\Domain\Model\User\UserPassword;
use SunMedia\Core\Domain\Model\User\UserTokenResetPassword;
use SunMedia\Core\Domain\Model\User\UserValidation;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\User\Exception\InvalidUserPassword;
use SunMedia\Shared\Domain\Model\User\Exception\PasswordMismatch;
use SunMedia\Shared\Domain\Model\User\PasswordEncoder;
use SunMedia\Shared\Domain\Model\User\Token\Token;
use SunMedia\Shared\Domain\Model\User\UserTokenValidator;

class NotLoggedUserPasswordResetValidation
{
    /** @var UserValidation */
    private $userValidation;

    /** @var UserTokenValidator */
    private $tokenValidator;

    /** @var PasswordEncoder */
    private $passwordEncoder;

    public function __construct(
        UserValidation $userValidation,
        UserTokenValidator $tokenValidator,
        PasswordEncoder $passwordEncoder
    ) {
        $this->userValidation = $userValidation;
        $this->tokenValidator = $tokenValidator;
        $this->passwordEncoder = $passwordEncoder;
    }

    /**
     * @throws InvalidUserPassword
     * @throws PasswordMismatch
     * @throws UserTokenResetPasswordNotExists
     * @throws PasswordTooSimple
     * @throws EmptyValue
     */
    public function validate(NotLoggedUserPasswordResetCommand $command): array
    {
        if ($command->newPassword1() !== $command->newPassword2()) {
            throw new PasswordMismatch('Passwords are not the same');
        }

        $token = new Token($command->token());
        $userId = $this->tokenValidator->validate($token);

        $tokenPassword = new UserTokenResetPassword($command->token());
        $user = $this->userValidation->checkTokenResetPassword($userId, $tokenPassword);

        $this->userValidation->checkSafePassword($command->newPassword1());
        $userPassword = new UserPassword($this->passwordEncoder->encode($command->newPassword1()));

        return [$user, $userPassword];
    }
}
