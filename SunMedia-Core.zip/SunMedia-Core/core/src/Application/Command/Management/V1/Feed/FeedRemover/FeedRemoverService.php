<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\Feed\FeedRemover;

use SunMedia\Core\Domain\Model\Feed\Feed;
use SunMedia\Core\Domain\Model\Feed\FeedRepository;
use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Shared\Domain\Exception\DomainException;

class FeedRemoverService
{
    /** @var FeedRepository */
    private $feedRepository;

    public function __construct(FeedRepository $feedRepository)
    {
        $this->feedRepository = $feedRepository;
    }

    /**
     * @throws DomainException
     */
    public function execute(User $author, Feed $feed): void
    {
        $feed->remove($author);

        if (file_exists($feed->input()->value())) {
            unlink($feed->input()->value());
        }

        if (file_exists($feed->output()->value())) {
            unlink($feed->output()->value());
        }

        $this->feedRepository->delete($feed);
    }
}
