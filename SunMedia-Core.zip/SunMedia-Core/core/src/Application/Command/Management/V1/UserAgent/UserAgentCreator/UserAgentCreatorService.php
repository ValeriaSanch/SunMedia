<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\UserAgent\UserAgentCreator;

use SunMedia\Core\Domain\Model\Browser\BrowserCriteriaFactory;
use SunMedia\Core\Domain\Model\Browser\BrowserRepository;
use SunMedia\Core\Domain\Model\Device\DeviceCriteriaFactory;
use SunMedia\Core\Domain\Model\Device\DeviceRepository;
use SunMedia\Core\Domain\Model\OperatingSystem\OperatingSystemCriteriaFactory;
use SunMedia\Core\Domain\Model\OperatingSystem\OperatingSystemRepository;
use SunMedia\Core\Domain\Model\UserAgent\UserAgent;
use SunMedia\Core\Domain\Model\UserAgent\UserAgentId;
use SunMedia\Core\Domain\Model\UserAgent\UserAgentName;
use SunMedia\Core\Domain\Model\UserAgent\UserAgentRepository;
use SunMedia\Shared\Domain\Model\Browser\Browser;
use SunMedia\Shared\Domain\Model\Device\Device;
use SunMedia\Shared\Domain\Model\OperatingSystem\OperatingSystem;

class UserAgentCreatorService
{
    /** @var UserAgentRepository */
    private $userAgentRepository;

    /** @var BrowserRepository */
    private $browserRepository;

    /** @var BrowserCriteriaFactory */
    private $browserCriteriaFactory;

    /** @var DeviceRepository */
    private $deviceRepository;

    /** @var DeviceCriteriaFactory */
    private $deviceCriteriaFactory;

    /** @var OperatingSystemRepository */
    private $operatingSystemRepository;

    /** @var OperatingSystemCriteriaFactory */
    private $operatingSystemCriteriaFactory;

    public function __construct(
        UserAgentRepository $userAgentRepository,
        BrowserRepository $browserRepository,
        BrowserCriteriaFactory $browserCriteriaFactory,
        DeviceRepository $deviceRepository,
        DeviceCriteriaFactory $deviceCriteriaFactory,
        OperatingSystemRepository $operatingSystemRepository,
        OperatingSystemCriteriaFactory $operatingSystemCriteriaFactory
    ) {
        $this->userAgentRepository = $userAgentRepository;
        $this->browserRepository = $browserRepository;
        $this->browserCriteriaFactory = $browserCriteriaFactory;
        $this->deviceRepository = $deviceRepository;
        $this->deviceCriteriaFactory = $deviceCriteriaFactory;
        $this->operatingSystemRepository = $operatingSystemRepository;
        $this->operatingSystemCriteriaFactory = $operatingSystemCriteriaFactory;
    }

    public function execute(
        UserAgentId $userAgentId,
        UserAgentName $userAgentName,
        Browser $browser,
        Device $device,
        OperatingSystem $operatingSystem,
        bool $isMobile,
        bool $isTablet,
        bool $isTouchCapable,
        bool $isPc,
        bool $isBot
    ): void {
        $browserCollection = $this->browserRepository->byCriteria($this->browserCriteriaFactory->byFamilyAndVersion(
            $browser->family(),
            $browser->version()
        ));

        if (0 === $browserCollection->count()) {
            $this->browserRepository->save($browser);
        } else {
            $browser = $browserCollection->first();
        }

        $deviceCollection = $this->deviceRepository->byCriteria($this->deviceCriteriaFactory->byFamilyBrandAndModel(
            $device->family(),
            $device->brand(),
            $device->model()
        ));

        if (0 === $deviceCollection->count()) {
            $this->deviceRepository->save($device);
        } else {
            $device = $deviceCollection->first();
        }

        $deviceCollection = $this->deviceRepository->byCriteria($this->deviceCriteriaFactory->byFamilyBrandAndModel(
            $device->family(),
            $device->brand(),
            $device->model()
        ));

        if (0 === $deviceCollection->count()) {
            $this->deviceRepository->save($device);
        } else {
            $device = $deviceCollection->first();
        }

        $operatingSystemCollection = $this->operatingSystemRepository->byCriteria($this->operatingSystemCriteriaFactory->byFamilyAndVersion(
            $operatingSystem->family(),
            $operatingSystem->version()
        ));

        if (0 === $operatingSystemCollection->count()) {
            $this->operatingSystemRepository->save($operatingSystem);
        } else {
            $operatingSystem = $operatingSystemCollection->first();
        }

        $this->userAgentRepository->save(new UserAgent(
            $userAgentId,
            $userAgentName,
            $browser->id(),
            $device->id(),
            $operatingSystem->id(),
            $isMobile,
            $isTablet,
            $isTouchCapable,
            $isPc,
            $isBot
        ));
    }
}
