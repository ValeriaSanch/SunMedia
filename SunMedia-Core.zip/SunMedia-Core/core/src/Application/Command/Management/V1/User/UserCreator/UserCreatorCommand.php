<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Command\Management\V1\User\UserCreator;

use SunMedia\Shared\Domain\Bus\SyncCommand;

class UserCreatorCommand implements SyncCommand
{
    public const ACTION = 'MANAGEMENT_USER_CREATE';

    /** @var string */
    private $id;

    /** @var string */
    private $name;

    /** @var string */
    private $email;

    /** @var string */
    private $authorId;

    /** @var string */
    private $password;

    /** @var array */
    private $contextRoles;

    /** @var bool */
    private $enabled;

    public function __construct(
        string $authorId,
        string $id,
        string $name,
        string $email,
        string $password,
        array $contextRoles,
        bool $enabled
    ) {
        $this->id = $id;
        $this->name = $name;
        $this->email = $email;
        $this->password = $password;
        $this->contextRoles = $contextRoles;
        $this->authorId = $authorId;
        $this->enabled = $enabled;
    }

    public function id(): string
    {
        return $this->id;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function email(): string
    {
        return $this->email;
    }

    public function password(): string
    {
        return $this->password;
    }

    public function authorId(): string
    {
        return $this->authorId;
    }

    public function contextRoles(): array
    {
        return $this->contextRoles;
    }

    public function enabled(): bool
    {
        return $this->enabled;
    }
}
