<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\UserAgent\OperatingSystemList;

use SunMedia\Core\Domain\Model\OperatingSystem\OperatingSystemCriteriaFactory;
use SunMedia\Core\Domain\Model\OperatingSystem\OperatingSystemRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetOperatingSystemListQueryService extends PaginatorService
{
    private $operatingSystemRepository;

    public function __construct(
        OperatingSystemRepository $operatingSystemRepository,
        OperatingSystemCriteriaFactory $operatingSystemCriteriaFactory,
        GetOperatingSystemListDataTransformer $dataTransformer
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->operatingSystemRepository = $operatingSystemRepository;
        $this->criteriaFactory = $operatingSystemCriteriaFactory;
    }

    protected function makeQueryResponse(): GetOperatingSystemListQueryResponse
    {
        return new GetOperatingSystemListQueryResponse(
            $this->operatingSystemRepository->byCriteria($this->defaultCriteria),
            $this->page,
            $this->size,
            $this->operatingSystemRepository->count($this->defaultCriteria),
            $this->fields
        );
    }
}
