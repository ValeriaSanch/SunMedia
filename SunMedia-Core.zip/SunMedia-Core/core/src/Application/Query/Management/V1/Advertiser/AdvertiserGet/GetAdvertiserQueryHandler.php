<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Advertiser\AdvertiserGet;

use SunMedia\Core\Domain\Model\Advertiser\AdvertiserId;
use SunMedia\Core\Domain\Model\Advertiser\Exception\AdvertiserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;

class GetAdvertiserQueryHandler
{
    /** @var GetAdvertiserQueryService */
    private $advertiserQueryService;

    public function __construct(GetAdvertiserQueryService $advertiserQueryService)
    {
        $this->advertiserQueryService = $advertiserQueryService;
    }

    /**
     * @throws AdvertiserNotFound
     * @throws DomainException
     */
    public function __invoke(GetAdvertiserQuery $getAdvertiserQuery): array
    {
        return $this->advertiserQueryService->execute(
            $getAdvertiserQuery->loggedUser(),
            new AdvertiserId($getAdvertiserQuery->advertiserId()),
            $getAdvertiserQuery->includes()
        );
    }
}
