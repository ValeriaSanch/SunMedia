<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Carrier\CarrierGet;

use SunMedia\Core\Domain\Model\Carrier\Carrier;
use SunMedia\Core\Domain\Model\Carrier\CarrierId;
use SunMedia\Core\Domain\Model\Carrier\CarrierRepository;
use SunMedia\Core\Domain\Model\Carrier\Exception\CarrierNotFound;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;

class GetCarrierQueryService
{
    /** @var GetCarrierDataTransformer */
    private $dataTransformer;

    /** @var CarrierRepository */
    private $carrierRepository;

    public function __construct(CarrierRepository $carrierRepository, GetCarrierDataTransformer $dataTransformer)
    {
        $this->dataTransformer = $dataTransformer;
        $this->carrierRepository = $carrierRepository;
    }

    /**
     * @throws CarrierNotFound
     */
    public function execute(CarrierId $carrierId, array $includes): array
    {
        $carrier = $this->getCarrier($carrierId);

        $this->dataTransformer->write(new GetCarrierQueryResponse($carrier, $includes));

        return $this->dataTransformer->read();
    }

    /**
     * @throws CarrierNotFound
     */
    private function getCarrier(CarrierId $carrierId): Carrier
    {
        $carrier = $this->carrierRepository->byId($carrierId, new Criteria());

        if (is_null($carrier)) {
            throw new CarrierNotFound($carrierId);
        }

        return $carrier;
    }
}
