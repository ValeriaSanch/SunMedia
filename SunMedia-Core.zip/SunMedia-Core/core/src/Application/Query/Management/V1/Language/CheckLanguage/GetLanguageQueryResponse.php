<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Language\CheckLanguage;

use SunMedia\Shared\Domain\Bus\SingleResourceResponse;
use SunMedia\Shared\Domain\Model\Language\Language;

class GetLanguageQueryResponse implements SingleResourceResponse
{
    /** @var Language */
    private $resource;

    /** @var array */
    private $includes;

    public function __construct(Language $language, array $includes)
    {
        $this->resource = $language;
        $this->includes = $includes;
    }

    public function resource(): Language
    {
        return $this->resource;
    }

    public function includes(): array
    {
        return $this->includes;
    }
}
