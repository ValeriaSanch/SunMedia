<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Carrier\CarrierGet;

use SunMedia\Shared\Application\Query\QuerySingleResource;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class GetCarrierQuery extends QuerySingleResource
{
    public const ACTION = 'MANAGEMENT_CARRIER_SHOW';

    /** @var string */
    private $carrierId;

    public function __construct(?SecurityUser $loggedUser, string $carrierId, array $includes)
    {
        parent::__construct($loggedUser, $includes);
        $this->carrierId = $carrierId;
        $this->includes = $includes;
    }

    public function carrierId(): string
    {
        return $this->carrierId;
    }
}
