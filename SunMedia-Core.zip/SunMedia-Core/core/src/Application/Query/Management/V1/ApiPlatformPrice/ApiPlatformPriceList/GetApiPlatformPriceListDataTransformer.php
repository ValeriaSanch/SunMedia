<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\ApiPlatformPrice\ApiPlatformPriceList;

use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetApiPlatformPriceListDataTransformer implements ResponseDataTransformer
{
    /** @var GetApiPlatformPriceListQueryResponse */
    private $getApiPlatformPriceListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getApiPlatformPriceListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        $apiPlatformPrices['data'] = $this->getApiPlatformPriceListQueryResponse->array();
        $apiPlatformPrices['meta'] = [
            'totalPages' => ceil($this->getApiPlatformPriceListQueryResponse->totalResults() / $this->getApiPlatformPriceListQueryResponse->size()),
            'totalResults' => $this->getApiPlatformPriceListQueryResponse->totalResults(),
            'size' => $this->getApiPlatformPriceListQueryResponse->size(),
        ];

        return $apiPlatformPrices;
    }
}
