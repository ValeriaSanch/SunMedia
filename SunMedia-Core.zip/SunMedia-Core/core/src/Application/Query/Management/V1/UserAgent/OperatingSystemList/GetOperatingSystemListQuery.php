<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\UserAgent\OperatingSystemList;

use SunMedia\Shared\Application\Query\QueryPaginator;

class GetOperatingSystemListQuery extends QueryPaginator
{
    public const ACTION = 'MANAGEMENT_OPERATING_SYSTEM_SHOW_LIST';

    protected function setDefaultOrder(): void
    {
        $this->orderType = 'asc';
        $this->orderBy = 'family';
    }

    protected function availableOrders(): array
    {
        return ['family'];
    }
}
