<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\UserAgent\DeviceList;

class GetDeviceListQueryHandler
{
    private $getDeviceListQueryService;

    public function __construct(GetDeviceListQueryService $getDeviceListQueryService)
    {
        $this->getDeviceListQueryService = $getDeviceListQueryService;
    }

    public function __invoke(GetDeviceListQuery $getUserQuery): array
    {
        return $this->getDeviceListQueryService->execute(
            $getUserQuery->loggedUser(),
            $getUserQuery->filters(),
            $getUserQuery->page(),
            $getUserQuery->size(),
            $getUserQuery->getIncludes(),
            $getUserQuery->getOrder(),
            $getUserQuery->query()
        );
    }
}
