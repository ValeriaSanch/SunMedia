<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Advertiser\AdvertiserGet;

use SunMedia\Core\Domain\Model\Advertiser\Advertiser;
use SunMedia\Shared\Domain\Bus\SingleResourceResponse;

class GetAdvertiserQueryResponse implements SingleResourceResponse
{
    /** @var Advertiser */
    private $resource;

    /** @var array */
    private $includes;

    public function __construct(Advertiser $advertiser, array $includes)
    {
        $this->resource = $advertiser;
        $this->includes = $includes;
    }

    public function resource(): Advertiser
    {
        return $this->resource;
    }

    public function includes(): array
    {
        return $this->includes;
    }
}
