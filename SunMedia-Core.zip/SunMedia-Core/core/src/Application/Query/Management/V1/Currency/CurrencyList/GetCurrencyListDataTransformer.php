<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Currency\CurrencyList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiCurrencyTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetCurrencyListDataTransformer extends JsonApiDataTransformer implements ResponseDataTransformer
{
    /** @var GetCurrencyListQueryResponse */
    private $getCurrencyListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getCurrencyListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getCurrencyListQueryResponse->currencies()->toArray(),
            new JsonApiCurrencyTransformer(),
            'currencies'
        );
    }
}
