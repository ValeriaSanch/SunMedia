<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\SalesforceUserList;

class GetSalesforceUserListQueryHandler
{
    /** @var GetSalesforceUserListQueryService */
    private $getSalesforceUserListQueryService;

    public function __construct(GetSalesforceUserListQueryService $getSalesforceUserListQueryService)
    {
        $this->getSalesforceUserListQueryService = $getSalesforceUserListQueryService;
    }

    public function __invoke(GetSalesforceUserListQuery $getUserQuery): array
    {
        return $this->getSalesforceUserListQueryService->execute(
            $getUserQuery->loggedUser(),
            $getUserQuery->filters(),
            $getUserQuery->page(),
            $getUserQuery->size(),
            $getUserQuery->getIncludes(),
            $getUserQuery->getOrder(),
            $getUserQuery->query()
        );
    }
}
