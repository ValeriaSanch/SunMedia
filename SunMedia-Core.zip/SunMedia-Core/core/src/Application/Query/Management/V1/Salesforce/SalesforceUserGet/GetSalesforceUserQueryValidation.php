<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\SalesforceUserGet;

use SunMedia\Core\Domain\Model\SalesforceUser\Exception\SalesforceUserNotFound;
use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUserValidation;
use SunMedia\Shared\Domain\Model\SalesforceUser\SalesforceUserId;

class GetSalesforceUserQueryValidation
{
    /** @var SalesforceUserValidation */
    private $salesforceUserValidation;

    public function __construct(SalesforceUserValidation $salesforceUserValidation)
    {
        $this->salesforceUserValidation = $salesforceUserValidation;
    }

    /**
     * @throws SalesforceUserNotFound
     */
    public function validate(GetSalesforceUserQuery $getSalesforceUserQuery): array
    {
        $salesforceUser = $this->salesforceUserValidation->checkUserSalesforceId(
            new SalesforceUserId($getSalesforceUserQuery->salesforceUserId())
        );

        return [$salesforceUser, $getSalesforceUserQuery->includes()];
    }
}
