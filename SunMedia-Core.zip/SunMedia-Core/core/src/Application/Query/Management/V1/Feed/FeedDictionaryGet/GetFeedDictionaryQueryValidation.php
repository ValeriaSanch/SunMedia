<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Feed\FeedDictionaryGet;

use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileEmpty;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidFileType;
use SunMedia\Core\Domain\Model\Feed\FeedType;
use SunMedia\Core\Domain\Model\Feed\FeedUrl;
use SunMedia\Shared\Domain\Exception\EmptyValue;

class GetFeedDictionaryQueryValidation
{
    /**
     * @throws EmptyValue
     * @throws FeedFileEmpty
     * @throws FeedFileNotFound
     * @throws InvalidFileType
     */
    public function validate(GetFeedDictionaryQuery $feedDictionaryQuery): array
    {
        return [new FeedUrl($feedDictionaryQuery->url()), new FeedType($feedDictionaryQuery->type())];
    }
}
