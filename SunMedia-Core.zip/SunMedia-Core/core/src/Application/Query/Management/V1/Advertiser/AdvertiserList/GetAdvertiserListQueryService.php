<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Advertiser\AdvertiserList;

use SunMedia\Core\Domain\Model\Advertiser\AdvertiserCriteriaFactory;
use SunMedia\Core\Domain\Model\Advertiser\AdvertiserRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetAdvertiserListQueryService extends PaginatorService
{
    /** @var AdvertiserRepository */
    private $advertiserRepository;

    public function __construct(
        AdvertiserRepository $advertiserRepository,
        GetAdvertiserListDataTransformer $advertiserDataTransformer,
        AdvertiserCriteriaFactory $criteriaFactory
    ) {
        $this->advertiserRepository = $advertiserRepository;
        $this->dataTransformer = $advertiserDataTransformer;
        $this->criteriaFactory = $criteriaFactory;
    }

    protected function makeQueryResponse(): GetAdvertiserListQueryResponse
    {
        return new GetAdvertiserListQueryResponse(
            $this->advertiserRepository->byCriteria($this->defaultCriteria),
            $this->page,
            $this->size,
            $this->advertiserRepository->count($this->defaultCriteria),
            $this->fields
        );
    }
}
