<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\UserAgent\BrowserList;

use SunMedia\Shared\Application\Query\QueryPaginator;

class GetBrowserListQuery extends QueryPaginator
{
    public const ACTION = 'MANAGEMENT_BROWSER_SHOW_LIST';

    protected function setDefaultOrder(): void
    {
        $this->orderType = 'asc';
        $this->orderBy = 'family';
    }

    protected function availableOrders(): array
    {
        return ['family'];
    }
}
