<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\UserAgent\DeviceList;

use SunMedia\Core\Domain\Model\Device\DeviceCriteriaFactory;
use SunMedia\Core\Domain\Model\Device\DeviceRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetDeviceListQueryService extends PaginatorService
{
    private $deviceRepository;

    public function __construct(
        DeviceRepository $deviceRepository,
        DeviceCriteriaFactory $deviceCriteriaFactory,
        GetDeviceListDataTransformer $dataTransformer
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->deviceRepository = $deviceRepository;
        $this->criteriaFactory = $deviceCriteriaFactory;
    }

    protected function makeQueryResponse(): GetDeviceListQueryResponse
    {
        return new GetDeviceListQueryResponse(
            $this->deviceRepository->byCriteria($this->defaultCriteria),
            $this->page,
            $this->size,
            $this->deviceRepository->count($this->defaultCriteria),
            $this->fields
        );
    }
}
