<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Publisher\PublisherGet;

use SunMedia\Core\Domain\Model\Publisher\Exception\PublisherNotFound;
use SunMedia\Core\Domain\Model\Publisher\Publisher;
use SunMedia\Core\Domain\Model\Publisher\PublisherCriteriaFactory;
use SunMedia\Core\Domain\Model\Publisher\PublisherId;
use SunMedia\Core\Domain\Model\Publisher\PublisherRepository;
use SunMedia\Core\Domain\Model\User\User;

class GetPublisherQueryService
{
    /** @var PublisherRepository */
    private $publisherRepository;

    /** @var GetPublisherDataTransformer */
    private $dataTransformer;

    /** @var PublisherCriteriaFactory */
    private $publisherCriteriaFactory;

    public function __construct(
        PublisherRepository $publisherRepository,
        GetPublisherDataTransformer $dataTransformer,
        PublisherCriteriaFactory $publisherCriteriaFactory
    ) {
        $this->publisherRepository = $publisherRepository;
        $this->dataTransformer = $dataTransformer;
        $this->publisherCriteriaFactory = $publisherCriteriaFactory;
    }

    /**
     * @throws PublisherNotFound
     */
    public function execute(User $loggedUser, PublisherId $publisherId, array $includes): array
    {
        $publisher = $this->getPublisherForUser($publisherId, $loggedUser);

        $this->dataTransformer->write(new GetPublisherQueryResponse($publisher, $includes));

        return $this->dataTransformer->read();
    }

    /**
     * @throws PublisherNotFound
     */
    private function getPublisherForUser(PublisherId $publisherId, User $user): Publisher
    {
        $publisher = $this->publisherRepository->byId(
            $publisherId,
            $this->publisherCriteriaFactory->getUserCriteria($user)
        );

        if (null === $publisher) {
            throw new PublisherNotFound($publisherId);
        }

        return $publisher;
    }
}
