<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\AccountGet;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiSalesforceAccountTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiResourceDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetSalesforceAccountDataTransformer extends JsonApiResourceDataTransformer implements ResponseDataTransformer
{
    /** @var GetSalesforceAccountQueryResponse */
    private $getClientResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getClientResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getClientResponse,
            new JsonApiSalesforceAccountTransformer(),
            'salesforce-accounts'
        );
    }
}
