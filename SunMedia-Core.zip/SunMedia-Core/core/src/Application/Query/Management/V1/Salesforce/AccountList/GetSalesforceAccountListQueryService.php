<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\AccountList;

use SunMedia\Core\Domain\Model\SalesforceAccount\SalesforceAccountCriteriaFactory;
use SunMedia\Core\Domain\Model\SalesforceAccount\SalesforceAccountRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetSalesforceAccountListQueryService extends PaginatorService
{
    /** @var SalesforceAccountRepository */
    private $salesforceAccountRepository;

    public function __construct(
        SalesforceAccountRepository $salesforceAccountRepository,
        GetSalesforceAccountListDataTransformer $dataTransformer,
        SalesforceAccountCriteriaFactory $salesforceAccountCriteriaFactory
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->salesforceAccountRepository = $salesforceAccountRepository;
        $this->criteriaFactory = $salesforceAccountCriteriaFactory;
    }

    protected function makeQueryResponse(): GetSalesforceAccountListQueryResponse
    {
        return new GetSalesforceAccountListQueryResponse(
            $this->salesforceAccountRepository->byCriteria($this->defaultCriteria),
            $this->page,
            $this->size,
            $this->salesforceAccountRepository->count($this->defaultCriteria),
            $this->fields
        );
    }
}
