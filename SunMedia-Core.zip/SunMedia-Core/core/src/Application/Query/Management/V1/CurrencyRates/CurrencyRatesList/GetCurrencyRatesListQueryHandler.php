<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\CurrencyRates\CurrencyRatesList;

use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Exception\InvalidArgumentDate;
use SunMedia\Shared\Domain\Exception\InvalidArgumentNotFound;

class GetCurrencyRatesListQueryHandler
{
    /** @var GetCurrencyRatesListQueryService */
    private $getCurrencyRatesListQueryService;

    /** @var GetCurrencyRatesListValidation */
    private $getCurrencyRatesListValidation;

    public function __construct(
        GetCurrencyRatesListQueryService $getCurrencyRatesListQueryService,
        GetCurrencyRatesListValidation $getCurrencyRatesListValidation
    ) {
        $this->getCurrencyRatesListQueryService = $getCurrencyRatesListQueryService;
        $this->getCurrencyRatesListValidation = $getCurrencyRatesListValidation;
    }

    /**
     * @throws EmptyValue
     * @throws InvalidArgumentDate
     * @throws InvalidArgumentNotFound
     */
    public function __invoke(GetCurrencyRatesListQuery $getCurrencyRatesListQuery): array
    {
        return $this->getCurrencyRatesListQueryService->execute(
            ...$this->getCurrencyRatesListValidation->validate($getCurrencyRatesListQuery)
        );
    }
}
