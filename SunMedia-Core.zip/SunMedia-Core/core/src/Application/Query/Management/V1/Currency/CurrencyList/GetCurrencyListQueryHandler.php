<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Currency\CurrencyList;

class GetCurrencyListQueryHandler
{
    /** @var GetCurrencyListQueryService */
    private $service;

    public function __construct(GetCurrencyListQueryService $service)
    {
        $this->service = $service;
    }

    public function __invoke(GetCurrencyListQuery $query): array
    {
        return $this->service->execute();
    }
}
