<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\CurrencyRates\CurrencyRatesList;

use Exception;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Exception\InvalidArgumentDate;
use SunMedia\Shared\Domain\Exception\InvalidArgumentNotFound;
use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRate;
use SunMedia\Shared\Infrastructure\Delivery\Http\Request;
use SunMedia\Shared\Infrastructure\Service\DateRangeService;
use SunMedia\Shared\Infrastructure\Service\DetectDelimiterCsv;

class GetCurrencyRatesListValidation
{
    /**
     * @throws EmptyValue
     * @throws InvalidArgumentDate
     * @throws InvalidArgumentNotFound
     */
    public function validate(GetCurrencyRatesListQuery $getCurrencyRatesListQuery): array
    {
        return [
            $getCurrencyRatesListQuery->loggedUser(),
            $this->validateFilter($getCurrencyRatesListQuery->filters()),
            $getCurrencyRatesListQuery->page(),
            $getCurrencyRatesListQuery->size(),
            $getCurrencyRatesListQuery->getIncludes(),
            $getCurrencyRatesListQuery->getOrder(),
            $getCurrencyRatesListQuery->query(),
        ];
    }

    /**
     * @throws EmptyValue
     * @throws Exception
     * @throws InvalidArgumentDate
     * @throws InvalidArgumentNotFound
     */
    private function validateFilter(array $filters): array
    {
        $validateFilter = [
            CurrencyRate::COLUMN_CURRENCY_BASE,
            CurrencyRate::COLUMN_CURRENCY_DESTINATION,
            CurrencyRate::COLUMN_DATE,
        ];

        foreach ($validateFilter as $value) {
            if (empty($filters[$value])) {
                if (!isset($filters[$value])) {
                    throw new InvalidArgumentNotFound(sprintf('filter[%s]', $value));
                }

                throw new EmptyValue(sprintf('filter[%s]', $value));
            }
        }

        $date = array_filter(array_unique(explode(
            DetectDelimiterCsv::DELIMITER_SEMICOLON,
            $filters[CurrencyRate::COLUMN_DATE]
        )));

        foreach ($date as $value) {
            Request::validateDate(sprintf('filter[%s]', CurrencyRate::COLUMN_DATE), $value);
        }

        if (count($date) > 1) {
            DateRangeService::orderCorrectDateRange($date[0], $date[1]);
            $filters[CurrencyRate::COLUMN_DATE] = implode(DetectDelimiterCsv::DELIMITER_SEMICOLON, $date);
        }

        return $filters;
    }
}
