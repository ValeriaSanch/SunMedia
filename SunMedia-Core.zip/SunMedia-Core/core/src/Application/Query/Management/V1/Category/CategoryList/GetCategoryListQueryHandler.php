<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\CategoryList;

use ReflectionException;

class GetCategoryListQueryHandler
{
    /** @var GetCategoryListQueryService */
    private $service;

    public function __construct(GetCategoryListQueryService $service)
    {
        $this->service = $service;
    }

    /**
     * @throws ReflectionException
     */
    public function __invoke(GetCategoryListQuery $query): array
    {
        return $this->service->execute();
    }
}
