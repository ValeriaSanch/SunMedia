<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\SalesforceUserList;

use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUserName;
use SunMedia\Shared\Application\Query\QueryPaginator;
use SunMedia\Shared\Domain\Criteria\OrderType;

class GetSalesforceUserListQuery extends QueryPaginator
{
    public const ACTION = 'MANAGEMENT_SALESFORCE_USER_SHOW_LIST';

    protected function setDefaultOrder(): void
    {
        $this->orderType = OrderType::ASC;
        $this->orderBy = SalesforceUserName::COLUMN;
    }

    protected function availableOrders(): array
    {
        return [SalesforceUserName::COLUMN];
    }
}
