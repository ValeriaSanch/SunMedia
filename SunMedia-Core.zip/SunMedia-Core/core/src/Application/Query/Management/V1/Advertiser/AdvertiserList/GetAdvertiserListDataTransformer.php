<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Advertiser\AdvertiserList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiAdvertiserTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiPaginatorDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetAdvertiserListDataTransformer extends JsonApiPaginatorDataTransformer implements ResponseDataTransformer
{
    /** @var GetAdvertiserListQueryResponse */
    private $getClientListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getClientListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getClientListQueryResponse,
            new JsonApiAdvertiserTransformer(),
            'advertisers'
        );
    }
}
