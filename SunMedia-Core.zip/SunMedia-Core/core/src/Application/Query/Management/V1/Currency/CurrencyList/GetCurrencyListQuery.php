<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Currency\CurrencyList;

class GetCurrencyListQuery
{
}
