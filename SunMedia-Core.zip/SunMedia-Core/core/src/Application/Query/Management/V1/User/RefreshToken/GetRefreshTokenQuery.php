<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\RefreshToken;

class GetRefreshTokenQuery
{
    /** @var string */
    private $refreshToken;

    public function __construct(string $refreshToken)
    {
        $this->refreshToken = $refreshToken;
    }

    public function refreshToken(): string
    {
        return $this->refreshToken;
    }
}
