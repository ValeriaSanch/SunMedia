<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\AccountGet;

use SunMedia\Core\Domain\Model\SalesforceAccount\Exception\SalesforceAccountNotFound;
use SunMedia\Core\Domain\Model\SalesforceAccount\SalesforceAccountId;

class GetSalesforceAccountQueryHandler
{
    /** @var GetSalesforceAccountQueryService */
    private $getClientQueryService;

    public function __construct(GetSalesforceAccountQueryService $getClientQueryService)
    {
        $this->getClientQueryService = $getClientQueryService;
    }

    /**
     * @throws SalesforceAccountNotFound
     */
    public function __invoke(GetSalesforceAccountQuery $getAccountQuery): array
    {
        return $this->getClientQueryService->execute(
            new SalesforceAccountId($getAccountQuery->accountId()),
            $getAccountQuery->includes()
        );
    }
}
