<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\CategoryGet;

use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Shared\Application\Query\QuerySingleResource;

final class GetCategoryQuery extends QuerySingleResource
{
    public const ACTION = 'MANAGEMENT_CATEGORY_SHOW';

    /** @var string */
    private $categoryId;

    public function __construct(User $loggedUser, string $categoryId, array $include)
    {
        parent::__construct($loggedUser, $include);
        $this->categoryId = $categoryId;
    }

    public function categoryId(): string
    {
        return $this->categoryId;
    }
}
