<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Advertiser\AdvertiserGet;

use SunMedia\Shared\Application\Query\QuerySingleResource;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class GetAdvertiserQuery extends QuerySingleResource
{
    public const ACTION = 'MANAGEMENT_ADVERTISER_SHOW';

    /** @var string */
    private $advertiserId;

    public function __construct(SecurityUser $loggedUser, string $advertiserId, array $includes)
    {
        parent::__construct($loggedUser, $includes);
        $this->advertiserId = $advertiserId;
    }

    public function advertiserId(): string
    {
        return $this->advertiserId;
    }
}
