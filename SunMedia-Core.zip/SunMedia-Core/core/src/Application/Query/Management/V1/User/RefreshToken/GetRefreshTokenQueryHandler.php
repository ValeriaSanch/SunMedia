<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\RefreshToken;

use SunMedia\Shared\Domain\Model\User\Token\Exception\ExpiredRefreshToken;
use SunMedia\Shared\Domain\Model\User\Token\Token;

class GetRefreshTokenQueryHandler
{
    /** @var GetRefreshTokenQueryService */
    private $getRefreshTokenQueryService;

    public function __construct(GetRefreshTokenQueryService $getRefreshTokenQueryService)
    {
        $this->getRefreshTokenQueryService = $getRefreshTokenQueryService;
    }

    /**
     * @throws ExpiredRefreshToken
     */
    public function __invoke(GetRefreshTokenQuery $getRefreshTokenQuery): array
    {
        return $this->getRefreshTokenQueryService->execute(new Token($getRefreshTokenQuery->refreshToken()));
    }
}
