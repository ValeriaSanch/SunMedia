<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Client\ClientGet;

use SunMedia\Core\Domain\Model\Client\Client;
use SunMedia\Core\Domain\Model\Client\ClientCriteriaFactory;
use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Core\Domain\Model\Client\ClientRepository;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNotFound;
use SunMedia\Core\Domain\Model\User\User;

class GetClientQueryService
{
    /** @var ClientRepository */
    private $clientRepository;

    /** @var GetClientDataTransformer */
    private $dataTransformer;

    /** @var ClientCriteriaFactory */
    private $clientCriteriaFactory;

    public function __construct(
        ClientRepository $clientRepository,
        GetClientDataTransformer $dataTransformer,
        ClientCriteriaFactory $clientCriteriaFactory
    ) {
        $this->clientRepository = $clientRepository;
        $this->dataTransformer = $dataTransformer;
        $this->clientCriteriaFactory = $clientCriteriaFactory;
    }

    /**
     * @throws ClientNotFound
     */
    public function execute(User $loggedUser, ClientId $clientId, array $includes): array
    {
        $client = $this->getClientForUser($clientId, $loggedUser);

        $this->dataTransformer->write(new GetClientQueryResponse($client, $includes));

        return $this->dataTransformer->read();
    }

    /**
     * @throws ClientNotFound
     */
    private function getClientForUser(ClientId $clientId, User $loggedUser): Client
    {
        $client = $this->clientRepository->byId($clientId, $this->clientCriteriaFactory->getUserCriteria($loggedUser));

        if (true === is_null($client)) {
            throw new ClientNotFound($clientId);
        }

        return $client;
    }
}
