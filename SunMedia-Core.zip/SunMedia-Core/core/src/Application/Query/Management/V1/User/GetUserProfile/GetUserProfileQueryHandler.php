<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\GetUserProfile;

class GetUserProfileQueryHandler
{
    /** @var GetUserProfileQueryService */
    private $getUserQueryService;

    public function __construct(GetUserProfileQueryService $getUserQueryService)
    {
        $this->getUserQueryService = $getUserQueryService;
    }

    public function __invoke(GetUserProfileQuery $getUserQuery): array
    {
        return $this->getUserQueryService->execute($getUserQuery->loggedUser());
    }
}
