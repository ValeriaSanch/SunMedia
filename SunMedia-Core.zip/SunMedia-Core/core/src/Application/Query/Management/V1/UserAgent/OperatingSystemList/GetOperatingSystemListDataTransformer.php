<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\UserAgent\OperatingSystemList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiOperatingSystemTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiPaginatorDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetOperatingSystemListDataTransformer extends JsonApiPaginatorDataTransformer implements ResponseDataTransformer
{
    /** @var GetOperatingSystemListQueryResponse */
    private $getOperatingSystemListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getOperatingSystemListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getOperatingSystemListQueryResponse,
            new JsonApiOperatingSystemTransformer(),
            'operating-systems'
        );
    }
}
