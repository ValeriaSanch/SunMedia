<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\SalesforceUserList;

use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUserCollection;
use SunMedia\Shared\Domain\Bus\PaginatorResponse;
use SunMedia\Shared\Domain\Bus\QueryResponse;
use SunMedia\Shared\Domain\Collection\AbstractCollection;
use SunMedia\Shared\Domain\Criteria\FieldCollection;

class GetSalesforceUserListQueryResponse implements QueryResponse, PaginatorResponse
{
    private $collection;

    /** @var int */
    private $page;

    /** @var int */
    private $itemsPerPage;

    /** @var int */
    private $totalResults;

    /** @var null|FieldCollection */
    private $includes;

    public function __construct(
        SalesforceUserCollection $salesforceUserCollection,
        int $page,
        int $itemsPerPage,
        int $totalResults,
        ?FieldCollection $includes = null
    ) {
        $this->collection = $salesforceUserCollection;
        $this->page = $page;
        $this->itemsPerPage = $itemsPerPage;
        $this->totalResults = $totalResults;
        $this->includes = $includes;
    }

    public function collection(): AbstractCollection
    {
        return $this->collection;
    }

    public function page(): int
    {
        return $this->page;
    }

    public function size(): int
    {
        return $this->itemsPerPage;
    }

    public function totalResults(): int
    {
        return $this->totalResults;
    }

    public function includes(): FieldCollection
    {
        return $this->includes;
    }
}
