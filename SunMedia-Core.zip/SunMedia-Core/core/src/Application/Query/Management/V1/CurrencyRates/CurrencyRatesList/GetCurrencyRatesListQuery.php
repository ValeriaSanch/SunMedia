<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\CurrencyRates\CurrencyRatesList;

use SunMedia\Shared\Application\Query\QueryPaginator;
use SunMedia\Shared\Domain\Criteria\OrderType;
use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRate;
use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRateId;

class GetCurrencyRatesListQuery extends QueryPaginator
{
    public const ACTION = '';

    protected function setDefaultOrder(): void
    {
        $this->orderType = OrderType::ASC;
        $this->orderBy = CurrencyRate::COLUMN_DATE;
    }

    protected function availableOrders(): array
    {
        return [CurrencyRateId::COLUMN, CurrencyRate::COLUMN_DATE];
    }
}
