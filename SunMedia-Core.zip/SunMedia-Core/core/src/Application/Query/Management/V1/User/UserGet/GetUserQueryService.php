<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\UserGet;

use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Core\Domain\Model\User\UserCriteriaFactory;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Shared\Domain\Model\User\UserId;

class GetUserQueryService
{
    /** @var UserRepository */
    private $userRepository;

    /** @var GetUserDataTransformer */
    private $dataTransformer;

    private $userCriteriaFactory;

    public function __construct(
        UserRepository $userRepository,
        UserCriteriaFactory $userCriteriaFactory,
        GetUserDataTransformer $dataTransformer
    ) {
        $this->userRepository = $userRepository;
        $this->dataTransformer = $dataTransformer;
        $this->userCriteriaFactory = $userCriteriaFactory;
    }

    /**
     * @throws UserNotFound
     */
    public function execute(User $loggedUser, UserId $userId, array $includes): array
    {
        $user = $this->getUser($loggedUser, $userId);

        $this->dataTransformer->write(new GetUserQueryResponse($user, $includes));

        return $this->dataTransformer->read();
    }

    /**
     * @throws UserNotFound
     */
    private function getUser(User $loggedUser, UserId $userId): User
    {
        $user = $this->userRepository->byId($userId, $this->userCriteriaFactory->getUserCriteria($loggedUser));

        if (null === $user) {
            throw new UserNotFound($userId);
        }

        return $user;
    }
}
