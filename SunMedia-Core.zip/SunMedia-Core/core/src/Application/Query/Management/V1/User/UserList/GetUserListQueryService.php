<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\UserList;

use SunMedia\Core\Domain\Model\User\UserCriteriaFactory;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetUserListQueryService extends PaginatorService
{
    /** @var UserRepository */
    private $userRepository;

    public function __construct(
        UserRepository $userRepository,
        GetUserListDataTransformer $dataTransformer,
        UserCriteriaFactory $userCriteriaFactory
    ) {
        $this->userRepository = $userRepository;
        $this->dataTransformer = $dataTransformer;
        $this->criteriaFactory = $userCriteriaFactory;
    }

    protected function makeQueryResponse(): GetUserListQueryResponse
    {
        $criteria = $this->criteriaFactory->createByClient(
            $this->loggedUser,
            $this->filters,
            $this->order,
            $this->query,
            $this->page,
            $this->size
        );

        return new GetUserListQueryResponse(
            $this->userRepository->byCriteria($criteria),
            $this->page,
            $this->size,
            $this->userRepository->count($criteria),
            $this->fields
        );
    }
}
