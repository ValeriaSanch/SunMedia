<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Feed\FeedDictionaryGet;

class GetFeedDictionaryQuery
{
    public const ACTION = 'MANAGEMENT_FEED_DICTIONARY';

    /** @var string */
    private $url;

    /** @var string */
    private $type;

    public function __construct(string $url, string $type)
    {
        $this->url = $url;
        $this->type = $type;
    }

    public function url(): string
    {
        return $this->url;
    }

    public function type(): string
    {
        return $this->type;
    }
}
