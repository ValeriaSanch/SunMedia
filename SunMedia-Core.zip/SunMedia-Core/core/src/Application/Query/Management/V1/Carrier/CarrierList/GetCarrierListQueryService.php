<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Carrier\CarrierList;

use SunMedia\Core\Domain\Model\Carrier\CarrierCriteriaFactory;
use SunMedia\Core\Domain\Model\Carrier\CarrierRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetCarrierListQueryService extends PaginatorService
{
    /** @var CarrierRepository */
    private $carrierRepository;

    public function __construct(
        CarrierRepository $carrierRepository,
        GetCarrierListDataTransformer $dataTransformer,
        CarrierCriteriaFactory $carrierCriteriaFactory
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->carrierRepository = $carrierRepository;
        $this->criteriaFactory = $carrierCriteriaFactory;
    }

    protected function makeQueryResponse(): GetCarrierListQueryResponse
    {
        return new GetCarrierListQueryResponse(
            $this->carrierRepository->byCriteria($this->defaultCriteria),
            $this->page,
            $this->size,
            $this->carrierRepository->count($this->defaultCriteria),
            $this->fields
        );
    }
}
