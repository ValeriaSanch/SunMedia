<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Country\CountryList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiCountryTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiPaginatorDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetCountryListDataTransformer extends JsonApiPaginatorDataTransformer implements ResponseDataTransformer
{
    /** @var GetCountryListQueryResponse */
    private $getCountryListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getCountryListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getCountryListQueryResponse,
            new JsonApiCountryTransformer(),
            'countries'
        );
    }
}
