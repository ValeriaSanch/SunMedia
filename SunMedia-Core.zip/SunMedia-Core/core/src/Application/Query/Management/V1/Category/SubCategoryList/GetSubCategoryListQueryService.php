<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\SubCategoryList;

use SunMedia\Shared\Domain\Model\Category\CategoryId;
use SunMedia\Shared\Domain\Model\Category\CategoryRepository;

class GetSubCategoryListQueryService
{
    /** @var CategoryRepository */
    private $categoryRepository;

    /** @var GetSubCategoryListDataTransformer */
    private $dataTransformer;

    public function __construct(
        CategoryRepository $categoryRepository,
        GetSubCategoryListDataTransformer $dataTransformer
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->categoryRepository = $categoryRepository;
    }

    public function execute(CategoryId $category): array
    {
        $categories = $this->categoryRepository->subcategoriesByCategory($category);

        $this->dataTransformer->write(new GetSubCategoryListQueryResponse($categories));

        return $this->dataTransformer->read();
    }
}
