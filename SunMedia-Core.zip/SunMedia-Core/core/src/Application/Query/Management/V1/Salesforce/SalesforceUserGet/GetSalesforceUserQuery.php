<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\SalesforceUserGet;

use SunMedia\Shared\Application\Query\QuerySingleResource;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class GetSalesforceUserQuery extends QuerySingleResource
{
    public const ACTION = 'MANAGEMENT_SALESFORCE_USER_SHOW';

    /** @var string */
    private $salesforceUserId;

    public function __construct(SecurityUser $loggedUser, string $salesforceUserId, array $include)
    {
        parent::__construct($loggedUser, $include);
        $this->salesforceUserId = $salesforceUserId;
    }

    public function salesforceUserId(): string
    {
        return $this->salesforceUserId;
    }
}
