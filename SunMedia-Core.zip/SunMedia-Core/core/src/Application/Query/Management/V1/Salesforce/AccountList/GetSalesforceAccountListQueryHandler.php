<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\AccountList;

class GetSalesforceAccountListQueryHandler
{
    /** @var GetSalesforceAccountListQueryService */
    private $getSalesforceListQueryService;

    public function __construct(GetSalesforceAccountListQueryService $getClientListQueryService)
    {
        $this->getSalesforceListQueryService = $getClientListQueryService;
    }

    public function __invoke(GetSalesforceAccountListQuery $getAccountQuery): array
    {
        return $this->getSalesforceListQueryService->execute(
            $getAccountQuery->loggedUser(),
            $getAccountQuery->filters(),
            $getAccountQuery->page(),
            $getAccountQuery->size(),
            $getAccountQuery->getIncludes(),
            $getAccountQuery->getOrder(),
            $getAccountQuery->query()
        );
    }
}
