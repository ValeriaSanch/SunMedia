<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\UserGet;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiUserTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiResourceDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetUserDataTransformer extends JsonApiResourceDataTransformer implements ResponseDataTransformer
{
    /** @var GetUserQueryResponse */
    private $getUserQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getUserQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getUserQueryResponse,
            new JsonApiUserTransformer(),
            'users'
        );
    }
}
