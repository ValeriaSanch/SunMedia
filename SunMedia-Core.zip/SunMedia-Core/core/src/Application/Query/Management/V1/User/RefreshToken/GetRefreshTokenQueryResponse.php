<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\RefreshToken;

use SunMedia\Shared\Domain\Bus\QueryResponse;
use SunMedia\Shared\Domain\Model\User\Token\RefreshToken;
use SunMedia\Shared\Domain\Model\User\UserToken;

class GetRefreshTokenQueryResponse implements QueryResponse
{
    /** @var UserToken */
    private $accessToken;

    /** @var string */
    private $tokenType;

    /** @var RefreshToken */
    private $refreshToken;

    public function __construct(UserToken $accessToken, string $tokenType, RefreshToken $refreshToken)
    {
        $this->accessToken = $accessToken;
        $this->tokenType = $tokenType;
        $this->refreshToken = $refreshToken;
    }

    public function accessToken(): UserToken
    {
        return $this->accessToken;
    }

    public function tokenType(): string
    {
        return $this->tokenType;
    }

    public function refreshToken(): RefreshToken
    {
        return $this->refreshToken;
    }
}
