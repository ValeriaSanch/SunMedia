<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\UserAgent\OperatingSystemList;

class GetOperatingSystemListQueryHandler
{
    private $getUserQueryService;

    public function __construct(GetOperatingSystemListQueryService $getUserQueryService)
    {
        $this->getUserQueryService = $getUserQueryService;
    }

    public function __invoke(GetOperatingSystemListQuery $getUserQuery): array
    {
        return $this->getUserQueryService->execute(
            $getUserQuery->loggedUser(),
            $getUserQuery->filters(),
            $getUserQuery->page(),
            $getUserQuery->size(),
            $getUserQuery->getIncludes(),
            $getUserQuery->getOrder(),
            $getUserQuery->query()
        );
    }
}
