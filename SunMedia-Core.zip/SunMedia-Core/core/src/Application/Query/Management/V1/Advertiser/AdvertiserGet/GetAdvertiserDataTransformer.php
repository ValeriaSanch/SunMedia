<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Advertiser\AdvertiserGet;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiAdvertiserTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiResourceDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetAdvertiserDataTransformer extends JsonApiResourceDataTransformer implements ResponseDataTransformer
{
    /** @var GetAdvertiserQueryResponse */
    private $getAdvertiserQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getAdvertiserQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getAdvertiserQueryResponse,
            new JsonApiAdvertiserTransformer(),
            'advertisers'
        );
    }
}
