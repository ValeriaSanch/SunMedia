<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Language\CheckLanguage;

use SunMedia\Core\Domain\Model\Language\Exception\LanguageNotFound;
use SunMedia\Core\Domain\Model\Language\LanguageRepository;
use SunMedia\Shared\Domain\Model\Language\LanguageId;

class CheckLanguageQueryService
{
    private $languageRepository;

    /** @var GetLanguageDataTransformer */
    private $getLanguageDataTransformer;

    public function __construct(
        LanguageRepository $languageRepository,
        GetLanguageDataTransformer $getLanguageDataTransformer
    ) {
        $this->languageRepository = $languageRepository;
        $this->getLanguageDataTransformer = $getLanguageDataTransformer;
    }

    /**
     * @throws LanguageNotFound
     */
    public function execute(LanguageId $languageId, array $includes): array
    {
        $language = $this->languageRepository->byId($languageId);

        if (null === $language) {
            throw new LanguageNotFound($languageId);
        }

        $this->getLanguageDataTransformer->write(new GetLanguageQueryResponse($language, $includes));

        return $this->getLanguageDataTransformer->read();
    }
}
