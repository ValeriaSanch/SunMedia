<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Carrier\CarrierList;

use SunMedia\Shared\Application\Query\QueryPaginator;

class GetCarrierListQuery extends QueryPaginator
{
    public const ACTION = 'MANAGEMENT_CARRIER_SHOW_LIST';

    protected function setDefaultOrder(): void
    {
        $this->orderType = 'asc';
        $this->orderBy = 'name';
    }

    protected function availableOrders(): array
    {
        return ['name'];
    }
}
