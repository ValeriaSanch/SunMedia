<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\ApiPlatformPrice\ApiPlatformPriceList;

use SunMedia\Shared\Application\Query\QueryPaginator;

class GetApiPlatformPriceListQuery extends QueryPaginator
{
    public const ACTION = 'MANAGEMENT_API_PLATFORM_PRICE_SHOW_LIST';

    /** @var array */
    private $group;

    public function addGroup(array $group = []): void
    {
        $this->group = $group;
    }

    public function group(): array
    {
        return $this->group ?? [];
    }

    public function availableGroups(): array
    {
        return ['country'];
    }

    protected function setDefaultOrder(): void
    {
        $this->orderType = 'asc';
        $this->orderBy = 'date';
    }

    protected function availableOrders(): array
    {
        return [
            'date',
            'country',
        ];
    }
}
