<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\SalesforceUserList;

use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUserCriteriaFactory;
use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUserRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetSalesforceUserListQueryService extends PaginatorService
{
    /** @var SalesforceUserRepository */
    private $salesforceUserRepository;

    public function __construct(
        SalesforceUserRepository $salesforceUserRepository,
        GetSalesforceUserListDataTransformer $dataTransformer,
        SalesforceUserCriteriaFactory $salesforceUserCriteriaFactory
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->salesforceUserRepository = $salesforceUserRepository;
        $this->criteriaFactory = $salesforceUserCriteriaFactory;
    }

    protected function makeQueryResponse(): GetSalesforceUserListQueryResponse
    {
        return new GetSalesforceUserListQueryResponse(
            $this->salesforceUserRepository->byCriteria($this->defaultCriteria),
            $this->page,
            $this->size,
            $this->salesforceUserRepository->count($this->defaultCriteria),
            $this->fields
        );
    }
}
