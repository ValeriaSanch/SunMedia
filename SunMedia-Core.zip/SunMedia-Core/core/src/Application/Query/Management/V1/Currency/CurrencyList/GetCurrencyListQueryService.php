<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Currency\CurrencyList;

use SunMedia\Shared\Domain\Model\Currency\CurrencyRepository;

class GetCurrencyListQueryService
{
    /** @var CurrencyRepository */
    private $currencyRepository;

    /** @var GetCurrencyListDataTransformer */
    private $dataTransformer;

    public function __construct(CurrencyRepository $currencyRepository, GetCurrencyListDataTransformer $dataTransformer)
    {
        $this->currencyRepository = $currencyRepository;
        $this->dataTransformer = $dataTransformer;
    }

    public function execute(): array
    {
        $currencies = $this->currencyRepository->all();

        $this->dataTransformer->write(new GetCurrencyListQueryResponse($currencies));

        return $this->dataTransformer->read();
    }
}
