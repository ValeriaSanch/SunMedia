<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\Login;

use SunMedia\Shared\Domain\Bus\Query;

class LoginQuery implements Query
{
    /** @var string */
    private $userEmail;

    /** @var string */
    private $userPassword;

    public function __construct(string $userEmail, string $userPassword)
    {
        $this->userEmail = $userEmail;
        $this->userPassword = $userPassword;
    }

    public function userEmail(): string
    {
        return $this->userEmail;
    }

    public function userPassword(): string
    {
        return $this->userPassword;
    }
}
