<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Geolocation\GetRegionList;

use SunMedia\Core\Domain\Model\Geolocation\Region\RegionCriteriaFactory;
use SunMedia\Core\Domain\Model\Geolocation\Region\RegionRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetRegionListQueryService extends PaginatorService
{
    private $regionRepository;

    public function __construct(
        RegionRepository $regionRepository,
        RegionCriteriaFactory $criteriaFactory,
        GetRegionListDataTransformer $dataTransformer
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->regionRepository = $regionRepository;
        $this->criteriaFactory = $criteriaFactory;
    }

    protected function makeQueryResponse(): GetRegionListQueryResponse
    {
        return new GetRegionListQueryResponse(
            $this->regionRepository->byCriteria($this->defaultCriteria),
            $this->page,
            $this->size,
            $this->regionRepository->count($this->defaultCriteria),
            $this->fields
        );
    }
}
