<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Client\ClientGet;

use SunMedia\Core\Domain\Model\Client\Client;
use SunMedia\Shared\Domain\Bus\SingleResourceResponse;

class GetClientQueryResponse implements SingleResourceResponse
{
    /** @var Client */
    private $resource;

    /** @var array */
    private $includes;

    public function __construct(Client $client, array $includes)
    {
        $this->resource = $client;
        $this->includes = $includes;
    }

    public function resource(): Client
    {
        return $this->resource;
    }

    public function includes(): array
    {
        return $this->includes;
    }
}
