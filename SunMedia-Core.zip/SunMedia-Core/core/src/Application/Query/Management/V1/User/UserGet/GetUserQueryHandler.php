<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\UserGet;

use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\User\UserId;

class GetUserQueryHandler
{
    /** @var GetUserQueryService */
    private $getUserQueryService;

    public function __construct(GetUserQueryService $getUserQueryService)
    {
        $this->getUserQueryService = $getUserQueryService;
    }

    /**
     * @throws DomainException
     * @throws UserNotFound
     */
    public function __invoke(GetUserQuery $getUserQuery): array
    {
        return $this->getUserQueryService->execute(
            $getUserQuery->loggedUser(),
            new UserId($getUserQuery->userId()),
            $getUserQuery->includes()
        );
    }
}
