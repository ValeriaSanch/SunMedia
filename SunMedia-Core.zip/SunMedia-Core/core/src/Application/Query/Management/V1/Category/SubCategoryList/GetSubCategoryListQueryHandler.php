<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\SubCategoryList;

use SunMedia\Shared\Domain\Model\Category\CategoryId;

class GetSubCategoryListQueryHandler
{
    /** @var GetSubCategoryListQueryService */
    private $service;

    public function __construct(GetSubCategoryListQueryService $service)
    {
        $this->service = $service;
    }

    public function __invoke(GetSubCategoryListQuery $query): array
    {
        return $this->service->execute(new CategoryId($query->category()));
    }
}
