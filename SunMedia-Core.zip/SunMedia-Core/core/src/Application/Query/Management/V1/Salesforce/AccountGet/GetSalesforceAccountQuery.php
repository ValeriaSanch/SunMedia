<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\AccountGet;

use SunMedia\Shared\Application\Query\QuerySingleResource;
use SunMedia\Shared\Domain\Model\User\User;

class GetSalesforceAccountQuery extends QuerySingleResource
{
    public const ACTION = 'MANAGEMENT_SALESFORCE_ACCOUNT_SHOW';

    /** @var string */
    private $accountId;

    public function __construct(User $loggedUser, string $accountId, array $include)
    {
        parent::__construct($loggedUser, $include);
        $this->accountId = $accountId;
    }

    public function accountId(): string
    {
        return $this->accountId;
    }
}
