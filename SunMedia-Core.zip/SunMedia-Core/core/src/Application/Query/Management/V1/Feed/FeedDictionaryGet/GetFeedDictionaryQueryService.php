<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Feed\FeedDictionaryGet;

use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileEmpty;
use SunMedia\Core\Domain\Model\Feed\FeedDictionary;
use SunMedia\Core\Domain\Model\Feed\FeedType;
use SunMedia\Core\Domain\Model\Feed\FeedUrl;
use SunMedia\Core\Domain\Service\Feed\TransformFile;
use SunMedia\Core\Domain\Service\Feed\TransformFileXml;

class GetFeedDictionaryQueryService
{
    /** @var TransformFileXml */
    private $transformFileXml;

    /** @var TransformFile */
    private $transformFile;

    public function __construct(TransformFileXml $transformFileXml, TransformFile $transformFile)
    {
        $this->transformFileXml = $transformFileXml;
        $this->transformFile = $transformFile;
    }

    /**
     * @throws FeedFileEmpty
     */
    public function execute(FeedUrl $url, FeedType $type): array
    {
        $dictionary = [];
        if (preg_match('/.*\.(xml)$/', $url->value())) {
            $this->transformFileXml->dictionary($url, $dictionary);
        }
        if (preg_match('/.*\.(csv)$/', $url->value())) {
            $this->transformFile->dictionary($url, $dictionary);
        }

        if (FeedType::FEED_TYPE_FILE === $type->value()) {
            unlink($url->value());
        }

        if (!$dictionary = array_filter($dictionary)) {
            throw new FeedFileEmpty($url->value());
        }

        return [
            'dictionary' => [
                'file' => $dictionary,
                'our' => array_combine(FeedDictionary::DICTIONARY, FeedDictionary::DICTIONARY),
            ],
        ];
    }
}
