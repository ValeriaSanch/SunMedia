<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\Login;

use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserPassword;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\Model\Email\Email;
use SunMedia\Shared\Domain\Model\User\Exception\PasswordMismatch;

class LoginQueryHandler
{
    /** @var LoginQueryService */
    private $loginQueryService;

    public function __construct(LoginQueryService $loginQueryService)
    {
        $this->loginQueryService = $loginQueryService;
    }

    /**
     * @throws EmailNotValid
     * @throws EmptyValue
     * @throws PasswordMismatch
     * @throws UserNotFound
     */
    public function __invoke(LoginQuery $loginQuery): array
    {
        $userEmail = new Email($loginQuery->userEmail());
        $userPassword = new UserPassword($loginQuery->userPassword());

        return $this->loginQueryService->execute($userEmail, $userPassword);
    }
}
