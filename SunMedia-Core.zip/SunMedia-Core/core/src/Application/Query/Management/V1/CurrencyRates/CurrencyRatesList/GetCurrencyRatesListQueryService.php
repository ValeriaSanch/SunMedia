<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\CurrencyRates\CurrencyRatesList;

use Exception;
use SunMedia\Core\Application\Command\Management\V1\CurrencyRate\CurrencyRateCreator\CurrencyRateCreatorCommand;
use SunMedia\Shared\Application\Query\PaginatorService;
use SunMedia\Shared\Domain\Model\Currency\Currency;
use SunMedia\Shared\Domain\Model\Currency\CurrencyCollection;
use SunMedia\Shared\Domain\Model\Currency\CurrencyId;
use SunMedia\Shared\Domain\Model\Currency\CurrencyName;
use SunMedia\Shared\Domain\Model\Currency\CurrencySymbol;
use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRate;
use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRateCriteriaFactory;
use SunMedia\Shared\Domain\Model\CurrencyRate\CurrencyRateRepository;
use SunMedia\Shared\Domain\Model\Date\SMDate;
use SunMedia\Shared\Domain\Service\CurrencyService;
use SunMedia\Shared\Infrastructure\Service\DateRangeService;
use SunMedia\Shared\Infrastructure\Service\DetectDelimiterCsv;
use Symfony\Component\Messenger\MessageBusInterface;

class GetCurrencyRatesListQueryService extends PaginatorService
{
    private $currencyRateRepository;

    /** @var CurrencyService */
    private $currencyService;

    /** @var MessageBusInterface */
    private $commandBus;

    public function __construct(
        GetCurrencyRatesListDataTransformer $dataTransformer,
        CurrencyRateRepository $currencyRateRepository,
        CurrencyRateCriteriaFactory $currencyRateCriteriaFactory,
        CurrencyService $currencyService,
        MessageBusInterface $commandBus
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->criteriaFactory = $currencyRateCriteriaFactory;
        $this->currencyRateRepository = $currencyRateRepository;
        $this->currencyService = $currencyService;
        $this->commandBus = $commandBus;
    }

    /**
     * @throws Exception
     */
    protected function makeQueryResponse(): GetCurrencyRatesListQueryResponse
    {
        $currencyRateCollection = $this->currencyRateRepository->byCriteria($this->defaultCriteria);

        $currencyBaseId = $this->filters[CurrencyRate::COLUMN_CURRENCY_BASE];
        $currencyDestinationId = $this->filters[CurrencyRate::COLUMN_CURRENCY_DESTINATION];

        $date = array_filter(explode(DetectDelimiterCsv::DELIMITER_SEMICOLON, $this->filters[CurrencyRate::COLUMN_DATE]));

        if (count($date) > 1) {
            $date = DateRangeService::setDateRange(SMDate::fromString($date[0]), SMDate::fromString($date[1]));
        }

        foreach ($date as $value) {
            $hash = $currencyRateCollection->generateHash($currencyBaseId, $currencyDestinationId, $value);

            if (!$currencyRateCollection->get($hash)) {
                $currencyRateCollection->addCurrencyRates($this->getCurrencyRateCollection($currencyBaseId, $currencyDestinationId, $value));
            }
        }

        return new GetCurrencyRatesListQueryResponse(
            $currencyRateCollection,
            $this->page,
            $this->size,
            $this->currencyRateRepository->count($this->defaultCriteria),
            $this->fields
        );
    }

    /**
     * @throws Exception
     */
    private function getCurrencyRateCollection(string $currencyBaseId, string $currencyDestinationId, string $date)
    {
        $baseCurrency = new Currency(
            new CurrencyId($currencyBaseId),
            new CurrencyName($currencyBaseId),
            new CurrencySymbol($currencyBaseId)
        );

        $destinyCurrency = new Currency(
            new CurrencyId($currencyDestinationId),
            new CurrencyName($currencyDestinationId),
            new CurrencySymbol($currencyDestinationId)
        );

        $currencyCollection = CurrencyCollection::create();
        $currencyCollection->addCurrency($destinyCurrency);

        $currencyRateCollection = $this->currencyService->conversionRatesByCurrencyAndDate(
            $baseCurrency,
            $currencyCollection,
            SMDate::fromString($date)
        );

        /** @var CurrencyRate $currencyRate */
        foreach ($currencyRateCollection as $currencyRate) {
            $this->commandBus->dispatch(new CurrencyRateCreatorCommand(
                $currencyRate->currencyBaseId()->value(),
                $currencyRate->currencyDestinationId()->value(),
                $currencyRate->date()->format(SMDate::FORMAT),
                $currencyRate->rate()->value()
            ));
        }

        return $currencyRateCollection;
    }
}
