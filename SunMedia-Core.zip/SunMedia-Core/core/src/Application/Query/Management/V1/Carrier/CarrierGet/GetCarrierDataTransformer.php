<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Carrier\CarrierGet;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiCarrierTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiResourceDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetCarrierDataTransformer extends JsonApiResourceDataTransformer implements ResponseDataTransformer
{
    /** @var GetCarrierQueryResponse */
    private $getCarrierQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getCarrierQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getCarrierQueryResponse,
            new JsonApiCarrierTransformer(),
            'carriers'
        );
    }
}
