<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\Login;

class LoginDataTransformer
{
    /** @var LoginQueryResponse */
    private $loginQueryResponse;

    public function write(LoginQueryResponse $loginQueryResponse): void
    {
        $this->loginQueryResponse = $loginQueryResponse;
    }

    public function read(): array
    {
        return [
            'token_type' => $this->loginQueryResponse->tokenType(),
            'access_token' => $this->loginQueryResponse->accessToken()->token()->value(),
            'expires_in' => $this->loginQueryResponse->accessToken()->expiresIn(),
            'refresh_token' => $this->loginQueryResponse->refreshToken()->token()->value(),
        ];
    }
}
