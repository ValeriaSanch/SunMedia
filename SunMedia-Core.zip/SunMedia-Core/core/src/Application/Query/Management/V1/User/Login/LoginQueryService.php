<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\Login;

use SunMedia\Core\Domain\Model\User\Exception\UserNotFound;
use SunMedia\Core\Domain\Model\User\UserPassword;
use SunMedia\Core\Domain\Model\User\UserRepository;
use SunMedia\Shared\Domain\Model\Email\Email;
use SunMedia\Shared\Domain\Model\User\Exception\PasswordMismatch;
use SunMedia\Shared\Domain\Model\User\PasswordEncoder;
use SunMedia\Shared\Domain\Model\User\SecurityUserRepository;
use SunMedia\Shared\Domain\Model\User\Token\RefreshTokenRepository;
use SunMedia\Shared\Domain\Model\User\Token\RefreshUserTokenGenerator;
use SunMedia\Shared\Domain\Model\User\UserTokenGenerator;

class LoginQueryService
{
    /** @var SecurityUserRepository */
    private $userRepository;

    /** @var PasswordEncoder */
    private $passwordEncoder;

    /** @var UserTokenGenerator */
    private $userTokenGenerator;

    /** @var LoginDataTransformer */
    private $loginDataTransformer;

    /** @var RefreshUserTokenGenerator */
    private $refreshUserTokenGenerator;

    /** @var RefreshTokenRepository */
    private $refreshTokenRepository;

    public function __construct(
        UserRepository $userRepository,
        PasswordEncoder $passwordEncoder,
        UserTokenGenerator $userTokenGenerator,
        RefreshUserTokenGenerator $refreshUserTokenGenerator,
        RefreshTokenRepository $refreshTokenRepository,
        LoginDataTransformer $loginDataTransformer
    ) {
        $this->userRepository = $userRepository;
        $this->passwordEncoder = $passwordEncoder;
        $this->userTokenGenerator = $userTokenGenerator;
        $this->loginDataTransformer = $loginDataTransformer;
        $this->refreshUserTokenGenerator = $refreshUserTokenGenerator;
        $this->refreshTokenRepository = $refreshTokenRepository;
    }

    /**
     * @throws PasswordMismatch
     * @throws UserNotFound
     */
    public function execute(Email $email, UserPassword $password): array
    {
        $user = $this->userRepository->byEmail($email);

        if (null === $user || $user->deleted() || !$user->enabled()->value()) {
            throw new UserNotFound();
        }

        $this->passwordEncoder->verify($password->value(), $user->password()->value());

        $userToken = $this->userTokenGenerator->generate($user->id());

        $refreshToken = $this->refreshTokenRepository->byUserId($user->id());
        if (null !== $refreshToken && $refreshToken->isExpired()) {
            $this->refreshTokenRepository->delete($refreshToken);
            $refreshToken = null;
        }

        if (null === $refreshToken) {
            $refreshToken = $this->refreshUserTokenGenerator->generate($user->id());
            $this->refreshTokenRepository->save($refreshToken);
        }

        $this->loginDataTransformer->write(new LoginQueryResponse($userToken, 'bearer', $refreshToken));

        return $this->loginDataTransformer->read();
    }
}
