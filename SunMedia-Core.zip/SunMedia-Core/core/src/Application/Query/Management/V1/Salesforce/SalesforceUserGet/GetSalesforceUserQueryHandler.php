<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\SalesforceUserGet;

use SunMedia\Core\Domain\Model\SalesforceUser\Exception\SalesforceUserNotFound;

class GetSalesforceUserQueryHandler
{
    /** @var GetSalesforceUserQueryService */
    private $getClientQueryService;

    /** @var GetSalesforceUserQueryValidation */
    private $getSalesforceUserQueryValidation;

    public function __construct(
        GetSalesforceUserQueryService $getClientQueryService,
        GetSalesforceUserQueryValidation $getSalesforceUserQueryValidation
    ) {
        $this->getClientQueryService = $getClientQueryService;
        $this->getSalesforceUserQueryValidation = $getSalesforceUserQueryValidation;
    }

    /**
     * @throws SalesforceUserNotFound
     */
    public function __invoke(GetSalesforceUserQuery $getSalesforceUserQuery): array
    {
        return $this->getClientQueryService->execute(
            ...$this->getSalesforceUserQueryValidation->validate($getSalesforceUserQuery)
        );
    }
}
