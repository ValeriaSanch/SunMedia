<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\SalesforceUserGet;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiSalesforceUserTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiResourceDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetSalesforceUserDataTransformer extends JsonApiResourceDataTransformer implements ResponseDataTransformer
{
    /** @var GetSalesforceUserQueryResponse */
    private $getClientResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getClientResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getClientResponse,
            new JsonApiSalesforceUserTransformer(),
            'salesforce-users'
        );
    }
}
