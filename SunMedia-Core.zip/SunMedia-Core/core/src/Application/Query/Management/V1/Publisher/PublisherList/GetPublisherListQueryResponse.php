<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Publisher\PublisherList;

use SunMedia\Core\Domain\Model\Publisher\PublisherCollection;
use SunMedia\Shared\Domain\Bus\PaginatorResponse;
use SunMedia\Shared\Domain\Bus\QueryResponse;
use SunMedia\Shared\Domain\Collection\AbstractCollection;
use SunMedia\Shared\Domain\Criteria\FieldCollection;

class GetPublisherListQueryResponse implements QueryResponse, PaginatorResponse
{
    /** @var PublisherCollection */
    private $collection;

    /** @var int */
    private $page;

    /** @var int */
    private $itemsPerPage;

    /** @var int */
    private $totalResults;

    /** @var FieldCollection */
    private $includes;

    public function __construct(
        PublisherCollection $publisherCollection,
        int $page,
        int $itemsPerPage,
        int $totalResults,
        FieldCollection $includes
    ) {
        $this->collection = $publisherCollection;
        $this->page = $page;
        $this->itemsPerPage = $itemsPerPage;
        $this->totalResults = $totalResults;
        $this->includes = $includes;
    }

    public function includes(): FieldCollection
    {
        return $this->includes;
    }

    public function collection(): AbstractCollection
    {
        return $this->collection;
    }

    public function page(): int
    {
        return $this->page;
    }

    public function size(): int
    {
        return $this->itemsPerPage;
    }

    public function totalResults(): int
    {
        return $this->totalResults;
    }
}
