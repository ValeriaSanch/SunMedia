<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\CategoryGet;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiCategoryTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiResourceDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

final class GetCategoryDataTransformer extends JsonApiResourceDataTransformer implements ResponseDataTransformer
{
    /** @var GetCategoryQueryResponse */
    private $getCategoryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getCategoryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getCategoryResponse,
            new JsonApiCategoryTransformer(),
            'categories'
        );
    }
}
