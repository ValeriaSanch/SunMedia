<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Country\CountryList;

class GetCountryListQueryHandler
{
    /** @var GetCountryListQueryService */
    private $service;

    public function __construct(GetCountryListQueryService $service)
    {
        $this->service = $service;
    }

    public function __invoke(GetCountryListQuery $query): array
    {
        $this->service->setAllFlag($query->all());

        return $this->service->execute(
            $query->loggedUser(),
            $query->filters(),
            $query->page(),
            $query->size(),
            $query->getIncludes(),
            $query->getOrder(),
            $query->query()
        );
    }
}
