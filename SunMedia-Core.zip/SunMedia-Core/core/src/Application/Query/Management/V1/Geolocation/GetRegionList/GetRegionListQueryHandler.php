<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Geolocation\GetRegionList;

class GetRegionListQueryHandler
{
    private $getRegionListQueryService;

    public function __construct(GetRegionListQueryService $getRegionListQueryService)
    {
        $this->getRegionListQueryService = $getRegionListQueryService;
    }

    public function __invoke(GetRegionListQuery $getRegionListQuery): array
    {
        return $this->getRegionListQueryService->execute(
            $getRegionListQuery->loggedUser(),
            $getRegionListQuery->filters(),
            $getRegionListQuery->page(),
            $getRegionListQuery->size(),
            $getRegionListQuery->getIncludes(),
            $getRegionListQuery->getOrder(),
            $getRegionListQuery->query()
        );
    }
}
