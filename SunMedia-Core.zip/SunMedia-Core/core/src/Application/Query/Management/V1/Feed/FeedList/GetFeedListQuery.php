<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Feed\FeedList;

use SunMedia\Shared\Application\Query\QueryPaginator;

class GetFeedListQuery extends QueryPaginator
{
    public const ACTION = 'MANAGEMENT_FEED_SHOW_LIST';

    protected function setDefaultOrder(): void
    {
        $this->orderType = 'desc';
        $this->orderBy = 'createdAt';
    }

    protected function availableOrders(): array
    {
        return ['name', 'type', 'createdAt'];
    }
}
