<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Feed\FeedDictionaryGet;

use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileEmpty;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidFileType;
use SunMedia\Shared\Domain\Exception\EmptyValue;

class GetFeedDictionaryQueryHandler
{
    /** @var GetFeedDictionaryQueryValidation */
    private $feedDictionaryQueryValidation;

    /** @var GetFeedDictionaryQueryService */
    private $feedDictionaryQueryService;

    public function __construct(
        GetFeedDictionaryQueryValidation $feedDictionaryQueryValidation,
        GetFeedDictionaryQueryService $feedDictionaryQueryService
    ) {
        $this->feedDictionaryQueryValidation = $feedDictionaryQueryValidation;
        $this->feedDictionaryQueryService = $feedDictionaryQueryService;
    }

    /**
     * @throws EmptyValue
     * @throws FeedFileEmpty
     * @throws FeedFileNotFound
     * @throws InvalidFileType
     */
    public function __invoke(GetFeedDictionaryQuery $feedDictionaryQuery): array
    {
        return $this->feedDictionaryQueryService->execute(...$this->feedDictionaryQueryValidation->validate($feedDictionaryQuery));
    }
}
