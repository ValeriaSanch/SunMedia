<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\UserList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiUserTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiPaginatorDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetUserListDataTransformer extends JsonApiPaginatorDataTransformer implements ResponseDataTransformer
{
    /** @var GetUserListQueryResponse */
    private $getUserListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getUserListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getUserListQueryResponse,
            new JsonApiUserTransformer(),
            'users'
        );
    }
}
