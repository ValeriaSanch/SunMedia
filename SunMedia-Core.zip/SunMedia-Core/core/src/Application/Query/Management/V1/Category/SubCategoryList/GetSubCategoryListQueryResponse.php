<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\SubCategoryList;

use SunMedia\Shared\Domain\Bus\QueryResponse;
use SunMedia\Shared\Domain\Model\Category\CategoryCollection;

class GetSubCategoryListQueryResponse implements QueryResponse
{
    /** @var CategoryCollection */
    private $categories;

    /**
     * GetCategoryListQueryResponse constructor.
     */
    public function __construct(CategoryCollection $categories)
    {
        $this->categories = $categories;
    }

    public function categories(): CategoryCollection
    {
        return $this->categories;
    }
}
