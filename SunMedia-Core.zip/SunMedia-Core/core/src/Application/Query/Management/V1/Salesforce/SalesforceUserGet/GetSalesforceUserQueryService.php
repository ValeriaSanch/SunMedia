<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\SalesforceUserGet;

use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUser;

class GetSalesforceUserQueryService
{
    /** @var GetSalesforceUserDataTransformer */
    private $dataTransformer;

    public function __construct(GetSalesforceUserDataTransformer $dataTransformer)
    {
        $this->dataTransformer = $dataTransformer;
    }

    public function execute(SalesforceUser $salesforceUser, array $includes): array
    {
        $this->dataTransformer->write(new GetSalesforceUserQueryResponse($salesforceUser, $includes));

        return $this->dataTransformer->read();
    }
}
