<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Currency\CurrencyList;

use SunMedia\Shared\Domain\Bus\QueryResponse;
use SunMedia\Shared\Domain\Model\Currency\CurrencyCollection;

class GetCurrencyListQueryResponse implements QueryResponse
{
    /** @var CurrencyCollection */
    private $currencies;

    public function __construct(CurrencyCollection $currencies)
    {
        $this->currencies = $currencies;
    }

    public function currencies(): CurrencyCollection
    {
        return $this->currencies;
    }
}
