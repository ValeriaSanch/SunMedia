<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\CdnInvalidation\CdnInvalidationGet;

use SunMedia\Core\Domain\Model\CdnInvalidation\CdnInvalidationRepository;
use SunMedia\Core\Domain\Model\CdnInvalidation\Exception\CdnInvalidationNotFound;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;

class GetCdnInvalidationQueryService
{
    /** @var CdnInvalidationRepository */
    private $cdnInvalidationRepository;

    /** @var GetCdnInvalidationDataTransformer */
    private $cdnInvalidationDataTransformer;

    public function __construct(
        GetCdnInvalidationDataTransformer $cdnInvalidationDataTransformer,
        CdnInvalidationRepository $cdnInvalidationRepository
    ) {
        $this->cdnInvalidationDataTransformer = $cdnInvalidationDataTransformer;
        $this->cdnInvalidationRepository = $cdnInvalidationRepository;
    }

    /**
     * @throws CdnInvalidationNotFound
     */
    public function execute(string $id): array
    {
        $cdnInvalidation = $this->cdnInvalidationRepository->byId($id, new Criteria());

        if (null === $cdnInvalidation) {
            throw new CdnInvalidationNotFound($id);
        }

        $this->cdnInvalidationDataTransformer->write(new GetCdnInvalidationQueryResponse($cdnInvalidation, []));

        return $this->cdnInvalidationDataTransformer->read();
    }
}
