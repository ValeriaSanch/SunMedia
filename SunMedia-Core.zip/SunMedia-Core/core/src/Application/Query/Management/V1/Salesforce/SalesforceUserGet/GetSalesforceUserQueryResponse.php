<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\SalesforceUserGet;

use SunMedia\Core\Domain\Model\SalesforceUser\SalesforceUser;
use SunMedia\Shared\Domain\Bus\SingleResourceResponse;

class GetSalesforceUserQueryResponse implements SingleResourceResponse
{
    /** @var SalesforceUser */
    private $resource;

    /** @var array */
    private $includes;

    public function __construct(SalesforceUser $user, array $includes)
    {
        $this->resource = $user;
        $this->includes = $includes;
    }

    public function resource(): SalesforceUser
    {
        return $this->resource;
    }

    public function includes(): array
    {
        return $this->includes;
    }
}
