<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Client\ClientGet;

use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Shared\Application\Query\QuerySingleResource;

class GetClientQuery extends QuerySingleResource
{
    public const ACTION = 'MANAGEMENT_CLIENT_SHOW';

    /** @var string */
    private $clientId;

    public function __construct(User $loggedUser, string $clientId, array $include)
    {
        parent::__construct($loggedUser, $include);
        $this->clientId = $clientId;
    }

    public function clientId(): string
    {
        return $this->clientId;
    }
}
