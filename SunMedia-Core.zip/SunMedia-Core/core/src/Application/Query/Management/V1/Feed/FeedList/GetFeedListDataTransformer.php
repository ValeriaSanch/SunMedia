<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Feed\FeedList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiFeedTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiPaginatorDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetFeedListDataTransformer extends JsonApiPaginatorDataTransformer implements ResponseDataTransformer
{
    /** @var GetFeedListQueryResponse */
    private $getFeedListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getFeedListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize($this->getFeedListQueryResponse, new JsonApiFeedTransformer(), 'feeds');
    }
}
