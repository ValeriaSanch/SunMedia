<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Publisher\PublisherList;

class GetPublisherListQueryHandler
{
    /** @var GetPublisherListQueryService */
    private $getPublisherListQueryService;

    public function __construct(GetPublisherListQueryService $getPublisherListQueryService)
    {
        $this->getPublisherListQueryService = $getPublisherListQueryService;
    }

    public function __invoke(GetPublisherListQuery $getPublisherListQuery): array
    {
        return $this->getPublisherListQueryService->execute(
            $getPublisherListQuery->loggedUser(),
            $getPublisherListQuery->filters(),
            $getPublisherListQuery->page(),
            $getPublisherListQuery->size(),
            $getPublisherListQuery->getIncludes(),
            $getPublisherListQuery->getOrder(),
            $getPublisherListQuery->query()
        );
    }
}
