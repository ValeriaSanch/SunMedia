<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\AccountList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiSalesforceAccountTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiPaginatorDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetSalesforceAccountListDataTransformer extends JsonApiPaginatorDataTransformer implements ResponseDataTransformer
{
    /** @var GetSalesforceAccountListQueryResponse */
    private $getSalesforceAccountListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getSalesforceAccountListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getSalesforceAccountListQueryResponse,
            new JsonApiSalesforceAccountTransformer(),
            'salesforce-accounts'
        );
    }
}
