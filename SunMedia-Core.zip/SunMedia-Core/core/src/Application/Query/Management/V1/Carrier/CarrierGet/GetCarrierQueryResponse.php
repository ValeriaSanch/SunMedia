<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Carrier\CarrierGet;

use SunMedia\Core\Domain\Model\Carrier\Carrier;
use SunMedia\Shared\Domain\Bus\SingleResourceResponse;

class GetCarrierQueryResponse implements SingleResourceResponse
{
    /** @var Carrier */
    private $resource;

    /** @var array */
    private $includes;

    public function __construct(Carrier $carrier, array $includes)
    {
        $this->resource = $carrier;
        $this->includes = $includes;
    }

    public function resource(): Carrier
    {
        return $this->resource;
    }

    public function includes(): array
    {
        return $this->includes;
    }
}
