<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\CdnInvalidation\CdnInvalidationGet;

use SunMedia\Core\Domain\Model\CdnInvalidation\Exception\CdnInvalidationNotFound;

class GetCdnInvalidationQueryHandler
{
    /** @var GetCdnInvalidationQueryService */
    private $service;

    public function __construct(GetCdnInvalidationQueryService $service)
    {
        $this->service = $service;
    }

    /**
     * @throws CdnInvalidationNotFound
     */
    public function __invoke(GetCdnInvalidationQuery $query): array
    {
        return $this->service->execute($query->cdnInvalidationId());
    }
}
