<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Publisher\PublisherList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiPublisherTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiPaginatorDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetPublisherListDataTransformer extends JsonApiPaginatorDataTransformer implements ResponseDataTransformer
{
    /** @var GetPublisherListQueryResponse */
    private $getPublisherListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getPublisherListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getPublisherListQueryResponse,
            new JsonApiPublisherTransformer(),
            'publishers'
        );
    }
}
