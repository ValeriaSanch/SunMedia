<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\SubCategoryList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiSubCategoryTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetSubCategoryListDataTransformer extends JsonApiDataTransformer implements ResponseDataTransformer
{
    /** @var GetSubCategoryListQueryResponse */
    private $getSubCategoryListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getSubCategoryListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getSubCategoryListQueryResponse->categories()->toArray(),
            new JsonApiSubCategoryTransformer(),
            'categories'
        );
    }
}
