<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\GetUserProfile;

use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Shared\Domain\Bus\SingleResourceResponse;

class GetUserProfileQueryResponse implements SingleResourceResponse
{
    /** @var User */
    private $resource;

    public function __construct(User $user)
    {
        $this->resource = $user;
    }

    public function resource(): User
    {
        return $this->resource;
    }

    public function includes(): array
    {
        return [];
    }
}
