<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Language\CheckLanguage;

use SunMedia\Core\Domain\Model\Language\Exception\LanguageNotFound;
use SunMedia\Shared\Domain\Model\Language\LanguageId;

class CheckLanguageQueryHandler
{
    private $checkLanguageQueryService;

    public function __construct(CheckLanguageQueryService $checkLanguageQueryService)
    {
        $this->checkLanguageQueryService = $checkLanguageQueryService;
    }

    /**
     * @throws LanguageNotFound
     */
    public function __invoke(CheckLanguageQuery $checkLanguageQuery): array
    {
        return $this->checkLanguageQueryService->execute(
            new LanguageId($checkLanguageQuery->languageId()),
            $checkLanguageQuery->includes()
        );
    }
}
