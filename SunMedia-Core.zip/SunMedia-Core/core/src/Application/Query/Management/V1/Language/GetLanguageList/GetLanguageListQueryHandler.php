<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Language\GetLanguageList;

class GetLanguageListQueryHandler
{
    private $getUserQueryService;

    public function __construct(GetLanguageListQueryService $getLanguageListQueryService)
    {
        $this->getUserQueryService = $getLanguageListQueryService;
    }

    public function __invoke(GetLanguageListQuery $getLanguageListQuery): array
    {
        return $this->getUserQueryService->execute(
            $getLanguageListQuery->loggedUser(),
            $getLanguageListQuery->filters(),
            $getLanguageListQuery->page(),
            $getLanguageListQuery->size(),
            $getLanguageListQuery->getIncludes(),
            $getLanguageListQuery->getOrder(),
            $getLanguageListQuery->query()
        );
    }
}
