<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\UserAgent\BrowserList;

use SunMedia\Core\Domain\Model\Browser\BrowserCriteriaFactory;
use SunMedia\Core\Domain\Model\Browser\BrowserRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetBrowserListQueryService extends PaginatorService
{
    private $browserRepository;

    public function __construct(
        BrowserRepository $browserRepository,
        BrowserCriteriaFactory $browserCriteriaFactory,
        GetBrowserListDataTransformer $dataTransformer
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->browserRepository = $browserRepository;
        $this->criteriaFactory = $browserCriteriaFactory;
    }

    protected function makeQueryResponse(): GetBrowserListQueryResponse
    {
        $browserFamilies = $this->browserRepository->byCriteria($this->defaultCriteria);

        return new GetBrowserListQueryResponse(
            $browserFamilies,
            $this->page,
            $this->size,
            $browserFamilies->count(),
            $this->fields
        );
    }
}
