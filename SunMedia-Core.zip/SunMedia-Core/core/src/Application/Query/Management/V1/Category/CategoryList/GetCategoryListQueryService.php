<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\CategoryList;

use ReflectionException;
use SunMedia\Shared\Domain\Model\Category\CategoryRepository;

class GetCategoryListQueryService
{
    /** @var CategoryRepository */
    private $categoryRepository;

    /** @var GetCategoryListDataTransformer */
    private $dataTransformer;

    public function __construct(CategoryRepository $categoryRepository, GetCategoryListDataTransformer $dataTransformer)
    {
        $this->dataTransformer = $dataTransformer;
        $this->categoryRepository = $categoryRepository;
    }

    /**
     * @throws ReflectionException
     */
    public function execute(): array
    {
        $this->dataTransformer->write(new GetCategoryListQueryResponse($this->categoryRepository->categories()));

        return $this->dataTransformer->read();
    }
}
