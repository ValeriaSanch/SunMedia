<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\CdnInvalidation\CdnInvalidationGet;

use SunMedia\Core\Domain\Model\CdnInvalidation\CdnInvalidation;
use SunMedia\Shared\Domain\Bus\SingleResourceResponse;

class GetCdnInvalidationQueryResponse implements SingleResourceResponse
{
    /** @var CdnInvalidation */
    private $resource;

    /** @var array */
    private $includes;

    public function __construct(CdnInvalidation $CdnInvalidation, array $includes)
    {
        $this->resource = $CdnInvalidation;
        $this->includes = $includes;
    }

    public function resource(): CdnInvalidation
    {
        return $this->resource;
    }

    public function includes(): array
    {
        return $this->includes;
    }
}
