<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\ApiPlatformPrice\ApiPlatformPriceList;

use SunMedia\Core\Application\Command\Management\V1\ApiPlatformPrice\ApiPlatformPriceCreator\ApiPlatformPriceCreatorCommand;
use SunMedia\Core\Domain\Model\ApiPlatformPrice\ApiPlatformPriceCriteriaFactory;
use SunMedia\Core\Domain\Model\ApiPlatformPrice\ApiPlatformPriceDate;
use SunMedia\Core\Domain\Model\ApiPlatformPrice\ApiPlatformPriceRepository;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Criteria\FieldCollection;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;
use Symfony\Component\Messenger\MessageBusInterface;

class GetApiPlatformPriceListQueryService
{
    /** @var ApiPlatformPriceRepository */
    private $apiPlatformPriceRepository;

    /** @var GetApiPlatformPriceListDataTransformer */
    private $dataTransformer;

    /** @var ApiPlatformPriceCriteriaFactory */
    private $criteriaFactory;

    /** @var MessageBusInterface */
    private $commandBus;

    public function __construct(
        ApiPlatformPriceRepository $apiPlatformPriceRepository,
        GetApiPlatformPriceListDataTransformer $dataTransformer,
        ApiPlatformPriceCriteriaFactory $criteriaFactory,
        MessageBusInterface $commandBus
    ) {
        $this->apiPlatformPriceRepository = $apiPlatformPriceRepository;
        $this->dataTransformer = $dataTransformer;
        $this->criteriaFactory = $criteriaFactory;
        $this->commandBus = $commandBus;
    }

    public function execute(array $filter, array $order, int $page = 1, int $size = 20, array $group = []): array
    {
        $criteria = $this->criteriaFactory->byFilters($filter, $order, $page, $size);

        $this->dataTransformer->write($this->makeQueryResponse($criteria, $filter, $page, $size, $group));

        return $this->dataTransformer->read();
    }

    private function makeQueryResponse(
        Criteria $criteria,
        $filter,
        $page,
        $size,
        $group
    ): GetApiPlatformPriceListQueryResponse {
        if (!empty($group)) {
            $apiPlatformPrices = $this->apiPlatformPriceRepository->byCriteriaByGroup($criteria, $group);
            $this->requestApiPlatformPrice($apiPlatformPrices, $filter);
            $count = $this->apiPlatformPriceRepository->countByGroup($criteria, $group);
        } else {
            $apiPlatformPrices = $this->apiPlatformPriceRepository->byCriteria($criteria);
            $this->requestApiPlatformPrice($apiPlatformPrices, $filter);
            $count = $this->apiPlatformPriceRepository->count($criteria);
        }

        return new GetApiPlatformPriceListQueryResponse(
            $apiPlatformPrices,
            $page,
            $size,
            $count,
            FieldCollection::create()
        );
    }

    private function requestApiPlatformPrice(array $apiPlatformPrices, $filters): void
    {
        $datesReturned = [];
        foreach ($apiPlatformPrices as $apiPlatformPrice) {
            $datesReturned[$apiPlatformPrice['date']] = $apiPlatformPrice['date'];
        }

        $start = SMDatetime::fromString($filters['start_date']);
        $end = SMDatetime::fromString($filters['end_date']);

        for ($i = 0; $i <= $start->diff($end)->days; ++$i) {
            $date = $start->modify("+{$i} days")->format(ApiPlatformPriceDate::FORMAT);
            if (!isset($datesReturned[$date])) {
                $this->commandBus->dispatch(new ApiPlatformPriceCreatorCommand($date));
            }
        }
    }
}
