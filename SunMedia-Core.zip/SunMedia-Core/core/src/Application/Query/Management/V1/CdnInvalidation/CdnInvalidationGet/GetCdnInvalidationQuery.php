<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\CdnInvalidation\CdnInvalidationGet;

use SunMedia\Shared\Application\Query\QuerySingleResource;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class GetCdnInvalidationQuery extends QuerySingleResource
{
    /** @var string */
    private $cdnInvalidationId;

    public function __construct(?SecurityUser $loggedUser, string $cdnInvalidationId)
    {
        parent::__construct($loggedUser, []);
        $this->cdnInvalidationId = $cdnInvalidationId;
    }

    public function cdnInvalidationId(): string
    {
        return $this->cdnInvalidationId;
    }
}
