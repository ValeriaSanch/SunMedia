<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\RefreshToken;

use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetRefreshTokenDataTransformer implements ResponseDataTransformer
{
    /** @var GetRefreshTokenQueryResponse */
    private $getRefreshTokenQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getRefreshTokenQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return [
            'token_type' => $this->getRefreshTokenQueryResponse->tokenType(),
            'access_token' => $this->getRefreshTokenQueryResponse->accessToken()->token()->value(),
            'expires_in' => $this->getRefreshTokenQueryResponse->accessToken()->expiresIn(),
            'refresh_token' => $this->getRefreshTokenQueryResponse->refreshToken()->token()->value(),
        ];
    }
}
