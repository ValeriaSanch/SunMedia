<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Carrier\CarrierList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiCarrierTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiPaginatorDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetCarrierListDataTransformer extends JsonApiPaginatorDataTransformer implements ResponseDataTransformer
{
    /** @var GetCarrierListQueryResponse */
    private $getCarrierListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getCarrierListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getCarrierListQueryResponse,
            new JsonApiCarrierTransformer(),
            'carriers'
        );
    }
}
