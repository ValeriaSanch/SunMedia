<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\RefreshToken;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Model\User\SecurityUserRepository;
use SunMedia\Shared\Domain\Model\User\Token\Exception\ExpiredRefreshToken;
use SunMedia\Shared\Domain\Model\User\Token\RefreshToken;
use SunMedia\Shared\Domain\Model\User\Token\RefreshTokenRepository;
use SunMedia\Shared\Domain\Model\User\Token\Token;
use SunMedia\Shared\Domain\Model\User\UserTokenGenerator;

class GetRefreshTokenQueryService
{
    /** @var GetRefreshTokenDataTransformer */
    private $dataTransformer;

    /** @var SecurityUserRepository */
    private $userRepository;

    /** @var RefreshTokenRepository */
    private $refreshTokenRepository;

    /** @var UserTokenGenerator */
    private $tokenGenerator;

    public function __construct(
        GetRefreshTokenDataTransformer $dataTransformer,
        SecurityUserRepository $userRepository,
        RefreshTokenRepository $refreshTokenRepository,
        UserTokenGenerator $tokenGenerator
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->userRepository = $userRepository;
        $this->refreshTokenRepository = $refreshTokenRepository;
        $this->tokenGenerator = $tokenGenerator;
    }

    /**
     * @throws ExpiredRefreshToken
     */
    public function execute(Token $token): array
    {
        /** @var RefreshToken $refreshToken */
        $refreshToken = $this->refreshTokenRepository->byToken($token);

        if (null === $refreshToken || $refreshToken->isExpired()) {
            throw new ExpiredRefreshToken();
        }

        $user = $this->userRepository->byId($refreshToken->userId(), new Criteria());

        $this->dataTransformer->write(new GetRefreshTokenQueryResponse(
            $this->tokenGenerator->generate($user->id()),
            'bearer',
            $refreshToken
        ));

        return $this->dataTransformer->read();
    }
}
