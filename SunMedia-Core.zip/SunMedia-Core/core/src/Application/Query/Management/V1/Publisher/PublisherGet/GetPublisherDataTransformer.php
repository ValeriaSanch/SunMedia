<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Publisher\PublisherGet;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiPublisherTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiResourceDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetPublisherDataTransformer extends JsonApiResourceDataTransformer implements ResponseDataTransformer
{
    /** @var GetPublisherQueryResponse */
    private $getPublisherResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getPublisherResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getPublisherResponse,
            new JsonApiPublisherTransformer(),
            'publishers'
        );
    }
}
