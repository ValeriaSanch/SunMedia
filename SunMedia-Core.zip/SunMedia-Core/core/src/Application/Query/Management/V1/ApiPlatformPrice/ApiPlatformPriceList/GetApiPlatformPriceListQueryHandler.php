<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\ApiPlatformPrice\ApiPlatformPriceList;

use SunMedia\Core\Domain\Model\ApiPlatformPrice\Exception\ApiPlatformPriceEmptyValue;

class GetApiPlatformPriceListQueryHandler
{
    /** @var GetApiPlatformPriceValidation */
    private $getApiPlatformPriceValidation;

    /** @var GetApiPlatformPriceListQueryService */
    private $getApiPlatformPriceQueryService;

    public function __construct(
        GetApiPlatformPriceValidation $getApiPlatformPriceValidation,
        GetApiPlatformPriceListQueryService $getApiPlatformPriceQueryService
    ) {
        $this->getApiPlatformPriceValidation = $getApiPlatformPriceValidation;
        $this->getApiPlatformPriceQueryService = $getApiPlatformPriceQueryService;
    }

    /**
     * @throws ApiPlatformPriceEmptyValue
     */
    public function __invoke(GetApiPlatformPriceListQuery $getApiPlatformPriceQuery): array
    {
        return $this->getApiPlatformPriceQueryService->execute(
            ...$this->getApiPlatformPriceValidation->validate($getApiPlatformPriceQuery)
        );
    }
}
