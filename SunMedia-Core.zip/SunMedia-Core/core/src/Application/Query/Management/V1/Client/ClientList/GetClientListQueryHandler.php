<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Client\ClientList;

class GetClientListQueryHandler
{
    /** @var GetClientListQueryService */
    private $getClientListQueryService;

    public function __construct(GetClientListQueryService $getClientListQueryService)
    {
        $this->getClientListQueryService = $getClientListQueryService;
    }

    public function __invoke(GetClientListQuery $getUserQuery): array
    {
        return $this->getClientListQueryService->execute(
            $getUserQuery->loggedUser(),
            $getUserQuery->filters(),
            $getUserQuery->page(),
            $getUserQuery->size(),
            $getUserQuery->getIncludes(),
            $getUserQuery->getOrder(),
            $getUserQuery->query()
        );
    }
}
