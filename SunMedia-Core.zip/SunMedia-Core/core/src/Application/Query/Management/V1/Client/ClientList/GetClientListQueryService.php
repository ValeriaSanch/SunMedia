<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Client\ClientList;

use SunMedia\Core\Domain\Model\Client\ClientCriteriaFactory;
use SunMedia\Core\Domain\Model\Client\ClientRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetClientListQueryService extends PaginatorService
{
    /** @var ClientRepository */
    private $clientRepository;

    public function __construct(
        ClientRepository $clientRepository,
        GetClientListDataTransformer $dataTransformer,
        ClientCriteriaFactory $clientCriteriaFactory
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->clientRepository = $clientRepository;
        $this->criteriaFactory = $clientCriteriaFactory;
    }

    protected function makeQueryResponse(): GetClientListQueryResponse
    {
        return new GetClientListQueryResponse(
            $this->clientRepository->byCriteria($this->defaultCriteria, $this->loggedUser),
            $this->page,
            $this->size,
            $this->clientRepository->count($this->defaultCriteria, $this->loggedUser),
            $this->fields
        );
    }
}
