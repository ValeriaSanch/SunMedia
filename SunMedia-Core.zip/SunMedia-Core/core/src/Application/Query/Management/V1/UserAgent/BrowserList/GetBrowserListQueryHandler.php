<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\UserAgent\BrowserList;

class GetBrowserListQueryHandler
{
    private $getUserQueryService;

    public function __construct(GetBrowserListQueryService $getUserQueryService)
    {
        $this->getUserQueryService = $getUserQueryService;
    }

    public function __invoke(GetBrowserListQuery $getUserQuery): array
    {
        return $this->getUserQueryService->execute(
            $getUserQuery->loggedUser(),
            $getUserQuery->filters(),
            $getUserQuery->page(),
            $getUserQuery->size(),
            $getUserQuery->getIncludes(),
            $getUserQuery->getOrder(),
            $getUserQuery->query()
        );
    }
}
