<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\CategoryGet;

use SunMedia\Shared\Domain\Model\Category\CategoryId;
use SunMedia\Shared\Domain\Model\Category\CategoryRepository;
use SunMedia\Shared\Domain\Model\Category\Exception\CategoryNotFound;

final class GetCategoryQueryService
{
    /** @var CategoryRepository */
    private $categoryRepository;

    /** @var GetCategoryDataTransformer */
    private $dataTransformer;

    public function __construct(CategoryRepository $categoryRepository, GetCategoryDataTransformer $dataTransformer)
    {
        $this->categoryRepository = $categoryRepository;
        $this->dataTransformer = $dataTransformer;
    }

    /**
     * @throws CategoryNotFound
     */
    public function execute(CategoryId $categoryId, array $includes): array
    {
        $category = $this->categoryRepository->byId($categoryId);

        if (is_null($category)) {
            throw new CategoryNotFound($categoryId);
        }

        $this->dataTransformer->write(new GetCategoryQueryResponse($category, $includes));

        return $this->dataTransformer->read();
    }
}
