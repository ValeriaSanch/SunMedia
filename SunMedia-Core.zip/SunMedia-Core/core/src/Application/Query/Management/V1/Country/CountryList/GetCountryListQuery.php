<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Country\CountryList;

use SunMedia\Shared\Application\Query\QueryPaginator;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class GetCountryListQuery extends QueryPaginator
{
    public const ACTION = 'MANAGEMENT_COUNTRY_SHOW_LIST';

    private $all;

    public function __construct(
        ?SecurityUser $loggedUser,
        bool $all,
        array $filters,
        int $page,
        int $size,
        ?string $query,
        ?string $orderBy,
        ?string $orderType,
        ?array $include
    ) {
        parent::__construct($loggedUser, $filters, $page, $size, $query, $orderBy, $orderType, $include);
        $this->all = $all;
    }

    public function all(): bool
    {
        return $this->all;
    }

    protected function setDefaultOrder(): void
    {
        $this->orderType = 'asc';
        $this->orderBy = 'name';
    }

    protected function availableOrders(): array
    {
        return ['country.name'];
    }
}
