<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Carrier\CarrierGet;

use SunMedia\Core\Domain\Model\Carrier\CarrierId;
use SunMedia\Core\Domain\Model\Carrier\Exception\CarrierNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;

class GetCarrierQueryHandler
{
    /** @var GetCarrierQueryService */
    private $getCarrierQueryService;

    public function __construct(GetCarrierQueryService $getCarrierQueryService)
    {
        $this->getCarrierQueryService = $getCarrierQueryService;
    }

    /**
     * @throws CarrierNotFound
     * @throws DomainException
     */
    public function __invoke(GetCarrierQuery $getCarrierQuery): array
    {
        return $this->getCarrierQueryService->execute(
            new CarrierId($getCarrierQuery->carrierId()),
            $getCarrierQuery->includes()
        );
    }
}
