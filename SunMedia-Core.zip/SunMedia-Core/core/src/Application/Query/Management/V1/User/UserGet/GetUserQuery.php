<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\UserGet;

use SunMedia\Shared\Application\Query\QuerySingleResource;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class GetUserQuery extends QuerySingleResource
{
    public const ACTION = 'MANAGEMENT_USER_SHOW';

    /** @var string */
    private $userId;

    public function __construct(SecurityUser $loggedUser, string $userId, array $includes)
    {
        parent::__construct($loggedUser, $includes);
        $this->userId = $userId;
    }

    public function userId(): string
    {
        return $this->userId;
    }
}
