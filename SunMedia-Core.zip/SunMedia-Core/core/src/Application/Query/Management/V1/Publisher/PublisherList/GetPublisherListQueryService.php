<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Publisher\PublisherList;

use SunMedia\Core\Domain\Model\Publisher\PublisherCriteriaFactory;
use SunMedia\Core\Domain\Model\Publisher\PublisherRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetPublisherListQueryService extends PaginatorService
{
    /** @var PublisherRepository */
    private $publisherRepository;

    public function __construct(
        PublisherRepository $publisherRepository,
        GetPublisherListDataTransformer $dataTransformer,
        PublisherCriteriaFactory $publisherCriteriaFactory
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->publisherRepository = $publisherRepository;
        $this->criteriaFactory = $publisherCriteriaFactory;
    }

    protected function makeQueryResponse(): GetPublisherListQueryResponse
    {
        return new GetPublisherListQueryResponse(
            $this->publisherRepository->byCriteria($this->defaultCriteria),
            $this->page,
            $this->size,
            $this->publisherRepository->count($this->defaultCriteria),
            $this->fields
        );
    }
}
