<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Language\GetLanguageList;

use SunMedia\Core\Domain\Model\Language\LanguageRepository;
use SunMedia\Shared\Application\Query\PaginatorService;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Model\Language\LanguageCriteriaFactory;

class GetLanguageListQueryService extends PaginatorService
{
    private $languageRepository;

    public function __construct(
        LanguageRepository $languageRepository,
        LanguageCriteriaFactory $languageCriteriaFactory,
        GetLanguageListDataTransformer $dataTransformer
    ) {
        $this->dataTransformer = $dataTransformer;
        $this->languageRepository = $languageRepository;
        $this->criteriaFactory = $languageCriteriaFactory;
    }

    protected function makeQueryResponse(): GetLanguageListQueryResponse
    {
        $languages = $this->languageRepository->byCriteria(new Criteria());

        return new GetLanguageListQueryResponse(
            $languages,
            $this->page,
            $this->size,
            $languages->count(),
            $this->fields
        );
    }
}
