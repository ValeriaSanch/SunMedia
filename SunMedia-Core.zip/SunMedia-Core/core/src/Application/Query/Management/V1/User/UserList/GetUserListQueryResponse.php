<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\UserList;

use SunMedia\Core\Domain\Model\User\UserCollection;
use SunMedia\Shared\Domain\Bus\PaginatorResponse;
use SunMedia\Shared\Domain\Bus\QueryResponse;
use SunMedia\Shared\Domain\Collection\AbstractCollection;
use SunMedia\Shared\Domain\Criteria\FieldCollection;

class GetUserListQueryResponse implements QueryResponse, PaginatorResponse
{
    private $collection;

    /** @var int */
    private $page;

    /** @var int */
    private $itemsPerPage;

    /** @var int */
    private $totalResults;

    /** @var FieldCollection */
    private $includes;

    public function __construct(
        UserCollection $userCollection,
        int $page,
        int $itemsPerPage,
        int $totalResults,
        FieldCollection $fields
    ) {
        $this->collection = $userCollection;
        $this->page = $page;
        $this->itemsPerPage = $itemsPerPage;
        $this->totalResults = $totalResults;
        $this->includes = $fields;
    }

    public function collection(): AbstractCollection
    {
        return $this->collection;
    }

    public function page(): int
    {
        return $this->page;
    }

    public function size(): int
    {
        return $this->itemsPerPage;
    }

    public function totalResults(): int
    {
        return $this->totalResults;
    }

    public function includes(): FieldCollection
    {
        return $this->includes;
    }
}
