<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\ApiPlatformPrice\ApiPlatformPriceList;

use SunMedia\Shared\Domain\Bus\QueryResponse;
use SunMedia\Shared\Domain\Criteria\FieldCollection;

class GetApiPlatformPriceListQueryResponse implements QueryResponse
{
    /** @var array */
    private $array;

    /** @var int */
    private $page;

    /** @var int */
    private $itemsPerPage;

    /** @var int */
    private $totalResults;

    /** @var FieldCollection */
    private $includes;

    public function __construct(
        array $apiPlatformPriceCollection,
        int $page,
        int $itemsPerPage,
        int $totalResults,
        FieldCollection $includes
    ) {
        $this->array = $apiPlatformPriceCollection;
        $this->page = $page;
        $this->itemsPerPage = $itemsPerPage;
        $this->totalResults = $totalResults;
        $this->includes = $includes;
    }

    public function array(): array
    {
        return $this->array;
    }

    public function page(): int
    {
        return $this->page;
    }

    public function size(): int
    {
        return $this->itemsPerPage;
    }

    public function totalResults(): int
    {
        return $this->totalResults;
    }

    public function includes(): FieldCollection
    {
        return $this->includes;
    }
}
