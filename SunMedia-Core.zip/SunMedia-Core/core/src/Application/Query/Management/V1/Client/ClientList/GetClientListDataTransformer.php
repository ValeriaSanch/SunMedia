<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Client\ClientList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiClientTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiPaginatorDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetClientListDataTransformer extends JsonApiPaginatorDataTransformer implements ResponseDataTransformer
{
    /** @var GetClientListQueryResponse */
    private $getClientListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getClientListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getClientListQueryResponse,
            new JsonApiClientTransformer(),
            'clients'
        );
    }
}
