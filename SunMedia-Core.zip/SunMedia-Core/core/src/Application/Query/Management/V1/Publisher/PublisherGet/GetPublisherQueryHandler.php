<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Publisher\PublisherGet;

use SunMedia\Core\Domain\Model\Publisher\Exception\PublisherNotFound;
use SunMedia\Core\Domain\Model\Publisher\PublisherId;
use SunMedia\Shared\Domain\Exception\DomainException;

class GetPublisherQueryHandler
{
    /** @var GetPublisherQueryService */
    private $getPublisherQueryService;

    public function __construct(GetPublisherQueryService $getPublisherQueryService)
    {
        $this->getPublisherQueryService = $getPublisherQueryService;
    }

    /**
     * @throws DomainException
     * @throws PublisherNotFound
     */
    public function __invoke(GetPublisherQuery $getPublisherQuery): array
    {
        return $this->getPublisherQueryService->execute(
            $getPublisherQuery->loggedUser(),
            new PublisherId($getPublisherQuery->publisherId()),
            $getPublisherQuery->includes()
        );
    }
}
