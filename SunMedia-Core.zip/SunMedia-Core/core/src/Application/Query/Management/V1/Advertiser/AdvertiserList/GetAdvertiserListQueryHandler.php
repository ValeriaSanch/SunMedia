<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Advertiser\AdvertiserList;

class GetAdvertiserListQueryHandler
{
    /** @var GetAdvertiserListQueryService */
    private $advertiserQueryService;

    public function __construct(GetAdvertiserListQueryService $advertiserQueryService)
    {
        $this->advertiserQueryService = $advertiserQueryService;
    }

    public function __invoke(GetAdvertiserListQuery $getAdvertiserQuery): array
    {
        return $this->advertiserQueryService->execute(
            $getAdvertiserQuery->loggedUser(),
            $getAdvertiserQuery->filters(),
            $getAdvertiserQuery->page(),
            $getAdvertiserQuery->size(),
            $getAdvertiserQuery->getIncludes(),
            $getAdvertiserQuery->getOrder(),
            $getAdvertiserQuery->query()
        );
    }
}
