<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Country\CountryList;

use SunMedia\Core\Domain\Model\Geolocation\Country\CountryCriteriaFactory;
use SunMedia\Core\Domain\Model\Geolocation\Country\CountryRepository;
use SunMedia\Shared\Application\Query\PaginatorService;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;

class GetCountryListQueryService extends PaginatorService
{
    private $countryRepository;

    /** @var bool */
    private $all;

    public function __construct(
        CountryRepository $countryRepository,
        CountryCriteriaFactory $criteriaFactory,
        GetCountryListDataTransformer $dataTransformer
    ) {
        $this->countryRepository = $countryRepository;
        $this->criteriaFactory = $criteriaFactory;
        $this->dataTransformer = $dataTransformer;
    }

    public function setAllFlag(bool $all): void
    {
        $this->all = $all;
    }

    protected function makeQueryResponse(): GetCountryListQueryResponse
    {
        $countryCollection = $this->all
            ? $this->countryRepository->byCriteria(new Criteria())
            : $this->countryRepository->byCriteria($this->defaultCriteria);

        $count = $this->all ? $countryCollection->count() : $this->countryRepository->count($this->defaultCriteria);

        return new GetCountryListQueryResponse(
            $countryCollection,
            $this->all ? 1 : $this->page,
            $this->all ? $count : $this->size,
            $count,
            $this->fields
        );
    }
}
