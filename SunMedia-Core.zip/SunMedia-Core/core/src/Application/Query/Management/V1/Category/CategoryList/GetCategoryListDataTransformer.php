<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\CategoryList;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiCategoryTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetCategoryListDataTransformer extends JsonApiDataTransformer implements ResponseDataTransformer
{
    /** @var GetCategoryListQueryResponse */
    private $getCategoryListQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getCategoryListQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getCategoryListQueryResponse->categories()->toArray(),
            new JsonApiCategoryTransformer(),
            'categories'
        );
    }
}
