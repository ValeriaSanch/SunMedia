<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Client\ClientGet;

use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNotFound;
use SunMedia\Shared\Domain\Exception\DomainException;

class GetClientQueryHandler
{
    /** @var GetClientQueryService */
    private $getClientQueryService;

    public function __construct(GetClientQueryService $getClientQueryService)
    {
        $this->getClientQueryService = $getClientQueryService;
    }

    /**
     * @throws DomainException
     * @throws ClientNotFound
     */
    public function __invoke(GetClientQuery $getUserQuery): array
    {
        return $this->getClientQueryService->execute(
            $getUserQuery->loggedUser(),
            new ClientId($getUserQuery->clientId()),
            $getUserQuery->includes()
        );
    }
}
