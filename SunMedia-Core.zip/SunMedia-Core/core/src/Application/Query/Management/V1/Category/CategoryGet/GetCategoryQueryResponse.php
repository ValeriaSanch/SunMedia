<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\CategoryGet;

use SunMedia\Shared\Domain\Bus\SingleResourceResponse;
use SunMedia\Shared\Domain\Model\Category\Category;

final class GetCategoryQueryResponse implements SingleResourceResponse
{
    /** @var Category */
    private $resource;

    /** @var array */
    private $includes;

    public function __construct(Category $category, array $includes)
    {
        $this->resource = $category;
        $this->includes = $includes;
    }

    public function resource(): Category
    {
        return $this->resource;
    }

    public function includes(): array
    {
        return $this->includes;
    }
}
