<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Publisher\PublisherGet;

use SunMedia\Shared\Application\Query\QuerySingleResource;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class GetPublisherQuery extends QuerySingleResource
{
    public const ACTION = 'MANAGEMENT_PUBLISHER_SHOW';

    /** @var string */
    private $publisherId;

    public function __construct(SecurityUser $loggedUser, string $publisherId, array $includes)
    {
        parent::__construct($loggedUser, $includes);
        $this->publisherId = $publisherId;
    }

    public function publisherId(): string
    {
        return $this->publisherId;
    }
}
