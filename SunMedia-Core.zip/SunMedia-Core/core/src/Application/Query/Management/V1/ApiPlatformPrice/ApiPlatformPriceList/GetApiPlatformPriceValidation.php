<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\ApiPlatformPrice\ApiPlatformPriceList;

use SunMedia\Core\Domain\Model\ApiPlatformPrice\Exception\ApiPlatformPriceEmptyValue;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\InvalidArgumentNotFound;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class GetApiPlatformPriceValidation
{
    /**
     * @throws ApiPlatformPriceEmptyValue
     * @throws DomainException
     */
    public function validate(GetApiPlatformPriceListQuery $apiPlatformPriceListQuery): array
    {
        $this->validateGroups($apiPlatformPriceListQuery);
        $this->validateDates($apiPlatformPriceListQuery->filters());

        return [
            $apiPlatformPriceListQuery->filters(),
            $this->getOrderings($apiPlatformPriceListQuery->getOrder()),
            $apiPlatformPriceListQuery->page(),
            $apiPlatformPriceListQuery->size(),
            $apiPlatformPriceListQuery->group(),
        ];
    }

    /**
     * @throws DomainException
     */
    private function validateGroups(GetApiPlatformPriceListQuery $apiPlatformPriceListQuery): void
    {
        foreach ($apiPlatformPriceListQuery->group() as $group) {
            if (!in_array($group, $apiPlatformPriceListQuery->availableGroups(), true)) {
                throw new DomainException(sprintf('Group value %s not found!', $group), DomainException::BAD_REQUEST);
            }
        }
    }

    private function getOrderings($order): array
    {
        if (null !== $order) {
            return [$order->orderBy()->value() => $order->orderType()->value()];
        }

        return [];
    }

    private function validateDates(array $filters)
    {
        $startDate = $filters['start_date'] ? SMDatetime::fromString($filters['start_date']) : null;
        $endDate = $filters['end_date'] ? SMDatetime::fromString($filters['end_date']) : null;

        if (!$startDate || !$endDate) {
            throw new InvalidArgumentNotFound('start_date or end_date');
        }

        if ($startDate > $endDate) {
            throw new \Exception("Date start don't must greater end date!");
        }
    }
}
