<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\AccountGet;

use SunMedia\Core\Domain\Model\SalesforceAccount\Exception\SalesforceAccountNotFound;
use SunMedia\Core\Domain\Model\SalesforceAccount\SalesforceAccountId;
use SunMedia\Core\Domain\Model\SalesforceAccount\SalesforceAccountRepository;

class GetSalesforceAccountQueryService
{
    /** @var SalesforceAccountRepository */
    private $accountSalesforceRepository;

    /** @var GetSalesforceAccountDataTransformer */
    private $dataTransformer;

    public function __construct(
        SalesforceAccountRepository $accountSalesforceRepository,
        GetSalesforceAccountDataTransformer $dataTransformer
    ) {
        $this->accountSalesforceRepository = $accountSalesforceRepository;
        $this->dataTransformer = $dataTransformer;
    }

    /**
     * @throws SalesforceAccountNotFound
     */
    public function execute(SalesforceAccountId $accountId, array $includes): array
    {
        $account = $this->accountSalesforceRepository->byId($accountId);

        if (true === is_null($account)) {
            throw new SalesforceAccountNotFound($accountId);
        }

        $this->dataTransformer->write(new GetSalesforceAccountQueryResponse($account, $includes));

        return $this->dataTransformer->read();
    }
}
