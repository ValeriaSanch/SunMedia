<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Carrier\CarrierList;

class GetCarrierListQueryHandler
{
    /** @var GetCarrierListQueryService */
    private $getCarrierListQueryService;

    public function __construct(GetCarrierListQueryService $getCarrierListQueryService)
    {
        $this->getCarrierListQueryService = $getCarrierListQueryService;
    }

    public function __invoke(GetCarrierListQuery $getUserQuery): array
    {
        return $this->getCarrierListQueryService->execute(
            $getUserQuery->loggedUser(),
            $getUserQuery->filters(),
            $getUserQuery->page(),
            $getUserQuery->size(),
            $getUserQuery->getIncludes(),
            $getUserQuery->getOrder(),
            $getUserQuery->query()
        );
    }
}
