<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Client\ClientGet;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiClientTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiResourceDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetClientDataTransformer extends JsonApiResourceDataTransformer implements ResponseDataTransformer
{
    /** @var GetClientQueryResponse */
    private $getClientResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getClientResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getClientResponse,
            new JsonApiClientTransformer(),
            'clients'
        );
    }
}
