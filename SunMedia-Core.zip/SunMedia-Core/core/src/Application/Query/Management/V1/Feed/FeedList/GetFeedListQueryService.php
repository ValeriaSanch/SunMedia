<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Feed\FeedList;

use SunMedia\Core\Domain\Model\Feed\FeedCriteriaFactory;
use SunMedia\Core\Domain\Model\Feed\FeedRepository;
use SunMedia\Shared\Application\Query\PaginatorService;

class GetFeedListQueryService extends PaginatorService
{
    /** @var FeedRepository */
    private $feedRepository;

    public function __construct(
        FeedRepository $feedRepository,
        GetFeedListDataTransformer $dataTransformer,
        FeedCriteriaFactory $criteriaFactory
    ) {
        $this->feedRepository = $feedRepository;
        $this->dataTransformer = $dataTransformer;
        $this->criteriaFactory = $criteriaFactory;
    }

    protected function makeQueryResponse(): GetFeedListQueryResponse
    {
        return new GetFeedListQueryResponse(
            $this->feedRepository->byCriteria($this->defaultCriteria),
            $this->page,
            $this->size,
            $this->feedRepository->count($this->defaultCriteria),
            $this->fields
        );
    }
}
