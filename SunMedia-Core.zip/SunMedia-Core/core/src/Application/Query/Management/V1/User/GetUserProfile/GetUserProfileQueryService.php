<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\GetUserProfile;

use SunMedia\Core\Domain\Model\User\User;

class GetUserProfileQueryService
{
    /** @var GetUserProfileDataTransformer */
    private $dataTransformer;

    public function __construct(GetUserProfileDataTransformer $dataTransformer)
    {
        $this->dataTransformer = $dataTransformer;
    }

    public function execute(User $loggedUser): array
    {
        $this->dataTransformer->write(new GetUserProfileQueryResponse($loggedUser));

        return $this->dataTransformer->read();
    }
}
