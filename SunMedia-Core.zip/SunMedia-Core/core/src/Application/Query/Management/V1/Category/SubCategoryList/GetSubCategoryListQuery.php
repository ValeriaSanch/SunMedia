<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\SubCategoryList;

class GetSubCategoryListQuery
{
    /** @var string */
    private $category;

    public function __construct(string $category)
    {
        $this->category = $category;
    }

    public function category(): string
    {
        return $this->category;
    }
}
