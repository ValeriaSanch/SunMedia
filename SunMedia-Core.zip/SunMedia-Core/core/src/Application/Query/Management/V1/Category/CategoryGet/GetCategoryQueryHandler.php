<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Category\CategoryGet;

use SunMedia\Shared\Domain\Model\Category\CategoryId;
use SunMedia\Shared\Domain\Model\Category\Exception\CategoryNotFound;

final class GetCategoryQueryHandler
{
    /** @var GetCategoryQueryService */
    private $getCategoryQueryService;

    public function __construct(GetCategoryQueryService $getCategoryQueryService)
    {
        $this->getCategoryQueryService = $getCategoryQueryService;
    }

    /**
     * @throws CategoryNotFound
     */
    public function __invoke(GetCategoryQuery $getUserQuery): array
    {
        return $this->getCategoryQueryService->execute(
            new CategoryId($getUserQuery->categoryId()),
            $getUserQuery->includes()
        );
    }
}
