<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Advertiser\AdvertiserGet;

use SunMedia\Core\Domain\Model\Advertiser\Advertiser;
use SunMedia\Core\Domain\Model\Advertiser\AdvertiserCriteriaFactory;
use SunMedia\Core\Domain\Model\Advertiser\AdvertiserId;
use SunMedia\Core\Domain\Model\Advertiser\AdvertiserRepository;
use SunMedia\Core\Domain\Model\Advertiser\Exception\AdvertiserNotFound;
use SunMedia\Core\Domain\Model\User\User;

class GetAdvertiserQueryService
{
    /** @var AdvertiserRepository */
    private $advertiserRepository;

    /** @var GetAdvertiserDataTransformer */
    private $advertiserDataTransformer;

    /** @var AdvertiserCriteriaFactory */
    private $advertiserCriteria;

    public function __construct(
        AdvertiserRepository $advertiserRepository,
        GetAdvertiserDataTransformer $advertiserDataTransformer,
        AdvertiserCriteriaFactory $advertiserCriteria
    ) {
        $this->advertiserRepository = $advertiserRepository;
        $this->advertiserDataTransformer = $advertiserDataTransformer;
        $this->advertiserCriteria = $advertiserCriteria;
    }

    /**
     * @throws AdvertiserNotFound
     */
    public function execute(User $loggerUser, AdvertiserId $advertiserId, array $includes): array
    {
        $advertiser = $this->getAdvertiserForUser($advertiserId, $loggerUser);

        $this->advertiserDataTransformer->write(new GetAdvertiserQueryResponse($advertiser, $includes));

        return $this->advertiserDataTransformer->read();
    }

    /**
     * @throws AdvertiserNotFound
     */
    private function getAdvertiserForUser(AdvertiserId $advertiserId, User $user): Advertiser
    {
        $advertiser = $this->advertiserRepository->byId(
            $advertiserId,
            $this->advertiserCriteria->getUserCriteria($user)
        );

        if (null === $advertiser) {
            throw new AdvertiserNotFound($advertiserId);
        }

        return $advertiser;
    }
}
