<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Language\CheckLanguage;

use SunMedia\Shared\Application\Query\QuerySingleResource;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class CheckLanguageQuery extends QuerySingleResource
{
    public const ACTION = 'MANAGEMENT_CHECK_LANGUAGE';

    /** @var string */
    private $languageId;

    public function __construct(?SecurityUser $loggedUser, string $languageId, array $includes)
    {
        parent::__construct($loggedUser, $includes);
        $this->languageId = $languageId;
    }

    public function languageId(): string
    {
        return $this->languageId;
    }
}
