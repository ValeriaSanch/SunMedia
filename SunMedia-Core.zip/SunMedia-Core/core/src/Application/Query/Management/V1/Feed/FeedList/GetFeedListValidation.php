<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Feed\FeedList;

use SunMedia\Shared\Domain\Exception\EmptyValue;

class GetFeedListValidation
{
    private const FILTER_CLIENT = 'client.id';

    /**
     * @throws EmptyValue
     */
    public function validate(GetFeedListQuery $getFeedListQuery): array
    {
        return [
            $getFeedListQuery->loggedUser(),
            $this->validateFilters($getFeedListQuery->filters()),
            $getFeedListQuery->page(),
            $getFeedListQuery->size(),
            $getFeedListQuery->getIncludes(),
            $getFeedListQuery->getOrder(),
            $getFeedListQuery->query(),
        ];
    }

    /**
     * @throws EmptyValue
     */
    private function validateFilters(array $filters): array
    {
        $this->validateClient($filters[self::FILTER_CLIENT] ?? '');

        return $filters;
    }

    /**
     * @throws EmptyValue
     */
    private function validateClient(string $clientId): void
    {
        if (!trim($clientId)) {
            throw new EmptyValue(self::FILTER_CLIENT);
        }
    }
}
