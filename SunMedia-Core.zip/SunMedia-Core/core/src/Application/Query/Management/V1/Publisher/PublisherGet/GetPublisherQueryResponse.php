<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Publisher\PublisherGet;

use SunMedia\Core\Domain\Model\Publisher\Publisher;
use SunMedia\Shared\Domain\Bus\SingleResourceResponse;

class GetPublisherQueryResponse implements SingleResourceResponse
{
    /** @var Publisher */
    private $resource;

    /** @var array */
    private $includes;

    public function __construct(Publisher $publisher, array $includes)
    {
        $this->resource = $publisher;
        $this->includes = $includes;
    }

    public function resource(): Publisher
    {
        return $this->resource;
    }

    public function includes(): array
    {
        return $this->includes;
    }
}
