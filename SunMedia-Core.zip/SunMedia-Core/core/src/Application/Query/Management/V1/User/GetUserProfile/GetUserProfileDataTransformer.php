<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\GetUserProfile;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiProfileTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiResourceDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetUserProfileDataTransformer extends JsonApiResourceDataTransformer implements ResponseDataTransformer
{
    /** @var GetUserProfileQueryResponse */
    private $getUserQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getUserQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getUserQueryResponse,
            new JsonApiProfileTransformer(),
            'users'
        );
    }
}
