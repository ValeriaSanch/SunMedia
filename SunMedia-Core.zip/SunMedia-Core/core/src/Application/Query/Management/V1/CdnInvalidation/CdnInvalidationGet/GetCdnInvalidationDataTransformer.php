<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\CdnInvalidation\CdnInvalidationGet;

use SunMedia\Core\Infrastructure\Delivery\Response\JsonApi\Transformer\JsonApiCdnInvalidationTransformer;
use SunMedia\Shared\Application\Query\Transformer\JsonApiResourceDataTransformer;
use SunMedia\Shared\Application\Query\Transformer\ResponseDataTransformer;
use SunMedia\Shared\Domain\Bus\QueryResponse;

class GetCdnInvalidationDataTransformer extends JsonApiResourceDataTransformer implements ResponseDataTransformer
{
    /** @var GetCdnInvalidationQueryResponse */
    private $getCdnInvalidationQueryResponse;

    public function write(QueryResponse $queryResponse): void
    {
        $this->getCdnInvalidationQueryResponse = $queryResponse;
    }

    public function read(): array
    {
        return $this->serializer->serialize(
            $this->getCdnInvalidationQueryResponse,
            new JsonApiCdnInvalidationTransformer(),
            'invalidation'
        );
    }
}
