<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Salesforce\AccountGet;

use SunMedia\Core\Domain\Model\SalesforceAccount\SalesforceAccount;
use SunMedia\Shared\Domain\Bus\SingleResourceResponse;

class GetSalesforceAccountQueryResponse implements SingleResourceResponse
{
    /** @var SalesforceAccount */
    private $resource;

    /** @var array */
    private $includes;

    public function __construct(SalesforceAccount $account, array $includes)
    {
        $this->resource = $account;
        $this->includes = $includes;
    }

    public function resource(): SalesforceAccount
    {
        return $this->resource;
    }

    public function includes(): array
    {
        return $this->includes;
    }
}
