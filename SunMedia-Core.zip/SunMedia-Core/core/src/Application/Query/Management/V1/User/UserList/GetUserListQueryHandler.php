<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\User\UserList;

class GetUserListQueryHandler
{
    private $getUserQueryService;

    public function __construct(GetUserListQueryService $getUserQueryService)
    {
        $this->getUserQueryService = $getUserQueryService;
    }

    public function __invoke(GetUserListQuery $getUserQuery): array
    {
        return $this->getUserQueryService->execute(
            $getUserQuery->loggedUser(),
            $getUserQuery->filters(),
            $getUserQuery->page(),
            $getUserQuery->size(),
            $getUserQuery->getIncludes(),
            $getUserQuery->getOrder(),
            $getUserQuery->query()
        );
    }
}
