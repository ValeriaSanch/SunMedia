<?php

declare(strict_types=1);

namespace SunMedia\Core\Application\Query\Management\V1\Feed\FeedList;

use SunMedia\Shared\Domain\Exception\EmptyValue;

class GetFeedListQueryHandler
{
    private $getFeedQueryService;

    /** @var GetFeedListValidation */
    private $getFeedListValidation;

    public function __construct(
        GetFeedListValidation $getFeedListValidation,
        GetFeedListQueryService $getFeedQueryService
    ) {
        $this->getFeedQueryService = $getFeedQueryService;
        $this->getFeedListValidation = $getFeedListValidation;
    }

    /**
     * @throws EmptyValue
     */
    public function __invoke(GetFeedListQuery $getFeedListQuery): array
    {
        return $this->getFeedQueryService->execute(...$this->getFeedListValidation->validate($getFeedListQuery));
    }
}
