<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\ApiPlatformPrice;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Criteria\Expr\ExpressionBuilder;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class ApiPlatformPriceCriteriaFactory
{
    private static $fieldToSearch = [];

    public function fieldToSearch(): array
    {
        return self::$fieldToSearch;
    }

    public function getUserCriteria(SecurityUser $user): Criteria
    {
        $comparison = null;

        return new Criteria($comparison);
    }

    public function byDate(
        ApiPlatformPriceDate $startDate,
        ApiPlatformPriceDate $endDate
    ): Criteria {
        $expressionBuilder = new ExpressionBuilder();
        $expression = $expressionBuilder->andX(
            $expressionBuilder->gte('date', $startDate->value()->format(ApiPlatformPriceDate::FORMAT)),
            $expressionBuilder->lte('date', $endDate->value()->format(ApiPlatformPriceDate::FORMAT))
        );

        return new Criteria($expression);
    }

    public function byFilters(array $filters, array $order, int $page, int $size): Criteria
    {
        $expressionBuilder = new ExpressionBuilder();

        $filter[] = $expressionBuilder->gte('date', $filters['start_date']);
        $filter[] = $expressionBuilder->lte('date', $filters['end_date']);
        foreach ($filters as $index => $value) {
            if (!in_array($index, ['start_date', 'end_date'])) {
                $filter[] = $expressionBuilder->eq($index, $value);
            }
        }

        $expression = $expressionBuilder->andX(...$filter);

        return new Criteria($expression, $order ?: ['date' => 'ASC'], ($page - 1) * $size, $size);
    }
}
