<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\ApiPlatformPrice;

use SunMedia\Shared\Domain\ValueObject\Uuid;

class ApiPlatformPriceId extends Uuid
{
}
