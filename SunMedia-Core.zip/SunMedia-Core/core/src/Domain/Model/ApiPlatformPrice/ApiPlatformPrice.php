<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\ApiPlatformPrice;

class ApiPlatformPrice
{
    /** @var ApiPlatformPriceId */
    private $id;

    /** @var ApiPlatformPriceDate */
    private $date;

    /** @var ApiPlatformPriceCountry */
    private $country;

    /** @var ApiPlatformPricePrice */
    private $price;

    private function __construct(
        ApiPlatformPriceId $id,
        ApiPlatformPriceDate $date,
        ApiPlatformPriceCountry $country,
        ApiPlatformPricePrice $price
    ) {
        $this->id = $id;
        $this->date = $date;
        $this->country = $country;
        $this->price = $price;
    }

    public static function create(
        ApiPlatformPriceId $id,
        ApiPlatformPriceDate $date,
        ApiPlatformPriceCountry $country,
        ApiPlatformPricePrice $price
    ): ApiPlatformPrice {
        return new self(
            $id,
            $date,
            $country,
            $price
        );
    }

    public function id(): ApiPlatformPriceId
    {
        return $this->id;
    }

    public function date(): ApiPlatformPriceDate
    {
        return $this->date;
    }

    public function country(): ApiPlatformPriceCountry
    {
        return $this->country;
    }

    public function price(): ApiPlatformPricePrice
    {
        return $this->price;
    }
}
