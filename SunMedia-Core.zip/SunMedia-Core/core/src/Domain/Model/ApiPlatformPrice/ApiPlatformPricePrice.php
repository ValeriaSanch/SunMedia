<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\ApiPlatformPrice;

use SunMedia\Shared\Domain\ValueObject\FloatValueObject;

class ApiPlatformPricePrice extends FloatValueObject
{
}
