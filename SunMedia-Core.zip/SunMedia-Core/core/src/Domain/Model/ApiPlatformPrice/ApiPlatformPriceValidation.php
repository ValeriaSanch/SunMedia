<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\ApiPlatformPrice;

use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use SunMedia\Core\Domain\Model\ApiPlatformPrice\Exception\ApiPlatformPriceEmptyValue;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Infrastructure\Service\DetectDelimiterCsv;

class ApiPlatformPriceValidation
{
    private const RECORDS_SAVE = 10000;

    private const HEADERS_ALLOWED = ['country', 'price'];

    /** @var EntityManagerInterface */
    private $entityManager;

    /** @var LoggerInterface */
    private $logger;

    public function __construct(EntityManagerInterface $entityManager, LoggerInterface $logger)
    {
        $this->entityManager = $entityManager;
        $this->logger = $logger;
    }

    /**
     * @param mixed $handler
     *
     * @throws ApiPlatformPriceEmptyValue
     * @throws DomainException
     */
    public function create($handler, ApiPlatformPriceDate $date): void
    {
        $count = 0;
        $headers = fgets($handler);
        $delimiter = DetectDelimiterCsv::detectDelimiter($headers);
        $headers = is_string($headers) ? trim($headers) : $headers;
        $this->validateHeaders($headers, $delimiter);

        while ($row = fgetcsv($handler, null, $delimiter)) {
            [$country, $price] = $this->validateAndGetValues($row);
            $apiPlatformPrice = ApiPlatformPrice::create(
                new ApiPlatformPriceId(ApiPlatformPriceId::random()->value()),
                $date,
                new ApiPlatformPriceCountry($country),
                new ApiPlatformPricePrice((float) $price),
            );

            $this->entityManager->persist($apiPlatformPrice);

            if (self::RECORDS_SAVE === $count) {
                $count = 0;
                $this->entityManager->flush();
                $this->entityManager->clear();
                $this->logger->info(sprintf('%d api platform price records have been processed', self::RECORDS_SAVE));
            }
            ++$count;
        }

        if ($count) {
            $this->entityManager->flush();
            $this->entityManager->clear();
            $this->logger->info(sprintf('%d api platform price records have been processed', $count));
        }
    }

    private function validateHeaders(string $headers, string $delimiter)
    {
        foreach (explode($delimiter, $headers) as $header) {
            if (!in_array($header, self::HEADERS_ALLOWED)) {
                throw new \Exception('Header not valid! '.$header, 400);
            }
        }
    }

    private function validateAndGetValues(array $row): array
    {
        [$country, $price] = $row;
        if (!is_string($country) || !is_numeric($price)) {
            throw new \Exception(
                sprintf(
                    'Values in fields not allowed: country: [%s], price: [%s]',
                    $country,
                    $price
                ),
                400
            );
        }

        return [$country, $price];
    }
}
