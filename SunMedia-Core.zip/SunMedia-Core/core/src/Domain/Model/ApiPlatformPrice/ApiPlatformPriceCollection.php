<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\ApiPlatformPrice;

use SunMedia\Shared\Domain\Collection\AbstractEntityCollection;

class ApiPlatformPriceCollection extends AbstractEntityCollection
{
    public function addApiPlatformPrice(ApiPlatformPrice $apiPlatformPrice): void
    {
        $this->addItem($apiPlatformPrice);
    }

    public function addApiPlatformPrices(array $apiPlatformPrices): void
    {
        array_map(function ($apiPlatformPrice) {
            $this->addApiPlatformPrice($apiPlatformPrice);
        }, $apiPlatformPrices);
    }
}
