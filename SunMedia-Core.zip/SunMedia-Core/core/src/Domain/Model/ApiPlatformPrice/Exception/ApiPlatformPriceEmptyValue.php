<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\ApiPlatformPrice\Exception;

use SunMedia\Shared\Domain\Exception\DomainException;

final class ApiPlatformPriceEmptyValue extends DomainException
{
    public function __construct(string $name)
    {
        parent::__construct(
            sprintf("The '%s' parameter cannot be empty, or it does not exist.", $name),
            self::BAD_REQUEST
        );
    }
}
