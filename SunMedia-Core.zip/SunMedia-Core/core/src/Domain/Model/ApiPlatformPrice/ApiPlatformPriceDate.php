<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\ApiPlatformPrice;

use DateTimeImmutable;
use SunMedia\Shared\Domain\Model\ApiPlatformPrice\Exception\ApiPlatformPriceEmptyValue;

class ApiPlatformPriceDate
{
    public const FORMAT = 'Y-m-d';

    protected $value;

    /**
     * @param mixed $initialDate
     *
     * @throws ApiPlatformPriceEmptyValue
     */
    public function __construct($initialDate, string $parameter = 'date')
    {
        if ($initialDate) {
            $this->value = DateTimeImmutable::createFromFormat(self::FORMAT, $initialDate);
        }
        $this->validateEmpty($parameter);
    }

    public function value()
    {
        return $this->value;
    }

    /**
     * @throws ApiPlatformPriceEmptyValue
     */
    private function validateEmpty(string $parameter): void
    {
        if (!$this->value()) {
            throw new ApiPlatformPriceEmptyValue($parameter);
        }
    }
}
