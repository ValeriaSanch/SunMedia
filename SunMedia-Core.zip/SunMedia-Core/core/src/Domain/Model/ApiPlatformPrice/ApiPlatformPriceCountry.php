<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\ApiPlatformPrice;

use SunMedia\Shared\Domain\ValueObject\StringValueObject;

class ApiPlatformPriceCountry extends StringValueObject
{
    public const COUNTRY_ALL = 'all';
}
