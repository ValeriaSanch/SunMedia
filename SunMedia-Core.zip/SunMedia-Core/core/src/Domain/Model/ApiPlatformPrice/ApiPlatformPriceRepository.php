<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\ApiPlatformPrice;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;

interface ApiPlatformPriceRepository
{
    public function ByDateOrderDesc(Criteria $criteria): array;

    public function count(Criteria $criteria): int;

    public function byCriteria(Criteria $criteria): array;

    public function delete(array $dates): bool;

    public function save(ApiPlatformPrice $apiPlatformPrice): void;

    public function byCriteriaByGroup(Criteria $criteria, array $groups): array;

    public function countByGroup(Criteria $criteria, array $groups): int;
}
