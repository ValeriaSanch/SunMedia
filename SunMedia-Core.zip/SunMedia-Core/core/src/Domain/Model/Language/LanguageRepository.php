<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Language;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Model\Language\Language;
use SunMedia\Shared\Domain\Model\Language\LanguageCollection;
use SunMedia\Shared\Domain\Model\Language\LanguageId;

interface LanguageRepository
{
    public function byId(LanguageId $languageId): ?Language;

    public function byCriteria(Criteria $criteria): LanguageCollection;
}
