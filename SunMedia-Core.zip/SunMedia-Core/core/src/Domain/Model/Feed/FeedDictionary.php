<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\ValueObject\ArrayValueObject;

class FeedDictionary extends ArrayValueObject
{
    public const DICTIONARY = ['id', 'title', 'price', 'link', 'image_link', 'description', 'category', 'subcategory'];

    public const DICTIONARY_FEED = 'feed';

    public const DICTIONARY_FILE = 'file';

    /**
     * @throws EmptyValue
     */
    public function __construct(array $value)
    {
        $this->transform($value);
        parent::__construct($value);
        $this->validateEmpty();
    }

    private function transform(array &$value): void
    {
        $value = array_combine(array_map(static function ($str) {
            return trim($str);
        }, array_keys($value)), array_values($value));

        foreach ($value as $key => &$val) {
            if (is_array($val)) {
                $this->transform($value[$key]);
            } else {
                $val = trim($val);
            }
        }
    }

    /**
     * @throws EmptyValue
     */
    private function validateEmpty(): void
    {
        if (!$this->value()) {
            throw new EmptyValue('dictionary');
        }
    }
}
