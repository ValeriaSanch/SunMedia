<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Core\Domain\Model\Feed\Exception\InvalidCallbackUrl;
use SunMedia\Shared\Domain\ValueObject\ArrayValueObject;

class FeedCallbackUrl extends ArrayValueObject
{
    /**
     * @throws InvalidCallbackUrl
     */
    public function __construct(array $value)
    {
        $this->transform($value);
        parent::__construct($value);
    }

    /**
     * @throws InvalidCallbackUrl
     */
    private function transform(array &$value): void
    {
        foreach ($value as &$data) {
            $data = trim(filter_var($data, FILTER_SANITIZE_URL) ?: $data);
            $this->validateUrl($data);
        }
        unset($data);
        $value = array_values($value);
    }

    /**
     * @throws InvalidCallbackUrl
     */
    private function validateUrl(string $value): void
    {
        if (!preg_match(
            '/\\b(?:(?:https?|ftp):\\/\\/|www\\.)[-a-z0-9+&@#\\/%?=~_|!:,.;]*[-a-z0-9+&@#\\/%=~_|]/i',
            $value
        )) {
            throw new InvalidCallbackUrl('callbackUrl');
        }
    }
}
