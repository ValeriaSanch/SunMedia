<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileEmpty;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidFileType;
use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\ValueObject\NullableStringValueObject;

class FeedUrl extends NullableStringValueObject
{
    public const MAX_SIZE_MB = 100; // 100MB

    public const MAX_SIZE = self::MAX_SIZE_MB * self::BYTES;

    public const MIME_TYPES = [
        'text/plain',
        'text/csv',
        'text/tsv',
        'text/tab-separated-values',
        'text/comma-separated-values',
        'application/vnd.ms-excel',
        'application/vnd.msexcel',
        'application/csv',
        'application/octet-stream',
        'application/x-csv',
        'text/xml',
        'application/xml',
        'application/rss+xml',
    ];

    public const TYPES = ['csv', 'xml'];

    private const BYTES = 1048576; // 1MB in bytes

    /**
     * @throws EmptyValue
     * @throws FeedFileEmpty
     * @throws FeedFileNotFound
     * @throws InvalidFileType
     */
    public function __construct(?string $value, bool $edit = false)
    {
        parent::__construct($value);
        if (!$edit && !is_null($value)) {
            $this->validateEmpty();
            $this->checkExtension();
            $this->checkExists();
            $this->checkFileEmpty();
        }
    }

    /**
     * @throws EmptyValue
     */
    private function validateEmpty(): void
    {
        if (!$this->value()) {
            throw new EmptyValue('url');
        }
    }

    /**
     * @throws InvalidFileType
     */
    private function checkExtension(): void
    {
        if (!preg_match('/.*\.(csv|xml)$/', $this->value())) {
            throw new InvalidFileType(self::TYPES);
        }
    }

    /**
     * @throws FeedFileNotFound
     */
    private function checkExists(): void
    {
        if (!@fopen($this->value(), 'rb')) {
            throw new FeedFileNotFound($this->value());
        }
    }

    /**
     * @throws FeedFileEmpty
     */
    private function checkFileEmpty(): void
    {
        if (!@file_get_contents($this->value())) {
            throw new FeedFileEmpty($this->value());
        }
    }
}
