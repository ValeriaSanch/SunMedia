<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Shared\Domain\ValueObject\Uuid;

class FeedId extends Uuid
{
}
