<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Shared\Domain\ValueObject\StringValueObject;

class FeedInput extends StringValueObject
{
}
