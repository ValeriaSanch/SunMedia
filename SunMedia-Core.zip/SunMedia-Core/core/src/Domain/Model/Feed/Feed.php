<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Core\Domain\Model\Feed\Applier\V1\FeedWasCreatedV1Applier;
use SunMedia\Core\Domain\Model\Feed\Applier\V1\FeedWasDeletedV1Applier;
use SunMedia\Core\Domain\Model\Feed\Applier\V1\FeedWasUpdatedV1Applier;
use SunMedia\Core\Domain\Model\Feed\Event\V1\FeedWasCreated;
use SunMedia\Core\Domain\Model\Feed\Event\V1\FeedWasDeleted;
use SunMedia\Core\Domain\Model\Feed\Event\V1\FeedWasUpdated;
use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\AggregateRootTrait;
use SunMedia\Shared\Domain\Model\TimeAwareTrait;

class Feed
{
    use TimeAwareTrait;
    use AggregateRootTrait;
    use FeedWasCreatedV1Applier;
    use FeedWasUpdatedV1Applier;
    use FeedWasDeletedV1Applier;

    /** @var FeedId */
    private $id;

    /** @var ClientId */
    private $clientId;

    /** @var FeedName */
    private $name;

    /** @var FeedType */
    private $type;

    /** @var FeedUrl */
    private $url;

    /** @var FeedCallbackUrl */
    private $callbackUrl;

    /** @var FeedHourInterval */
    private $hourInterval;

    /** @var FeedInput */
    private $input;

    /** @var FeedOutput */
    private $output;

    /** @var FeedDictionary */
    private $dictionary;

    /**
     * @throws DomainException
     */
    private function __construct(
        User $author,
        FeedId $id,
        ClientId $clientId,
        FeedName $name,
        FeedType $type,
        FeedHourInterval $hourInterval,
        FeedUrl $url,
        FeedCallbackUrl $callbackUrl,
        FeedInput $input,
        FeedOutput $output,
        FeedDictionary $dictionary
    ) {
        $this->applyAndPublishThat(
            new FeedWasCreated(
                $author->id()->value(),
                $id->value(),
                $clientId->value(),
                $name->value(),
                $type->value(),
                $hourInterval->value(),
                $url->value(),
                $callbackUrl->value(),
                $input->value(),
                $output->value(),
                $dictionary->value()
            )
        );
    }

    /**
     * @throws DomainException
     */
    public static function create(
        User $author,
        FeedId $id,
        ClientId $clientId,
        FeedName $name,
        FeedType $type,
        FeedHourInterval $hourInterval,
        FeedUrl $url,
        FeedCallbackUrl $callbackUrl,
        FeedInput $input,
        FeedOutput $output,
        FeedDictionary $dictionary
    ): Feed {
        return new self(
            $author,
            $id,
            $clientId,
            $name,
            $type,
            $hourInterval,
            $url,
            $callbackUrl,
            $input,
            $output,
            $dictionary
        );
    }

    /**
     * @throws DomainException
     */
    public function update(
        User $author,
        FeedId $id,
        FeedName $name,
        FeedType $type,
        FeedHourInterval $hourInterval,
        FeedUrl $url,
        FeedCallbackUrl $callbackUrl,
        FeedInput $input,
        FeedOutput $output,
        FeedDictionary $dictionary
    ): void {
        $this->applyAndPublishThat(
            new FeedWasUpdated(
                $author->id()->value(),
                $id->value(),
                $name->value(),
                $type->value(),
                $hourInterval->value(),
                $url->value(),
                $callbackUrl->value(),
                $input->value(),
                $output->value(),
                $dictionary->value()
            )
        );
    }

    /**
     * @throws DomainException
     */
    public function updateBackground(User $author, FeedInput $input, FeedOutput $output): void
    {
        $this->applyAndPublishThat(
            new FeedWasUpdated(
                $author->id()->value(),
                $this->id()->value(),
                $this->name()->value(),
                $this->type()->value(),
                $this->hourInterval()->value(),
                $this->url()->value(),
                $this->callbackUrl()->value(),
                $input->value(),
                $output->value(),
                $this->dictionary()->value()
            )
        );
    }

    public function id(): FeedId
    {
        return $this->id;
    }

    public function clientId(): ClientId
    {
        return $this->clientId;
    }

    public function name(): FeedName
    {
        return $this->name;
    }

    public function type(): FeedType
    {
        return $this->type;
    }

    public function hourInterval(): FeedHourInterval
    {
        return $this->hourInterval;
    }

    public function url(): FeedUrl
    {
        return $this->url;
    }

    public function callbackUrl(): FeedCallbackUrl
    {
        return $this->callbackUrl;
    }

    public function dictionary(): FeedDictionary
    {
        return $this->dictionary;
    }

    /**
     * @throws DomainException
     */
    public function remove(User $author): void
    {
        $this->applyAndPublishThat(new FeedWasDeleted($author->id()->value(), $this->id()->value()));
    }

    public function input(): FeedInput
    {
        return $this->input;
    }

    public function output(): FeedOutput
    {
        return $this->output;
    }
}
