<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Shared\Domain\Collection\AbstractEntityCollection;

class FeedCollection extends AbstractEntityCollection
{
    public function addFeeds(iterable $feeds): void
    {
        foreach ($feeds as $feed) {
            $this->addFeed($feed);
        }
    }

    public function addFeed(Feed $feed): void
    {
        $this->addItem($feed);
    }
}
