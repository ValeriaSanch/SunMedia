<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Core\Domain\Model\Feed\Exception\InvalidHourInterval;
use SunMedia\Shared\Domain\ValueObject\IntValueObject;

class FeedHourInterval extends IntValueObject
{
    /**
     * @throws InvalidHourInterval
     */
    public function __construct(int $value)
    {
        parent::__construct($value);
        $this->checkHourInterval();
    }

    /**
     * @throws InvalidHourInterval
     */
    private function checkHourInterval(): void
    {
        if (!$this->value()) {
            throw new InvalidHourInterval('0 is not valid');
        }
    }
}
