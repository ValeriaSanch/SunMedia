<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Exception;

use SunMedia\Shared\Domain\Exception\DomainException;

final class InvalidHourInterval extends DomainException
{
    public function __construct(string $message)
    {
        parent::__construct(sprintf('Invalid hour interval, %s', $message), self::BAD_REQUEST);
    }
}
