<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Exception;

use SunMedia\Shared\Domain\Exception\DomainException;

final class FeedFileEmpty extends DomainException
{
    public function __construct(string $file)
    {
        parent::__construct(sprintf("file '%s' has no content.", $file), self::BAD_REQUEST);
    }
}
