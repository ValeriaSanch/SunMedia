<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Exception;

use SunMedia\Core\Domain\Model\Feed\FeedId;
use SunMedia\Shared\Domain\Exception\DomainException;

final class FeedNotFound extends DomainException
{
    public function __construct(?FeedId $id = null)
    {
        $message = null !== $id ? sprintf('The feed with id %s not found.', $id->value()) : 'Feed not found.';

        parent::__construct($message, self::NOT_FOUND);
    }
}
