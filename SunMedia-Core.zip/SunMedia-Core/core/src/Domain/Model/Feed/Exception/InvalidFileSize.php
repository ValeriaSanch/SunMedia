<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Exception;

use SunMedia\Shared\Domain\Exception\DomainException;

final class InvalidFileSize extends DomainException
{
    public function __construct(string $size)
    {
        parent::__construct(sprintf('File max size %s', $size, ), self::BAD_REQUEST);
    }
}
