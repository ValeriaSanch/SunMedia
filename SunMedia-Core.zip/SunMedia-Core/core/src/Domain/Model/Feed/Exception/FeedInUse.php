<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Exception;

use SunMedia\Core\Domain\Model\Feed\FeedId;
use SunMedia\Shared\Domain\Exception\DomainException;

final class FeedInUse extends DomainException
{
    public function __construct(FeedId $id)
    {
        parent::__construct(sprintf(
            "It is not possible to delete the feed with id '%s' because is in use.",
            $id->value()
        ), self::BAD_REQUEST);
    }
}
