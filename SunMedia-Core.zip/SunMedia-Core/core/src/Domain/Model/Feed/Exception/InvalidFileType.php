<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Exception;

use SunMedia\Shared\Domain\Exception\DomainException;

final class InvalidFileType extends DomainException
{
    public function __construct(array $types)
    {
        parent::__construct(sprintf('Invalid File, only files (%s)', implode(', ', $types)), self::BAD_REQUEST);
    }
}
