<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Exception;

use SunMedia\Shared\Domain\Exception\DomainException;

final class InvalidCallbackUrl extends DomainException
{
    public function __construct(string $name)
    {
        parent::__construct(sprintf("The '%s' parameter contains an invalid url.", $name), self::BAD_REQUEST);
    }
}
