<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;

interface FeedRepository
{
    public function byId(FeedId $id, Criteria $criteria): ?Feed;

    public function save(Feed $feed): void;

    public function byCriteria(Criteria $criteria): FeedCollection;

    public function count(Criteria $criteria): int;

    public function delete(Feed $feed): bool;
}
