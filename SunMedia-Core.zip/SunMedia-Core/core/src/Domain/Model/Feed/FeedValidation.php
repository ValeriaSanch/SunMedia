<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Core\Domain\Model\Feed\Exception\FeedInUse;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidHourInterval;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;

class FeedValidation
{
    /** @var FeedRepository */
    private $feedRepository;

    public function __construct(FeedRepository $feedRepository)
    {
        $this->feedRepository = $feedRepository;
    }

    /**
     * @throws InvalidHourInterval
     */
    public function validateHourInterval(FeedType $type, FeedHourInterval $hourInterval, FeedUrl $url): void
    {
        switch ($type->value()) {
            case FeedType::FEED_TYPE_FILE:
                if (-1 !== $hourInterval->value()) {
                    if ($url->value()) {
                        unlink($url->value());
                    }

                    throw new InvalidHourInterval('cannot be different from -1');
                }

                break;

            case FeedType::FEED_TYPE_URL:
                if ($hourInterval->value() < 1) {
                    throw new InvalidHourInterval('cannot be less than 1');
                }

                break;
        }
    }

    /**
     * @throws FeedNotFound
     */
    public function ensureFeedIdExists(FeedId $feedId): Feed
    {
        $feed = $this->feedRepository->byId($feedId, new Criteria());

        if (is_null($feed)) {
            throw new FeedNotFound($feedId);
        }

        return $feed;
    }

    /**
     * @throws FeedInUse
     */
    public function checkIsUsed(Feed $feed): void
    {
        if (0 !== count($feed->callbackUrl()->value())) {
            throw new FeedInUse($feed->id());
        }
    }
}
