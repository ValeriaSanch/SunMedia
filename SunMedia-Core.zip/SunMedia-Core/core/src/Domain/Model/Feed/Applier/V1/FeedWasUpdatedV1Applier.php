<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Applier\V1;

use SunMedia\Core\Domain\Model\Feed\Event\V1\FeedWasUpdated;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileEmpty;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidCallbackUrl;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidFileType;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidHourInterval;
use SunMedia\Core\Domain\Model\Feed\FeedCallbackUrl;
use SunMedia\Core\Domain\Model\Feed\FeedDictionary;
use SunMedia\Core\Domain\Model\Feed\FeedHourInterval;
use SunMedia\Core\Domain\Model\Feed\FeedInput;
use SunMedia\Core\Domain\Model\Feed\FeedName;
use SunMedia\Core\Domain\Model\Feed\FeedOutput;
use SunMedia\Core\Domain\Model\Feed\FeedType;
use SunMedia\Core\Domain\Model\Feed\FeedUrl;
use SunMedia\Shared\Domain\Exception\EmptyValue;

trait FeedWasUpdatedV1Applier
{
    /**
     * @throws EmptyValue
     * @throws FeedFileEmpty
     * @throws FeedFileNotFound
     * @throws InvalidCallbackUrl
     * @throws InvalidFileType
     * @throws InvalidHourInterval
     */
    public function applyThatFeedWasUpdatedV1(FeedWasUpdated $feedWasUpdated): void
    {
        $this->type = new FeedType($feedWasUpdated->type());
        $this->hourInterval = new FeedHourInterval($feedWasUpdated->hourInterval());
        $this->name = new FeedName($feedWasUpdated->name());
        $this->url = new FeedUrl($feedWasUpdated->url());
        $this->callbackUrl = new FeedCallbackUrl($feedWasUpdated->callbackUrl());
        $this->input = new FeedInput($feedWasUpdated->input());
        $this->output = new FeedOutput($feedWasUpdated->output());
        $this->dictionary = new FeedDictionary($feedWasUpdated->dictionary());

        $this->updatedAt = $feedWasUpdated->occurredOn();
    }
}
