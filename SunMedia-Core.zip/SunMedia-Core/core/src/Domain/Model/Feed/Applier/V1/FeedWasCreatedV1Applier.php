<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Applier\V1;

use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Core\Domain\Model\Feed\Event\V1\FeedWasCreated;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileEmpty;
use SunMedia\Core\Domain\Model\Feed\Exception\FeedFileNotFound;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidCallbackUrl;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidFileType;
use SunMedia\Core\Domain\Model\Feed\Exception\InvalidHourInterval;
use SunMedia\Core\Domain\Model\Feed\FeedCallbackUrl;
use SunMedia\Core\Domain\Model\Feed\FeedDictionary;
use SunMedia\Core\Domain\Model\Feed\FeedHourInterval;
use SunMedia\Core\Domain\Model\Feed\FeedId;
use SunMedia\Core\Domain\Model\Feed\FeedInput;
use SunMedia\Core\Domain\Model\Feed\FeedName;
use SunMedia\Core\Domain\Model\Feed\FeedOutput;
use SunMedia\Core\Domain\Model\Feed\FeedType;
use SunMedia\Core\Domain\Model\Feed\FeedUrl;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmptyValue;

trait FeedWasCreatedV1Applier
{
    /**
     * @throws DomainException
     * @throws EmptyValue
     * @throws FeedFileEmpty
     * @throws FeedFileNotFound
     * @throws InvalidCallbackUrl
     * @throws InvalidFileType
     * @throws InvalidHourInterval
     */
    public function applyThatFeedWasCreatedV1(FeedWasCreated $feedWasCreated): void
    {
        $this->id = new FeedId($feedWasCreated->id());
        $this->clientId = new ClientId($feedWasCreated->clientId());
        $this->name = new FeedName($feedWasCreated->name());
        $this->type = new FeedType($feedWasCreated->type());
        $this->hourInterval = new FeedHourInterval($feedWasCreated->hourInterval());
        $this->url = new FeedUrl($feedWasCreated->url());
        $this->callbackUrl = new FeedCallbackUrl($feedWasCreated->callbackUrl());
        $this->input = new FeedInput($feedWasCreated->input());
        $this->output = new FeedOutput($feedWasCreated->output());
        $this->dictionary = new FeedDictionary($feedWasCreated->dictionary());

        $this->createdAt = $feedWasCreated->occurredOn();
        $this->updatedAt = $feedWasCreated->occurredOn();
    }
}
