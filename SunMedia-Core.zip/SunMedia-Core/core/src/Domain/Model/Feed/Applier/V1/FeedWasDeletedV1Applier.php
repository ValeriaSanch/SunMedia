<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Applier\V1;

use SunMedia\Core\Domain\Model\Feed\Event\V1\FeedWasDeleted;
use SunMedia\Core\Domain\Model\Feed\FeedId;
use SunMedia\Shared\Domain\Exception\DomainException;

trait FeedWasDeletedV1Applier
{
    /**
     * @throws DomainException
     */
    public function applyThatFeedWasDeletedV1(FeedWasDeleted $feedWasDeleted): void
    {
        $this->id = new FeedId($feedWasDeleted->feedId());
    }
}
