<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Shared\Domain\ValueObject\StringValueObject;

class FeedType extends StringValueObject
{
    public const FEED_TYPE_FILE = 'FILE';

    public const FEED_TYPE_URL = 'URL';
}
