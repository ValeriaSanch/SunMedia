<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed;

use SunMedia\Shared\Domain\Exception\EmptyValue;
use SunMedia\Shared\Domain\ValueObject\StringValueObject;

class FeedName extends StringValueObject
{
    /**
     * @throws EmptyValue
     */
    public function __construct(string $value)
    {
        parent::__construct($value);
        $this->validateEmpty();
    }

    /**
     * @throws EmptyValue
     */
    private function validateEmpty(): void
    {
        if (!trim($this->value())) {
            throw new EmptyValue('name');
        }
    }
}
