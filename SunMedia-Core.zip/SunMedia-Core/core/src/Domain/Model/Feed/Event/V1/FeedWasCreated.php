<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Event\V1;

use SunMedia\Core\Domain\Model\Feed\Feed;
use SunMedia\Shared\Domain\Bus\AbstractDomainEvent;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class FeedWasCreated extends AbstractDomainEvent
{
    public const DOMAIN_EVENT_NAME = 'sunmedia.feed.%s.event.feed.created';

    private const VERSION = 1;

    /** @var string */
    private $id;

    /** @var string */
    private $clientId;

    /** @var string */
    private $name;

    /** @var string */
    private $type;

    /** @var int */
    private $hourInterval;

    /** @var ?string */
    private $url;

    /** @var array */
    private $callbackUrl;

    /** @var string */
    private $input;

    /** @var string */
    private $output;

    /** @var array */
    private $dictionary;

    /**
     * @throws DomainException
     */
    public function __construct(
        string $authorId,
        string $id,
        string $clientUserId,
        string $name,
        string $type,
        int $hourInterval,
        ?string $url,
        array $callbackUrl,
        string $input,
        string $output,
        array $dictionary
    ) {
        parent::__construct(
            $authorId,
            SMDatetime::now(),
            $id,
            Feed::class,
            self::VERSION,
            sprintf(self::DOMAIN_EVENT_NAME, self::VERSION)
        );

        $this->id = $id;
        $this->clientId = $clientUserId;
        $this->name = $name;
        $this->type = $type;
        $this->hourInterval = $hourInterval;
        $this->url = $url;
        $this->callbackUrl = $callbackUrl;
        $this->input = $input;
        $this->output = $output;
        $this->dictionary = $dictionary;
    }

    public function id(): string
    {
        return $this->id;
    }

    public function clientId(): string
    {
        return $this->clientId;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function type(): string
    {
        return $this->type;
    }

    public function hourInterval(): int
    {
        return $this->hourInterval;
    }

    public function url(): ?string
    {
        return $this->url;
    }

    public function callbackUrl(): array
    {
        return $this->callbackUrl;
    }

    public function input(): string
    {
        return $this->input;
    }

    public function output(): string
    {
        return $this->output;
    }

    public function dictionary(): array
    {
        return $this->dictionary;
    }
}
