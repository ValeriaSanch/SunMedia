<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Feed\Event\V1;

use SunMedia\Core\Domain\Model\Feed\Feed;
use SunMedia\Shared\Domain\Bus\AbstractDomainEvent;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class FeedWasDeleted extends AbstractDomainEvent
{
    public const DOMAIN_EVENT_NAME = 'sunmedia.feed.%s.event.feed.deleted';

    private const VERSION = 1;

    /** @var string */
    private $feedId;

    /**
     * @throws DomainException
     */
    public function __construct(string $authorId, string $id)
    {
        parent::__construct(
            $authorId,
            SMDatetime::now(),
            $id,
            Feed::class,
            self::VERSION,
            sprintf(self::DOMAIN_EVENT_NAME, self::VERSION)
        );

        $this->feedId = $id;
    }

    public function feedId(): string
    {
        return $this->feedId;
    }
}
