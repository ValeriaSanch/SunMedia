<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Device;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Model\Device\Device;
use SunMedia\Shared\Domain\Model\Device\DeviceCollection;
use SunMedia\Shared\Domain\Model\Device\DeviceFamilyCollection;

interface DeviceRepository
{
    public function byCriteria(Criteria $criteria): DeviceCollection;

    public function save(Device $device);

    public function families(): DeviceFamilyCollection;

    public function count(Criteria $criteria);
}
