<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Device;

use SunMedia\Shared\Domain\Criteria\CriteriaFactory;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Criteria\Expr\ExpressionBuilder;
use SunMedia\Shared\Domain\Model\Device\DeviceBrand;
use SunMedia\Shared\Domain\Model\Device\DeviceFamily;
use SunMedia\Shared\Domain\Model\Device\DeviceModel;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class DeviceCriteriaFactory extends CriteriaFactory
{
    private static $fieldToSearch = ['name'];

    public function fieldToSearch(): array
    {
        return self::$fieldToSearch;
    }

    public function getUserCriteria(SecurityUser $user): Criteria
    {
        return new Criteria(null);
    }

    public function byFamilyBrandAndModel(DeviceFamily $family, DeviceBrand $brand, DeviceModel $model): Criteria
    {
        $expressionBuilder = new ExpressionBuilder();

        $comparison = $expressionBuilder->andX(
            $expressionBuilder->eq('device.family', $family->value()),
            $expressionBuilder->eq('device.brand', $brand->value()),
            $expressionBuilder->eq('device.model', $model->value())
        );

        return new Criteria($comparison);
    }

    public function byFamily(DeviceFamily $deviceFamily): Criteria
    {
        $expressionBuilder = new ExpressionBuilder();

        $comparison = $expressionBuilder->eq('device.family', $deviceFamily->value());

        return new Criteria($comparison);
    }
}
