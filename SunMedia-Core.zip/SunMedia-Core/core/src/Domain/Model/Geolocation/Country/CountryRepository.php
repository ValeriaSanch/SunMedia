<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Geolocation\Country;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Model\Country\Country;
use SunMedia\Shared\Domain\Model\Country\CountryCollection;
use SunMedia\Shared\Domain\Model\Country\CountryIso;

interface CountryRepository
{
    public function all(): CountryCollection;

    public function byIsoCode(CountryIso $countryIso): ?Country;

    public function save(Country $country): void;

    public function byCriteria(Criteria $criteria): CountryCollection;

    public function count(Criteria $criteria): int;
}
