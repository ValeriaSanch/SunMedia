<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Geolocation\City;

use SunMedia\Shared\Domain\Model\Geolocation\City\City;

interface CityRepository
{
    public function save(City $city): void;
}
