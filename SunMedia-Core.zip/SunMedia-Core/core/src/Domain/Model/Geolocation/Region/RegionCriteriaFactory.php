<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Geolocation\Region;

use SunMedia\Shared\Domain\Criteria\CriteriaFactory;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class RegionCriteriaFactory extends CriteriaFactory
{
    private static $fieldToSearch = ['name'];

    public function fieldToSearch(): array
    {
        return self::$fieldToSearch;
    }

    public function getUserCriteria(SecurityUser $user): Criteria
    {
        return new Criteria(null);
    }
}
