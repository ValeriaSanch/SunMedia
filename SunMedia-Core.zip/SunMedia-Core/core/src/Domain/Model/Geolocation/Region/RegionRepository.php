<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Geolocation\Region;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Model\Geolocation\Region\Region;
use SunMedia\Shared\Domain\Model\Geolocation\Region\RegionCollection;

interface RegionRepository
{
    public function save(Region $region): void;

    public function byCriteria(Criteria $criteria, array $includes = null): RegionCollection;

    public function count(Criteria $criteria): int;
}
