<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser;

use SunMedia\Shared\Domain\Collection\AbstractEntityCollection;

class AdvertiserCollection extends AbstractEntityCollection
{
    public function addAdvertiser(Advertiser $advertiser): void
    {
        $this->addItem($advertiser);
    }

    public function addAdvertisers(iterable $advertisers): void
    {
        foreach ($advertisers as $advertiser) {
            $this->addAdvertiser($advertiser);
        }
    }
}
