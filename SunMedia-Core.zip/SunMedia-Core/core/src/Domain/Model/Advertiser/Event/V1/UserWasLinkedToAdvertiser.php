<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser\Event\V1;

use Exception;
use SunMedia\Core\Domain\Model\Advertiser\Advertiser;
use SunMedia\Shared\Domain\Bus\AbstractDomainEvent;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class UserWasLinkedToAdvertiser extends AbstractDomainEvent
{
    public const VERSION = 1;

    public const DOMAIN_EVENT_NAME = 'sunmedia.advertiser.%s.event.advertiser.user_linked';

    /** @var string */
    private $userId;

    /** @var string */
    private $advertiserId;

    /**
     * @throws DomainException
     * @throws Exception
     */
    public function __construct(string $authorId, string $advertiserId, string $userUserId)
    {
        parent::__construct(
            $authorId,
            SMDatetime::now(),
            $advertiserId,
            Advertiser::class,
            self::VERSION,
            sprintf(self::DOMAIN_EVENT_NAME, self::VERSION)
        );

        $this->userId = $userUserId;
        $this->advertiserId = $advertiserId;
    }

    /**
     * @param mixed $event
     *
     * @throws DomainException
     */
    public static function fromExternalEvent($event): self
    {
        return new self(
            $event->data['attributes']['authorId'],
            $event->data['attributes']['aggregateId'],
            $event->data['attributes']['userId']
        );
    }

    public function userId(): string
    {
        return $this->userId;
    }

    public function advertiserId(): string
    {
        return $this->advertiserId;
    }
}
