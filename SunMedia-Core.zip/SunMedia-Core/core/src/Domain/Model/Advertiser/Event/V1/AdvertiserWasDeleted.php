<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser\Event\V1;

use Exception;
use SunMedia\Core\Domain\Model\Advertiser\Advertiser;
use SunMedia\Shared\Domain\Bus\AbstractDomainEvent;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class AdvertiserWasDeleted extends AbstractDomainEvent
{
    public const DOMAIN_EVENT_NAME = 'sunmedia.advertiser.%s.event.advertiser.deleted';

    private const VERSION = 1;

    /** @var string */
    private $advertiserId;

    /**
     * @throws DomainException
     * @throws Exception
     */
    public function __construct(string $authorId, string $id)
    {
        parent::__construct(
            $authorId,
            SMDatetime::now(),
            $id,
            Advertiser::class,
            self::VERSION,
            sprintf(self::DOMAIN_EVENT_NAME, self::VERSION)
        );

        $this->advertiserId = $id;
    }

    /**
     * @param mixed $event
     *
     * @throws DomainException
     */
    public static function fromExternalEvent($event): self
    {
        return new self($event->data['attributes']['authorId'], $event->data['attributes']['aggregateId']);
    }

    public function advertiserId(): string
    {
        return $this->advertiserId;
    }
}
