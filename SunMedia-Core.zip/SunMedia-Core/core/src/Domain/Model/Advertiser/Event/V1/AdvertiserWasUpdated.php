<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser\Event\V1;

use Exception;
use SunMedia\Core\Domain\Model\Advertiser\Advertiser;
use SunMedia\Shared\Domain\Bus\AbstractDomainEvent;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class AdvertiserWasUpdated extends AbstractDomainEvent
{
    public const DOMAIN_EVENT_NAME = 'sunmedia.advertiser.%s.event.advertiser.updated';

    private const VERSION = 1;

    /** @var string */
    private $id;

    /** @var string */
    private $name;

    /** @var null|string */
    private $clientId;

    /**
     * @throws DomainException
     * @throws Exception
     */
    public function __construct(string $authorId, string $id, string $name, ?string $clientId)
    {
        parent::__construct(
            $authorId,
            SMDatetime::now(),
            $id,
            Advertiser::class,
            self::VERSION,
            sprintf(self::DOMAIN_EVENT_NAME, self::VERSION)
        );

        $this->id = $id;
        $this->name = $name;
        $this->clientId = $clientId;
    }

    /**
     * @param mixed $event
     *
     * @throws DomainException
     */
    public static function fromExternalEvent($event): self
    {
        return new self(
            $event->data['attributes']['authorId'],
            $event->data['attributes']['aggregateId'],
            $event->data['attributes']['name'],
            $event->data['attributes']['clientId'] ?? null
        );
    }

    public function id(): string
    {
        return $this->id;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function clientId(): ?string
    {
        return $this->clientId;
    }
}
