<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser;

use SunMedia\Core\Domain\Model\User\UserAdvertiserLink;
use SunMedia\Shared\Domain\Collection\AbstractCollection;

class UserAdvertiserLinkCollection extends AbstractCollection
{
    public function addUserAdvertiserLink(UserAdvertiserLink $userPublisherLink): void
    {
        $this->addItem($userPublisherLink);
    }

    public function addUserAdvertiserLinks(iterable $userAdvertiserLinks): void
    {
        foreach ($userAdvertiserLinks as $userAdvertiserLink) {
            $this->addUserAdvertiserLink($userAdvertiserLink);
        }
    }

    protected function calculateHash($item): string
    {
        return md5($item->advertiserId()->value().$item->userId()->value());
    }
}
