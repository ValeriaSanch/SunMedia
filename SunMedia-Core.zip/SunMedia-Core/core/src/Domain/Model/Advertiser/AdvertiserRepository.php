<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;

interface AdvertiserRepository
{
    public function byId(AdvertiserId $advertiserId, Criteria $criteria): ?Advertiser;

    public function save(Advertiser $advertiser): void;

    public function byCriteria(Criteria $criteria): AdvertiserCollection;

    public function count(Criteria $criteria): int;
}
