<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser\Applier\V1;

use SunMedia\Core\Domain\Model\Advertiser\Event\V1\UserWasUnlikedToAdvertiser;
use SunMedia\Core\Domain\Model\User\UserAdvertiserLink;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\User\UserId;

trait UserWasUnLinkedToAdvertiserV1Applier
{
    /**
     * @throws DomainException
     */
    public function applyThatUserWasUnlikedToAdvertiserV1(UserWasUnlikedToAdvertiser $userWasUnlikedToAdvertiser): void
    {
        $this->userAdvertiserLinkCollection->removeItem(new UserAdvertiserLink(
            new UserId($userWasUnlikedToAdvertiser->userId()),
            $this->id
        ));
    }
}
