<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser\Applier\V1;

use SunMedia\Core\Domain\Model\Advertiser\AdvertiserId;
use SunMedia\Core\Domain\Model\Advertiser\AdvertiserName;
use SunMedia\Core\Domain\Model\Advertiser\Event\V1\AdvertiserWasUpdated;
use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Shared\Domain\Exception\DomainException;

trait AdvertiserWasUpdatedV1Applier
{
    /**
     * @throws DomainException
     */
    public function applyThatAdvertiserWasUpdatedV1(AdvertiserWasUpdated $wasUpdated): void
    {
        $this->id = new AdvertiserId($wasUpdated->id());
        $this->name = new AdvertiserName($wasUpdated->name());

        if (null !== $wasUpdated->clientId()) {
            $this->clientId = new ClientId($wasUpdated->clientId());
            $this->deletedAt = null;
            $this->createdAt = $wasUpdated->occurredOn();
        }

        $this->updatedAt = $wasUpdated->occurredOn();
    }
}
