<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser\Applier\V1;

use SunMedia\Core\Domain\Model\Advertiser\Event\V1\AdvertiserWasDeleted;
use SunMedia\Shared\Domain\Model\DeleteTrait;

trait AdvertiserWasDeletedV1Applier
{
    use DeleteTrait;

    public function applyThatAdvertiserWasDeletedV1(AdvertiserWasDeleted $advertiserWasDeleted): void
    {
        $this->deleted = true;
        $this->deletedAt = $advertiserWasDeleted->occurredOn();
    }
}
