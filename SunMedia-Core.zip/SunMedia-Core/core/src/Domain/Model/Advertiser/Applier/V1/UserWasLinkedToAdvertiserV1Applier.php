<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser\Applier\V1;

use SunMedia\Core\Domain\Model\Advertiser\Event\V1\UserWasLinkedToAdvertiser;
use SunMedia\Core\Domain\Model\User\UserAdvertiserLink;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\User\UserId;

trait UserWasLinkedToAdvertiserV1Applier
{
    /**
     * @throws DomainException
     */
    public function applyThatUserWasLinkedToAdvertiserV1(UserWasLinkedToAdvertiser $userWasLinkedToAdvertiser): void
    {
        $this->userAdvertiserLinkCollection->addUserAdvertiserLink(new UserAdvertiserLink(
            new UserId($userWasLinkedToAdvertiser->userId()),
            $this->id
        ));
    }
}
