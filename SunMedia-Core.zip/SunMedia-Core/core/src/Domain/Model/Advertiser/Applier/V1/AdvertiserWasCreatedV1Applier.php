<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser\Applier\V1;

use SunMedia\Core\Domain\Model\Advertiser\AdvertiserId;
use SunMedia\Core\Domain\Model\Advertiser\AdvertiserName;
use SunMedia\Core\Domain\Model\Advertiser\Event\V1\AdvertiserWasCreated;
use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Shared\Domain\Exception\DomainException;

trait AdvertiserWasCreatedV1Applier
{
    /**
     * @throws DomainException
     */
    public function applyThatAdvertiserWasCreatedV1(AdvertiserWasCreated $advertiserWasCreated): void
    {
        $this->id = new AdvertiserId($advertiserWasCreated->id());
        $this->name = new AdvertiserName($advertiserWasCreated->name());
        $this->clientId = new ClientId($advertiserWasCreated->clientId());

        $this->deleted = false;
        $this->deletedAt = null;
        $this->createdAt = $advertiserWasCreated->occurredOn();
        $this->updatedAt = $advertiserWasCreated->occurredOn();
    }
}
