<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser;

use SunMedia\Core\Domain\Model\Advertiser\Applier\V1\AdvertiserWasCreatedV1Applier;
use SunMedia\Core\Domain\Model\Advertiser\Applier\V1\AdvertiserWasDeletedV1Applier;
use SunMedia\Core\Domain\Model\Advertiser\Applier\V1\AdvertiserWasUpdatedV1Applier;
use SunMedia\Core\Domain\Model\Advertiser\Applier\V1\UserWasLinkedToAdvertiserV1Applier;
use SunMedia\Core\Domain\Model\Advertiser\Applier\V1\UserWasUnLinkedToAdvertiserV1Applier;
use SunMedia\Core\Domain\Model\Client\Client;
use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Core\Domain\Model\User\UserCollection;
use SunMedia\Shared\Domain\Model\AggregateRootTrait;
use SunMedia\Shared\Domain\Model\TimeAwareTrait;

class Advertiser
{
    use AggregateRootTrait;
    use AdvertiserWasCreatedV1Applier;
    use AdvertiserWasDeletedV1Applier;
    use AdvertiserWasUpdatedV1Applier;
    use UserWasUnLinkedToAdvertiserV1Applier;
    use UserWasLinkedToAdvertiserV1Applier;
    use TimeAwareTrait;

    /** @var AdvertiserId */
    private $id;

    /** @var AdvertiserName */
    private $name;

    /** @var Client */
    private $client;

    /** @var ClientId */
    private $clientId;

    /** @var UserAdvertiserLinkCollection */
    private $userAdvertiserLinkCollection;

    /** @var UserCollection */
    private $linkedUsers;

    public function id(): AdvertiserId
    {
        return $this->id;
    }

    public function name(): AdvertiserName
    {
        return $this->name;
    }

    public function client(): Client
    {
        return $this->client;
    }

    public function clientId(): ClientId
    {
        return $this->clientId;
    }

    public function userAdvertiserLinkCollection(): ?UserAdvertiserLinkCollection
    {
        return $this->userAdvertiserLinkCollection;
    }

    public function linkedUsers(): UserCollection
    {
        return $this->linkedUsers;
    }
}
