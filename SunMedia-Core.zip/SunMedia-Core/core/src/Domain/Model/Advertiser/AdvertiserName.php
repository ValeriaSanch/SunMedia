<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser;

use SunMedia\Shared\Domain\ValueObject\StringValueObject;

class AdvertiserName extends StringValueObject
{
}
