<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser;

use SunMedia\Shared\Domain\ValueObject\Uuid;

class AdvertiserId extends Uuid
{
}
