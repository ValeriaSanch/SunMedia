<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser\Exception;

use SunMedia\Core\Domain\Model\Advertiser\AdvertiserId;
use SunMedia\Shared\Domain\Exception\DomainException;

final class AdvertiserNotFound extends DomainException
{
    public function __construct(AdvertiserId $advertiserId)
    {
        parent::__construct(sprintf("The advertiser with id '%s' not found.", $advertiserId), self::NOT_FOUND);
    }
}
