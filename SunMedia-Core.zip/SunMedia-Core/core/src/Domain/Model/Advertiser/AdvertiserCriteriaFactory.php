<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Advertiser;

use SunMedia\Shared\Domain\Criteria\CriteriaFactory;
use SunMedia\Shared\Domain\Criteria\Expr\CompositeExpression;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Criteria\Expr\ExpressionBuilder;
use SunMedia\Shared\Domain\Model\Context\Context;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class AdvertiserCriteriaFactory extends CriteriaFactory
{
    private static $fieldToSearch = [
        'name',
        'email',
        'creditLimit',
        'categoryId',
        'address.street',
        'address.city',
        'address.country',
        'address.county',
        'address.postalCode',
    ];

    public function fieldToSearch(): array
    {
        return self::$fieldToSearch;
    }

    public function getUserCriteria(SecurityUser $user): Criteria
    {
        $expressionBuilder = new ExpressionBuilder();

        $comparisonArray = [];
        $this->addExpressionForContext($user, Context::thirdParty(), $comparisonArray);
        $this->addExpressionForContext($user, Context::ecommerce(), $comparisonArray);
        $this->addExpressionForContext($user, Context::socialAudience(), $comparisonArray);

        $comparison = (1 === count($comparisonArray)) ? $comparisonArray[0] :
            new CompositeExpression('OR', $comparisonArray);

        if (null !== $comparison) {
            $comparison = $expressionBuilder->andX($comparison, $expressionBuilder->eq('deleted', 0));
        } else {
            $comparison = $expressionBuilder->eq('deleted', 0);
        }

        return new Criteria($comparison);
    }
}
