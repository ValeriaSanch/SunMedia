<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\Event\V1;

use Exception;
use SunMedia\Core\Domain\Model\Client\Client;
use SunMedia\Shared\Domain\Bus\AbstractDomainEvent;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class UsersWereLinkedToClient extends AbstractDomainEvent
{
    public const VERSION = 1;

    public const DOMAIN_EVENT_NAME = 'sunmedia.client.%s.event.client.users_linked';

    /** @var string */
    private $userIds;

    /** @var string */
    private $clientId;

    /**
     * @throws DomainException
     * @throws Exception
     */
    public function __construct(array $userIds, string $id, string $authorUserId)
    {
        parent::__construct(
            $authorUserId,
            SMDatetime::now(),
            $id,
            Client::class,
            self::VERSION,
            sprintf(self::DOMAIN_EVENT_NAME, self::VERSION)
        );

        $this->userIds = $userIds;
        $this->clientId = $id;
    }

    public function userIds(): array
    {
        return $this->userIds;
    }

    public function clientId(): string
    {
        return $this->clientId;
    }

    /**
     * @param mixed $domainEvent
     *
     * @throws DomainException
     */
    public static function fromExternalEvent($domainEvent): self
    {
        return new self(
            $domainEvent->data['attributes']['userIds'],
            $domainEvent->data['attributes']['aggregateId'],
            $domainEvent->data['attributes']['authorId']
        );
    }
}
