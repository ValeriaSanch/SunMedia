<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\Event\V1;

use Exception;
use SunMedia\Core\Domain\Model\Client\Client;
use SunMedia\Shared\Domain\Bus\AbstractDomainEvent;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class ClientWasCreated extends AbstractDomainEvent
{
    public const DOMAIN_EVENT_NAME = 'sunmedia.client.%s.event.client.created';

    private const VERSION = 1;

    /** @var string */
    private $id;

    /** @var string */
    private $name;

    /** @var string */
    private $type;

    /** @var string */
    private $email;

    /** @var string */
    private $contactName;

    /** @var bool */
    private $isExternal;

    /** @var null|string */
    private $taxId;

    /**
     * @throws DomainException
     * @throws Exception
     */
    public function __construct(
        string $authorId,
        string $id,
        string $name,
        string $type,
        string $email,
        string $contactName,
        bool $isExternal,
        ?string $taxId
    ) {
        parent::__construct(
            $authorId,
            SMDatetime::now(),
            $id,
            Client::class,
            self::VERSION,
            sprintf(self::DOMAIN_EVENT_NAME, self::VERSION)
        );
        $this->id = $id;
        $this->name = $name;
        $this->type = $type;
        $this->email = $email;
        $this->contactName = $contactName;
        $this->isExternal = $isExternal;
        $this->taxId = $taxId;
    }

    public function id(): string
    {
        return $this->id;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function type(): string
    {
        return $this->type;
    }

    public function email(): string
    {
        return $this->email;
    }

    public function contactName(): string
    {
        return $this->contactName;
    }

    /**
     * @param mixed $event
     *
     * @throws DomainException
     */
    public static function fromExternalEvent($event): self
    {
        return new self(
            $event->data['attributes']['authorId'],
            $event->data['id'],
            $event->data['attributes']['name'],
            $event->data['attributes']['type'],
            $event->data['attributes']['email'],
            $event->data['attributes']['contactName'],
            $event->data['attributes']['isExternal'],
            $event->data['attributes']['taxId'] ?? null
        );
    }

    public function isExternal(): bool
    {
        return $this->isExternal;
    }

    public function taxId(): ?string
    {
        return $this->taxId;
    }
}
