<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\EventAdjustment;

use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;
use SunMedia\Shared\Domain\Model\DeleteTrait;
use SunMedia\Shared\Domain\Model\DeviceType\DeviceType;
use SunMedia\Shared\Domain\Model\Stream\Stream;
use SunMedia\Shared\Domain\Model\TimeAwareTrait;
use SunMedia\Shared\Domain\Model\TrackingEvent\TrackingEventId;

class EventAdjustment
{
    use TimeAwareTrait;
    use DeleteTrait;

    public static $defaultEventAdjustmentsByStream = [
        Stream::OUT_STREAM_TYPE => [
            'req',
            'op',
            'imp',
            'unf',
        ],
        Stream::IN_STREAM_TYPE => [
            'imp',
            'unf',
        ],
        Stream::NATIVE_STREAM_TYPE => [
            'req',
            'op',
            'imp',
            'unf',
            'ncclk',
        ],
    ];

    /** @var EventAdjustmentId */
    private $id;

    /** @var TrackingEventId */
    private $event;

    /** @var ClientId */
    private $clientId;

    /** @var EventAdjustmentAmount */
    private $amount;

    /** @var Stream */
    private $streamType;

    /** @var DeviceType */
    private $device;

    private function __construct(
        TrackingEventId $event,
        EventAdjustmentAmount $amount,
        Stream $streamType,
        DeviceType $device,
        ?ClientId $clientId = null
    ) {
        $this->event = $event;
        $this->clientId = $clientId;
        $this->amount = $amount;
        $this->streamType = $streamType;
        $this->device = $device;

        $this->createdAt = SMDatetime::now();
        $this->deletedAt = SMDatetime::now();
    }

    public static function create(
        TrackingEventId $event,
        EventAdjustmentAmount $amount,
        Stream $streamType,
        DeviceType $device,
        ?ClientId $clientId = null
    ): self {
        return new self(
            $event,
            $amount,
            $streamType,
            $device,
            $clientId
        );
    }

    public function id(): EventAdjustmentId
    {
        return $this->id;
    }

    public function event(): TrackingEventId
    {
        return $this->event;
    }

    public function clientId(): ClientId
    {
        return $this->clientId;
    }

    public function amount(): EventAdjustmentAmount
    {
        return $this->amount;
    }

    public function streamType(): Stream
    {
        return $this->streamType;
    }

    public function device(): DeviceType
    {
        return $this->device;
    }

    public function updateAmount(EventAdjustmentAmount $amount)
    {
        $this->amount = $amount;
    }
}
