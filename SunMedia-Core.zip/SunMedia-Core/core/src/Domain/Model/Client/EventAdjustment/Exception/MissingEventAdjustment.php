<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\EventAdjustment\Exception;

class MissingEventAdjustment extends \Exception
{
    public function __construct()
    {
        parent::__construct(
            sprintf('Missing event adjustment config.')
        );
    }
}
