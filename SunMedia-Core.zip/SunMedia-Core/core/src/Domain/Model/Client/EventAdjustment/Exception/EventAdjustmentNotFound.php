<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\EventAdjustment\Exception;

use SunMedia\Core\Domain\Model\Client\EventAdjustment\EventAdjustmentId;

class EventAdjustmentNotFound extends \Exception
{
    public function __construct(EventAdjustmentId $id)
    {
        parent::__construct(
            sprintf('Event Adjustment with id %s not found.', $id->value())
        );
    }
}
