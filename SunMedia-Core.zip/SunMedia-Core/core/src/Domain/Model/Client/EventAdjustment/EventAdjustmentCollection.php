<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\EventAdjustment;

use SunMedia\Shared\Domain\Collection\AbstractCollection;
use SunMedia\Shared\Domain\Model\DeviceType\DeviceType;
use SunMedia\Shared\Domain\Model\Stream\Stream;
use SunMedia\Shared\Domain\Model\TrackingEvent\TrackingEventId;

class EventAdjustmentCollection extends AbstractCollection
{
    public function addEventAdjustment(EventAdjustment $eventAdjustment): void
    {
        $this->addItem($eventAdjustment);
    }

    public function addEventAdjustments(iterable $eventAdjustments): void
    {
        foreach ($eventAdjustments as $eventAdjustment) {
            $this->addEventAdjustment($eventAdjustment);
        }
    }

    public function existsWith(TrackingEventId $event, Stream $streamType, DeviceType $device)
    {
        /** @var EventAdjustment $eventAdjustment */
        foreach ($this->toArray() as $eventAdjustment) {
            if ($eventAdjustment->event()->value() === $event->value()
            && $eventAdjustment->streamType()->value() === $streamType->value()
            && $eventAdjustment->device()->value() === $device->value()) {
                return true;
            }
        }

        return false;
    }

    protected function calculateHash($item): string
    {
        return sprintf(
            '%s%s%s',
            $item->streamType()->value(),
            $item->event()->value(),
            $item->device()->value()
        );
    }
}
