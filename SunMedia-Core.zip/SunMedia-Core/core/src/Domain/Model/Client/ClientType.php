<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client;

use SunMedia\Core\Domain\Model\Client\Exception\ClientTypeInvalidOption;
use SunMedia\Shared\Domain\ValueObject\StringValueObject;

class ClientType extends StringValueObject
{
    public const CLIENT_TYPE_SOCIAL_AUDIENCE = 'SOCIAL_AUDIENCE';

    public const CLIENT_TYPE_THIRD_PARTY = 'THIRD_PARTY';

    public const CLIENT_TYPE_ECOMMERCE = 'ECOMMERCE';

    public const CLIENT_TYPE_DASHBOARD_SSP = 'DASHBOARD_SSP';

    public const CLIENT_TYPE_SUNSTUDIO = 'SUNSTUDIO';

    public const VALID_TYPES = [
        self::CLIENT_TYPE_SOCIAL_AUDIENCE,
        self::CLIENT_TYPE_THIRD_PARTY,
        self::CLIENT_TYPE_ECOMMERCE,
        self::CLIENT_TYPE_DASHBOARD_SSP,
        self::CLIENT_TYPE_SUNSTUDIO,
    ];

    /**
     * @throws ClientTypeInvalidOption
     */
    public function __construct(string $value)
    {
        parent::__construct($value);
        $this->checkIfTypeIsValidOption();
    }

    /**
     * @throws ClientTypeInvalidOption
     */
    private function checkIfTypeIsValidOption(): void
    {
        if (!in_array($this->value, self::VALID_TYPES, true)) {
            throw new ClientTypeInvalidOption($this->value);
        }
    }
}
