<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client;

use SunMedia\Shared\Domain\Model\Currency\CurrencyId;

class Wallet
{
    /** @var CurrencyId */
    private $currencyId;

    /** @var WalletAmount */
    private $amount;

    private function __construct(
        CurrencyId $currencyId
    ) {
        $this->currencyId = $currencyId;
        $this->amount = new WalletAmount(0.0);
    }

    public static function create(
        CurrencyId $currencyId
    ) {
        return new self($currencyId);
    }

    public function currencyId(): CurrencyId
    {
        return $this->currencyId;
    }

    public function amount(): WalletAmount
    {
        return $this->amount;
    }

    public function updateCurrency(CurrencyId $currency): void
    {
        $this->currencyId = $currency;
    }

    public function updateAmount(WalletAmount $amount): void
    {
        $this->amount = $amount;
    }
}
