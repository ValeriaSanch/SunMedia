<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client;

use SunMedia\Shared\Domain\Collection\AbstractEntityCollection;

class ClientCollection extends AbstractEntityCollection
{
    public function addClient(Client $client): void
    {
        $this->addItem($client);
    }

    public function addClients(iterable $clients): void
    {
        foreach ($clients as $client) {
            $this->addClient($client);
        }
    }
}
