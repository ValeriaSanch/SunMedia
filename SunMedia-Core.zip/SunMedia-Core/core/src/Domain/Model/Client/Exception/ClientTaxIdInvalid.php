<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\Exception;

use SunMedia\Shared\Domain\Exception\DomainException;

class ClientTaxIdInvalid extends DomainException
{
    public function __construct(int $maxLength, string $taxId)
    {
        parent::__construct(sprintf(
            "The client with TAX_ID '%s' is not valid, it allowed until '%s' characters.",
            $taxId,
            $maxLength
        ), self::BAD_REQUEST);
    }
}
