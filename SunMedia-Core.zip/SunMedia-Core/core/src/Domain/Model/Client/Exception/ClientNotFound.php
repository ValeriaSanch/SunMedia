<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\Exception;

use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Shared\Domain\Exception\DomainException;

final class ClientNotFound extends DomainException
{
    public function __construct(ClientId $clientId)
    {
        parent::__construct(sprintf("Client with id '%s' not found.", $clientId->value()), self::NOT_FOUND);
    }
}
