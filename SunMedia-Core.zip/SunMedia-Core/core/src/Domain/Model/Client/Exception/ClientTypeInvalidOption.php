<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\Exception;

use SunMedia\Shared\Domain\Exception\DomainException;

final class ClientTypeInvalidOption extends DomainException
{
    public function __construct(string $type)
    {
        parent::__construct(sprintf("The client type '%s' it is not a valid option.", $type), self::BAD_REQUEST);
    }
}
