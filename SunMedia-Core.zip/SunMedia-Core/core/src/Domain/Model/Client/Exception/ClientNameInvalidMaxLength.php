<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\Exception;

use SunMedia\Shared\Domain\Exception\DomainException;

final class ClientNameInvalidMaxLength extends DomainException
{
    public function __construct(string $name)
    {
        parent::__construct(
            sprintf("The client name '%s' should have less than fifty characters.", $name),
            self::BAD_REQUEST
        );
    }
}
