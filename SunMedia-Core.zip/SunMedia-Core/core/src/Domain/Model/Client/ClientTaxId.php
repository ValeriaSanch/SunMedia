<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client;

use SunMedia\Core\Domain\Model\Client\Exception\ClientTaxIdInvalid;
use SunMedia\Shared\Domain\ValueObject\NullableStringValueObject;

class ClientTaxId extends NullableStringValueObject
{
    public function __construct(?string $value)
    {
        parent::__construct($value);
        $maxLength = 15;
        if (null !== $value) {
            $this->checkIfLengthIsValid($maxLength, $value);
        }
    }

    public function checkIfLengthIsValid($maxLength, $value): void
    {
        if (strlen($value) > $maxLength) {
            throw new ClientTaxIdInvalid($maxLength, $value);
        }
    }
}
