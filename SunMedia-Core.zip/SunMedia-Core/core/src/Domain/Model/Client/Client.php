<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client;

use SunMedia\Core\Domain\Model\Client\Applier\V1\ClientWasCreatedV1Applier;
use SunMedia\Core\Domain\Model\Client\Applier\V1\ClientWasDeletedV1Applier;
use SunMedia\Core\Domain\Model\Client\Applier\V1\ClientWasUpdatedV1Applier;
use SunMedia\Core\Domain\Model\Client\Applier\V1\UsersWereLinkedToClientV1Applier;
use SunMedia\Core\Domain\Model\User\UserClientLinkCollection;
use SunMedia\Core\Domain\Model\User\UserCollection;
use SunMedia\Shared\Domain\Model\AggregateRootTrait;
use SunMedia\Shared\Domain\Model\DeleteTrait;
use SunMedia\Shared\Domain\Model\Email\Email;
use SunMedia\Shared\Domain\Model\TimeAwareTrait;

class Client
{
    use AggregateRootTrait;
    use ClientWasCreatedV1Applier;
    use ClientWasUpdatedV1Applier;
    use ClientWasDeletedV1Applier;
    use UsersWereLinkedToClientV1Applier;
    use TimeAwareTrait;
    use DeleteTrait;

    /** @var ClientId */
    private $id;

    /** @var ClientName */
    private $name;

    /** @var ClientType */
    private $type;

    /** @var Email */
    private $email;

    /** @var ClientContactName */
    private $contactName;

    /** @var UserClientLinkCollection */
    private $userClientLinkCollection;

    /** @var UserCollection */
    private $linkedUsers;

    /** @var ClientIsExternal */
    private $isExternal;

    /** @var null|ClientTaxId */
    private $taxId;

    public function id(): ClientId
    {
        return $this->id;
    }

    public function name(): ClientName
    {
        return $this->name;
    }

    public function type(): ClientType
    {
        return $this->type;
    }

    public function email(): Email
    {
        return $this->email;
    }

    public function contactName(): ClientContactName
    {
        return $this->contactName;
    }

    public function taxId(): ?ClientTaxId
    {
        return $this->taxId;
    }

    public function userClientLinkCollection(): UserClientLinkCollection
    {
        return $this->userClientLinkCollection;
    }

    public function isExternal(): ClientIsExternal
    {
        return $this->isExternal;
    }

    public function linkedUsers(): UserCollection
    {
        return $this->linkedUsers;
    }
}
