<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client;

use SunMedia\Shared\Domain\ValueObject\BooleanValueObject;

class ClientIsExternal extends BooleanValueObject
{
}
