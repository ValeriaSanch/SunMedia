<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client;

use SunMedia\Shared\Domain\Collection\AbstractIdCollection;

class ClientIdsCollection extends AbstractIdCollection
{
    public function addClientId(ClientId $clientId): void
    {
        $this->addItem($clientId);
    }

    public function addClientIds(iterable $clientsIds): void
    {
        foreach ($clientsIds as $clientId) {
            $this->addClientId($clientId);
        }
    }
}
