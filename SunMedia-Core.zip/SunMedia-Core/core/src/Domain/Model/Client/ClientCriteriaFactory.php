<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client;

use SunMedia\Shared\Domain\Criteria\CriteriaFactory;
use SunMedia\Shared\Domain\Criteria\Expr\CompositeExpression;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Criteria\Expr\ExpressionBuilder;
use SunMedia\Shared\Domain\Model\Context\Context;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class ClientCriteriaFactory extends CriteriaFactory
{
    private static $fieldToSearch = [
        'name',
        'type',
        'contactName',
        'email',
    ];

    public function fieldToSearch(): array
    {
        return self::$fieldToSearch;
    }

    public function getUserCriteria(SecurityUser $user): Criteria
    {
        $expressionBuilder = new ExpressionBuilder();

        $comparisonArray = [];
        $this->addExpressionForContext($user, Context::thirdParty(), $comparisonArray);
        $this->addExpressionForContext($user, Context::ecommerce(), $comparisonArray);
        $this->addExpressionForContext($user, Context::socialAudience(), $comparisonArray);
        $this->addExpressionForContext($user, Context::dashboardSsp(), $comparisonArray);
        $this->addExpressionForContext($user, Context::sunstudio(), $comparisonArray);

        $comparison = [$expressionBuilder->eq('deleted', 0)];

        if ($comparisonArray) {
            $comparison[] = new CompositeExpression('OR', $comparisonArray);
        }

        return new Criteria($expressionBuilder->andX(...$comparison));
    }
}
