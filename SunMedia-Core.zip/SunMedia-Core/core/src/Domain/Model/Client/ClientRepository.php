<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Model\Email\Email;
use SunMedia\Shared\Domain\Model\User\SecurityUser;
use SunMedia\Shared\Domain\Model\User\UserId;

interface ClientRepository
{
    public function byId(ClientId $clientId, Criteria $criteria, ?array $includes = null): ?Client;

    public function save(Client $client, ?array $relations = null): void;

    public function byName(ClientName $clientName): ?Client;

    public function byUserId(UserId $userId): ClientCollection;

    public function count(Criteria $criteria, SecurityUser $securityUser): int;

    public function byEmail(Email $clientEmail): ?Client;

    public function byCriteria(
        Criteria $criteria,
        SecurityUser $securityUser,
        array $includes = null
    ): ClientCollection;
}
