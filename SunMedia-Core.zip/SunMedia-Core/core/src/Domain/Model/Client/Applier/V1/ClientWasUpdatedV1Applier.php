<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\Applier\V1;

use SunMedia\Core\Domain\Model\Client\ClientContactName;
use SunMedia\Core\Domain\Model\Client\ClientIsExternal;
use SunMedia\Core\Domain\Model\Client\ClientName;
use SunMedia\Core\Domain\Model\Client\ClientTaxId;
use SunMedia\Core\Domain\Model\Client\ClientType;
use SunMedia\Core\Domain\Model\Client\Event\V1\ClientWasUpdated;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNameInvalidMaxLength;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNameInvalidMinLength;
use SunMedia\Core\Domain\Model\Client\Exception\ClientTypeInvalidOption;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Model\Email\Email;

trait ClientWasUpdatedV1Applier
{
    /**
     * @throws ClientNameInvalidMaxLength
     * @throws ClientNameInvalidMinLength
     * @throws ClientTypeInvalidOption
     * @throws EmailNotValid
     */
    public function applyThatClientWasUpdatedV1(ClientWasUpdated $clientWasUpdated): void
    {
        $this->name = new ClientName($clientWasUpdated->name());
        $this->type = new ClientType($clientWasUpdated->type());
        $this->email = new Email($clientWasUpdated->email());
        $this->contactName = new ClientContactName($clientWasUpdated->contactName());
        $this->isExternal = new ClientIsExternal($clientWasUpdated->isExternal());
        $this->taxId = new ClientTaxId($clientWasUpdated->taxId());

        $this->updatedAt = $clientWasUpdated->occurredOn();
    }
}
