<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\Applier\V1;

use SunMedia\Core\Domain\Model\Client\ClientContactName;
use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Core\Domain\Model\Client\ClientIsExternal;
use SunMedia\Core\Domain\Model\Client\ClientName;
use SunMedia\Core\Domain\Model\Client\ClientTaxId;
use SunMedia\Core\Domain\Model\Client\ClientType;
use SunMedia\Core\Domain\Model\Client\Event\V1\ClientWasCreated;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNameInvalidMaxLength;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNameInvalidMinLength;
use SunMedia\Core\Domain\Model\Client\Exception\ClientTypeInvalidOption;
use SunMedia\Core\Domain\Model\User\UserClientLinkCollection;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Model\Email\Email;

trait ClientWasCreatedV1Applier
{
    /**
     * @throws ClientNameInvalidMaxLength
     * @throws ClientNameInvalidMinLength
     * @throws ClientTypeInvalidOption
     * @throws DomainException
     * @throws EmailNotValid
     */
    public function applyThatClientWasCreatedV1(ClientWasCreated $clientWasCreated): void
    {
        $this->id = new ClientId($clientWasCreated->id());
        $this->name = new ClientName($clientWasCreated->name());
        $this->email = new Email($clientWasCreated->email());
        $this->type = new ClientType($clientWasCreated->type());
        $this->contactName = new ClientContactName($clientWasCreated->contactName());
        $this->isExternal = new ClientIsExternal($clientWasCreated->isExternal());
        $this->taxId = new ClientTaxId($clientWasCreated->taxId());

        $this->userClientLinkCollection = UserClientLinkCollection::create();

        $this->deleted = false;
        $this->deletedAt = null;
        $this->createdAt = $clientWasCreated->occurredOn();
    }
}
