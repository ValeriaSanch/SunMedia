<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\Applier\V1;

use SunMedia\Core\Domain\Model\Client\ClientId;
use SunMedia\Core\Domain\Model\Client\Event\V1\UsersWereLinkedToClient;
use SunMedia\Core\Domain\Model\User\UserClientLink;
use SunMedia\Core\Domain\Model\User\UserClientLinkCollection;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\User\UserId;

trait UsersWereLinkedToClientV1Applier
{
    /**
     * @throws DomainException
     */
    public function applyThatUsersWereLinkedToClientV1(UsersWereLinkedToClient $clientWasLinkedToUser): void
    {
        $this->userClientLinkCollection = UserClientLinkCollection::create();

        foreach ($clientWasLinkedToUser->userIds() as $userId) {
            $this->userClientLinkCollection->addUserClientLink(new UserClientLink(
                new UserId($userId),
                new ClientId($clientWasLinkedToUser->clientId())
            ));
        }
    }
}
