<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Client\Applier\V1;

use SunMedia\Core\Domain\Model\Client\ClientName;
use SunMedia\Core\Domain\Model\Client\Event\V1\ClientWasDeleted;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNameInvalidMaxLength;
use SunMedia\Core\Domain\Model\Client\Exception\ClientNameInvalidMinLength;
use SunMedia\Shared\Domain\Exception\EmailNotValid;
use SunMedia\Shared\Domain\Model\DeleteTrait;
use SunMedia\Shared\Domain\Model\Email\Email;

trait ClientWasDeletedV1Applier
{
    use DeleteTrait;

    /**
     * @throws ClientNameInvalidMinLength
     * @throws ClientNameInvalidMaxLength
     * @throws EmailNotValid
     */
    public function applyThatClientWasDeletedV1(ClientWasDeleted $clientWasDeleted): void
    {
        $this->name = new ClientName($clientWasDeleted->name());
        $this->email = new Email($clientWasDeleted->email());
        $this->deleted = true;
        $this->deletedAt = $clientWasDeleted->occurredOn();
    }
}
