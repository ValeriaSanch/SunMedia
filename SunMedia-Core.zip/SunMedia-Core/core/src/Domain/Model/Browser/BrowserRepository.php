<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Browser;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Model\Browser\Browser;
use SunMedia\Shared\Domain\Model\Browser\BrowserCollection;
use SunMedia\Shared\Domain\Model\Browser\BrowserFamilyCollection;

interface BrowserRepository
{
    public function byCriteria(Criteria $criteria): BrowserCollection;

    public function save(Browser $browser);

    public function families(): BrowserFamilyCollection;
}
