<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier;

use SunMedia\Shared\Domain\Collection\AbstractEntityCollection;

class CarrierCollection extends AbstractEntityCollection
{
    public function addCarrier(Carrier $carrier): void
    {
        $this->addItem($carrier);
    }

    public function addCarriers(iterable $carriers): void
    {
        foreach ($carriers as $carrier) {
            $this->addCarrier($carrier);
        }
    }
}
