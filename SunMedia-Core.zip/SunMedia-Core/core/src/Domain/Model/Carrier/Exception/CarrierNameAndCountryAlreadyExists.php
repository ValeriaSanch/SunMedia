<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\Exception;

use SunMedia\Core\Domain\Model\Carrier\CarrierName;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Country\CountryIso;

final class CarrierNameAndCountryAlreadyExists extends DomainException
{
    public function __construct(CarrierName $name, CountryIso $countryIso)
    {
        parent::__construct(sprintf('%s %s already exists.', $name->value(), $countryIso->value()), self::BAD_REQUEST);
    }
}
