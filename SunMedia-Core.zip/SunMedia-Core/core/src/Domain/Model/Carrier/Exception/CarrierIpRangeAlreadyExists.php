<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\Exception;

use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeCidr;
use SunMedia\Shared\Domain\Exception\DomainException;

final class CarrierIpRangeAlreadyExists extends DomainException
{
    public function __construct(IpRangeCidr $cidr)
    {
        parent::__construct(sprintf("Carrier IpRangeCidr '%s' already exists.", $cidr->value()), self::BAD_REQUEST);
    }
}
