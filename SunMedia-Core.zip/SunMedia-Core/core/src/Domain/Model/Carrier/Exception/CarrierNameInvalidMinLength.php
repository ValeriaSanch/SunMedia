<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\Exception;

use SunMedia\Shared\Domain\Exception\DomainException;

final class CarrierNameInvalidMinLength extends DomainException
{
    public function __construct(string $name)
    {
        parent::__construct(
            sprintf("The carrier name '%s' should have more than three characters.", $name),
            self::BAD_REQUEST
        );
    }
}
