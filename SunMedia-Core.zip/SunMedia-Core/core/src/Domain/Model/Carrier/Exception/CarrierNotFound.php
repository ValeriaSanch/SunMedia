<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\Exception;

use SunMedia\Core\Domain\Model\Carrier\CarrierId;
use SunMedia\Shared\Domain\Exception\DomainException;

final class CarrierNotFound extends DomainException
{
    public function __construct(CarrierId $carrierId)
    {
        parent::__construct(sprintf('Carrier with id: %s not found.', $carrierId), self::NOT_FOUND);
    }
}
