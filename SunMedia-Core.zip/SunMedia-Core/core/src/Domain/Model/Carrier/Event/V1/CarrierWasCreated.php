<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\Event\V1;

use Exception;
use SunMedia\Core\Domain\Model\Carrier\Carrier;
use SunMedia\Shared\Domain\Bus\AbstractDomainEvent;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class CarrierWasCreated extends AbstractDomainEvent
{
    public const DOMAIN_EVENT_NAME = 'sunmedia.carrier.%s.event.carrier.created';

    private const VERSION = 1;

    /** @var string */
    private $id;

    /** @var string */
    private $name;

    /** @var array */
    private $asn;

    /** @var string */
    private $countryIso;

    /** @var array */
    private $ipRanges;

    /**
     * @throws DomainException
     * @throws Exception
     */
    public function __construct(
        string $authorId,
        string $id,
        string $name,
        array $asn,
        string $countryIso,
        array $ipRanges
    ) {
        parent::__construct(
            $authorId,
            SMDatetime::now(),
            $id,
            Carrier::class,
            self::VERSION,
            sprintf(self::DOMAIN_EVENT_NAME, self::VERSION)
        );

        $this->id = $id;
        $this->name = $name;
        $this->asn = $asn;
        $this->countryIso = $countryIso;
        $this->ipRanges = $ipRanges;
    }

    public function id(): string
    {
        return $this->id;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function asn(): array
    {
        return $this->asn;
    }

    public function countryIso(): string
    {
        return $this->countryIso;
    }

    public function ipRanges(): array
    {
        return $this->ipRanges;
    }
}
