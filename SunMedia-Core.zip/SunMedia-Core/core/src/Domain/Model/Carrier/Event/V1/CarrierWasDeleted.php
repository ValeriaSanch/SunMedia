<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\Event\V1;

use Exception;
use SunMedia\Core\Domain\Model\Carrier\Carrier;
use SunMedia\Shared\Domain\Bus\AbstractDomainEvent;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

class CarrierWasDeleted extends AbstractDomainEvent
{
    public const DOMAIN_EVENT_NAME = 'sunmedia.carrier.%s.event.carrier.deleted';

    private const VERSION = 1;

    /** @var string */
    private $id;

    /**
     * @throws DomainException
     * @throws Exception
     */
    public function __construct(string $authorId, string $id)
    {
        parent::__construct(
            $authorId,
            SMDatetime::now(),
            $id,
            Carrier::class,
            self::VERSION,
            sprintf(self::DOMAIN_EVENT_NAME, self::VERSION)
        );

        $this->id = $id;
    }

    public function id(): string
    {
        return $this->id;
    }
}
