<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier;

use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeFirstIp;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeLastIp;
use SunMedia\Shared\Domain\Criteria\CriteriaFactory;
use SunMedia\Shared\Domain\Criteria\Expr\Criteria;
use SunMedia\Shared\Domain\Criteria\Expr\ExpressionBuilder;
use SunMedia\Shared\Domain\Model\Country\CountryIso;
use SunMedia\Shared\Domain\Model\User\SecurityUser;

class CarrierCriteriaFactory extends CriteriaFactory
{
    private static $fieldToSearch = ['name', 'asn', 'country', 'carrierIpRangeLink.cidr'];

    public function fieldToSearch(): array
    {
        return self::$fieldToSearch;
    }

    public function getUserCriteria(SecurityUser $user): Criteria
    {
        return new Criteria();
    }

    public function checkCarrierNameAndCountryAlreadyExists(CarrierName $carrierName, CountryIso $countryIso): Criteria
    {
        $expressionBuilder = new ExpressionBuilder();

        $comparisonCarrierName = $expressionBuilder->eq('name', $carrierName->value());

        $comparisonCountryIso = $expressionBuilder->eq('countryIso', $countryIso->value());

        $comparison = $expressionBuilder->andX($comparisonCarrierName, $comparisonCountryIso);

        if (null !== $comparison) {
            $comparison = $expressionBuilder->andX($comparison, $expressionBuilder->eq('deleted', 0));
        } else {
            $comparison = $expressionBuilder->eq('deleted', 0);
        }

        return new Criteria($comparison);
    }

    public function checkIpRange(
        IpRangeFirstIp $firstIp,
        IpRangeLastIp $lastIp,
        CarrierId $carrierId,
        CarrierName $carrierName
    ): Criteria {
        $expressionBuilder = new ExpressionBuilder();

        $comparisonFirstIpWithIpRangeFirstIp = $expressionBuilder->lte('carrierIpRangeLink.firstIp', $firstIp->value());

        $comparisonFirstIpWithIpRangeLastIp = $expressionBuilder->gte('carrierIpRangeLink.lastIp', $firstIp->value());

        $comparisonLastIpWithIpRangeFirstIp = $expressionBuilder->lte('carrierIpRangeLink.firstIp', $lastIp->value());

        $comparisonLastIpWithIpRangeLastIp = $expressionBuilder->gte('carrierIpRangeLink.lastIp', $lastIp->value());

        $comparisonCarrierId = $expressionBuilder->neq('carrierIpRangeLink.carrierId', $carrierId->value());

        $comparisonCarrierName = $expressionBuilder->neq('name', $carrierName->value());

        return new Criteria($expressionBuilder->andX(
            $expressionBuilder->orX(
                $expressionBuilder->andX(
                    $comparisonFirstIpWithIpRangeFirstIp,
                    $comparisonFirstIpWithIpRangeLastIp
                ),
                $expressionBuilder->andX($comparisonLastIpWithIpRangeFirstIp, $comparisonLastIpWithIpRangeLastIp)
            ),
            $comparisonCarrierId,
            $comparisonCarrierName
        ));
    }

    public function findByInterval(int $intervalStart, int $intervalEnd): Criteria
    {
        $expressionBuilder = new ExpressionBuilder();

        $comparisonFirstIpWithIntervalStart = $expressionBuilder->gte('carrierIpRangeLink.firstIp', $intervalStart);

        $comparisonFirstIpWithIntervalEnd = $expressionBuilder->lte('carrierIpRangeLink.lastIp', $intervalEnd);

        return new Criteria($expressionBuilder->andX(
            $comparisonFirstIpWithIntervalStart,
            $comparisonFirstIpWithIntervalEnd
        ));
    }
}
