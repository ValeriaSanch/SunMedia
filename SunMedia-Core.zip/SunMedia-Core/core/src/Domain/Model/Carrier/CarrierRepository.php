<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier;

use SunMedia\Shared\Domain\Criteria\Expr\Criteria;

interface CarrierRepository
{
    public function save(Carrier $carrier): void;

    public function byId(CarrierId $carrierId, Criteria $criteria): ?Carrier;

    public function byCriteria(Criteria $criteria): CarrierCollection;

    public function count(Criteria $criteria): int;
}
