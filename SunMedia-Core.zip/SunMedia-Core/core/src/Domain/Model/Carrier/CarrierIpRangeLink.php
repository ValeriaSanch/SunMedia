<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier;

use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRange;

class CarrierIpRangeLink
{
    /** @var int */
    private $id;

    /** @var CarrierId */
    private $carrierId;

    /** @var IpRange */
    private $ipRange;

    public function __construct(CarrierId $carrierId, IpRange $ipRange)
    {
        $this->carrierId = $carrierId;
        $this->ipRange = $ipRange;
    }

    public function id(): int
    {
        return $this->id;
    }

    public function carrierId(): CarrierId
    {
        return $this->carrierId;
    }

    public function ipRange(): IpRange
    {
        return $this->ipRange;
    }
}
