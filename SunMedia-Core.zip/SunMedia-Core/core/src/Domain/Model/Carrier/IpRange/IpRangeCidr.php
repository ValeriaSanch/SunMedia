<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\IpRange;

use SunMedia\Shared\Domain\ValueObject\StringValueObject;

class IpRangeCidr extends StringValueObject
{
    public function __construct(string $value)
    {
        $this->validateCidr($value);
        parent::__construct($value);
    }

    public function validateCidr(string $cidr)
    {
        $parts = explode('/', $cidr);
        if (2 != count($parts)) {
            return false;
        }

        $ip = $parts[0];
        $netmask = intval($parts[1]);

        if ($netmask < 0) {
            return false;
        }

        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return $netmask <= 32;
        }

        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            return $netmask <= 128;
        }

        return false;
    }
}
