<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\IpRange;

class IpRange
{
    /** @var IpRangeCidr */
    private $cidr;

    /** @var IpRangeNetmask */
    private $netmask;

    /** @var IpRangeFirstIp */
    private $firstIp;

    /** @var IpRangeLastIp */
    private $lastIp;

    private function __construct(
        IpRangeCidr $cidr,
        IpRangeNetmask $netmask,
        IpRangeFirstIp $firstIp,
        IpRangeLastIp $lastIp
    ) {
        $this->cidr = $cidr;
        $this->netmask = $netmask;
        $this->firstIp = $firstIp;
        $this->lastIp = $lastIp;
    }

    public static function create(
        IpRangeCidr $cidr,
        IpRangeNetmask $netmask,
        IpRangeFirstIp $firstIp,
        IpRangeLastIp $lastIp
    ) {
        return new self(
            $cidr,
            $netmask,
            $firstIp,
            $lastIp
        );
    }

    public function cidr(): IpRangeCidr
    {
        return $this->cidr;
    }

    public function netmask(): IpRangeNetmask
    {
        return $this->netmask;
    }

    public function firstIp(): IpRangeFirstIp
    {
        return $this->firstIp;
    }

    public function lastIp(): IpRangeLastIp
    {
        return $this->lastIp;
    }

    public static function cidrToRange(string $cidr): array
    {
        $range = [];
        $cidr = explode('/', $cidr);
        $range[0] = long2ip((ip2long($cidr[0])) & ((-1 << (32 - (int) $cidr[1]))));
        $range[1] = long2ip((ip2long($range[0])) + pow(2, (32 - (int) $cidr[1])) - 1);

        return $range;
    }

    public static function cidrToFirstIp(string $cidr): string
    {
        return self::cidrToRange($cidr)[0];
    }

    public static function cidrToLastIp(string $cidr): string
    {
        return self::cidrToRange($cidr)[1];
    }

    public static function cidrToNetmask(string $cidr): string
    {
        $cidr = explode('/', $cidr);

        return long2ip(-1 << (32 - (int) $cidr[1]));
    }
}
