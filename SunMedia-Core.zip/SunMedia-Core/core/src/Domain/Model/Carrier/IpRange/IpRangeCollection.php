<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\IpRange;

use SunMedia\Shared\Domain\Collection\AbstractEntityCollection;

class IpRangeCollection extends AbstractEntityCollection
{
    public function addIpRange(IpRange $ipRange): void
    {
        $this->addItem($ipRange);
    }

    public function addIpRanges(iterable $ipRanges): void
    {
        foreach ($ipRanges as $ipRange) {
            $this->addIpRange($ipRange);
        }
    }

    public function serializeIpRange(): array
    {
        return parent::serialize(function (IpRange $ipRange) {
            return [
                'cidr' => $ipRange->cidr()->value(),
                'netmask' => $ipRange->netmask()->value(),
                'firstIp' => $ipRange->firstIp()->value(),
                'lastIp' => $ipRange->lastIp()->value(),
            ];
        });
    }

    protected function calculateHash($item): string
    {
        return (string)
            $item->lastIp()->value().$item->cidr()->value().
            $item->netmask()->value().$item->firstIp()->value();
    }
}
