<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\IpRange;

use SunMedia\Shared\Domain\ValueObject\StringValueObject;

class IpRangeNetmask extends StringValueObject
{
}
