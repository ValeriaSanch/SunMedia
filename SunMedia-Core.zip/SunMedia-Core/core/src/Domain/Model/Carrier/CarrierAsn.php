<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier;

use SunMedia\Shared\Domain\ValueObject\ArrayValueObject;

class CarrierAsn extends ArrayValueObject
{
}
