<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\Applier\V1;

use Exception;
use SunMedia\Core\Domain\Model\Carrier\Event\V1\CarrierWasDeleted;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeCollection;
use SunMedia\Shared\Domain\Model\DeleteTrait;

trait CarrierWasDeletedV1Applier
{
    use DeleteTrait;

    /**
     * @throws Exception
     */
    public function applyThatCarrierWasDeletedV1(CarrierWasDeleted $carrierWasDeleted): void
    {
        $this->ipRangeCollection = IpRangeCollection::create();
        $this->delete();
    }
}
