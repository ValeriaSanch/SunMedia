<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\Applier\V1;

use Exception;
use SunMedia\Core\Domain\Model\Carrier\CarrierAsn;
use SunMedia\Core\Domain\Model\Carrier\CarrierId;
use SunMedia\Core\Domain\Model\Carrier\CarrierName;
use SunMedia\Core\Domain\Model\Carrier\Event\V1\CarrierWasUpdated;
use SunMedia\Core\Domain\Model\Carrier\Exception\CarrierNameInvalidMaxLength;
use SunMedia\Core\Domain\Model\Carrier\Exception\CarrierNameInvalidMinLength;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRange;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeCidr;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeCollection;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeFirstIp;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeLastIp;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeNetmask;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Country\CountryIso;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

trait CarrierWasUpdatedV1Applier
{
    /**
     * @throws CarrierNameInvalidMaxLength
     * @throws CarrierNameInvalidMinLength
     * @throws DomainException
     * @throws Exception
     */
    public function applyThatCarrierWasUpdatedV1(CarrierWasUpdated $carrierWasUpdated): void
    {
        $this->id = new CarrierId($carrierWasUpdated->id());
        $this->name = new CarrierName($carrierWasUpdated->name());
        $this->asn = new CarrierAsn($carrierWasUpdated->asn());
        $this->countryIso = new CountryIso($carrierWasUpdated->countryIso());
        $this->updatedAt = SMDatetime::now();
        $this->ipRangeCollection = IpRangeCollection::create();
        foreach ($carrierWasUpdated->ipRanges() as $ipRange) {
            $this->ipRangeCollection->addIpRange(IpRange::create(
                new IpRangeCidr($ipRange['cidr']),
                new IpRangeNetmask($ipRange['netmask']),
                new IpRangeFirstIp($ipRange['firstIp']),
                new IpRangeLastIp($ipRange['lastIp'])
            ));
        }
    }
}
