<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier\Applier\V1;

use Exception;
use SunMedia\Core\Domain\Model\Carrier\CarrierAsn;
use SunMedia\Core\Domain\Model\Carrier\CarrierId;
use SunMedia\Core\Domain\Model\Carrier\CarrierName;
use SunMedia\Core\Domain\Model\Carrier\Event\V1\CarrierWasCreated;
use SunMedia\Core\Domain\Model\Carrier\Exception\CarrierNameInvalidMaxLength;
use SunMedia\Core\Domain\Model\Carrier\Exception\CarrierNameInvalidMinLength;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRange;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeCidr;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeCollection;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeFirstIp;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeLastIp;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeNetmask;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\Country\CountryIso;
use SunMedia\Shared\Domain\Model\Date\SMDatetime;

trait CarrierWasCreatedV1Applier
{
    /**
     * @throws CarrierNameInvalidMaxLength
     * @throws CarrierNameInvalidMinLength
     * @throws DomainException
     * @throws Exception
     */
    public function applyThatCarrierWasCreatedV1(CarrierWasCreated $carrierWasCreated): void
    {
        $this->id = new CarrierId($carrierWasCreated->id());
        $this->name = new CarrierName($carrierWasCreated->name());
        $this->asn = new CarrierAsn($carrierWasCreated->asn());
        $this->countryIso = new CountryIso($carrierWasCreated->countryIso());
        $this->ipRangeCollection = IpRangeCollection::create();
        foreach ($carrierWasCreated->ipRanges() as $ipRange) {
            $this->ipRangeCollection->addIpRange(IpRange::create(new IpRangeCidr($ipRange['cidr']), new IpRangeNetmask($ipRange['netmask']), new IpRangeFirstIp($ipRange['firstIp']), new IpRangeLastIp($ipRange['lastIp'])));
        }
        $this->deleted = false;
        $this->deletedAt = null;
        $this->createdAt = SMDatetime::now();
        $this->updatedAt = SMDatetime::now();
    }
}
