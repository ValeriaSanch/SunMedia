<?php

declare(strict_types=1);

namespace SunMedia\Core\Domain\Model\Carrier;

use SunMedia\Core\Domain\Model\Carrier\Applier\V1\CarrierWasCreatedV1Applier;
use SunMedia\Core\Domain\Model\Carrier\Applier\V1\CarrierWasDeletedV1Applier;
use SunMedia\Core\Domain\Model\Carrier\Applier\V1\CarrierWasUpdatedV1Applier;
use SunMedia\Core\Domain\Model\Carrier\Event\V1\CarrierWasCreated;
use SunMedia\Core\Domain\Model\Carrier\Event\V1\CarrierWasDeleted;
use SunMedia\Core\Domain\Model\Carrier\Event\V1\CarrierWasUpdated;
use SunMedia\Core\Domain\Model\Carrier\IpRange\IpRangeCollection;
use SunMedia\Core\Domain\Model\User\User;
use SunMedia\Shared\Domain\Exception\DomainException;
use SunMedia\Shared\Domain\Model\AggregateRootTrait;
use SunMedia\Shared\Domain\Model\Country\Country;
use SunMedia\Shared\Domain\Model\Country\CountryIso;
use SunMedia\Shared\Domain\Model\TimeAwareTrait;
use SunMedia\Shared\Domain\Model\User\UserId;

class Carrier
{
    use AggregateRootTrait;
    use CarrierWasCreatedV1Applier;
    use CarrierWasUpdatedV1Applier;
    use CarrierWasDeletedV1Applier;
    use TimeAwareTrait;

    /** @var CarrierId */
    private $id;

    /** @var CarrierName */
    private $name;

    /** @var CarrierAsn */
    private $asn;

    /** @var CountryIso */
    private $countryIso;

    /** @var Country */
    private $country;

    /** @var IpRangeCollection */
    private $ipRangeCollection;

    /**
     * @throws DomainException
     */
    private function __construct(
        UserId $authorId,
        CarrierId $id,
        CarrierName $name,
        CarrierAsn $asn,
        Country $country,
        IpRangeCollection $ipRangeCollection
    ) {
        $this->applyAndPublishThat(new CarrierWasCreated(
            $authorId->value(),
            $id->value(),
            $name->value(),
            $asn->value(),
            $country->iso()->value(),
            $ipRangeCollection->serializeIpRange()
        ));
    }

    /**
     * @throws DomainException
     */
    public static function create(
        UserId $authorId,
        CarrierId $id,
        CarrierName $name,
        CarrierAsn $asn,
        Country $country,
        IpRangeCollection $ipRangeCollection
    ): self {
        return new self($authorId, $id, $name, $asn, $country, $ipRangeCollection);
    }

    public function name(): CarrierName
    {
        return $this->name;
    }

    public function asn(): CarrierAsn
    {
        return $this->asn;
    }

    public function countryIso(): CountryIso
    {
        return $this->countryIso;
    }

    /**
     * @throws DomainException
     */
    public function remove(User $author): void
    {
        $this->applyAndPublishThat(new CarrierWasDeleted($author->id()->value(), $this->id()->value()));
    }

    public function id(): CarrierId
    {
        return $this->id;
    }

    /**
     * @throws DomainException
     */
    public function update(
        User $author,
        CarrierName $name,
        CarrierAsn $asn,
        Country $country,
        IpRangeCollection $ipRangeCollection
    ): void {
        $this->applyAndPublishThat(new CarrierWasUpdated(
            $author->id()->value(),
            $this->id()->value(),
            $name->value(),
            $asn->value(),
            $country->iso()->value(),
            $ipRangeCollection->serializeIpRange()
        ));
    }

    public function ipRangeCollection(): IpRangeCollection
    {
        return $this->ipRangeCollection;
    }

    public function country(): Country
    {
        return $this->country;
    }
}
