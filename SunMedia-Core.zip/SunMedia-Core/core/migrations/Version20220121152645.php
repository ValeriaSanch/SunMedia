<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220121152645 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'mapping with externalId platform';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('TRUNCATE table browser');
        $this->addSql('TRUNCATE table device');
        $this->addSql('TRUNCATE table operating_system');

        $this->loadSqlScript('browser.sql');
        $this->loadSqlScript('device.sql');
        $this->loadSqlScript('operating_system.sql');

        $this->addSql('ALTER TABLE browser ADD platform_value JSON DEFAULT NULL COMMENT \'(DC2Type:json_array)\'');
        $this->addSql('ALTER TABLE country ADD platform_value JSON DEFAULT NULL COMMENT \'(DC2Type:json_array)\'');
        $this->addSql('ALTER TABLE device ADD platform_value JSON DEFAULT NULL COMMENT \'(DC2Type:json_array)\'');
        $this->addSql('ALTER TABLE operating_system ADD platform_value JSON DEFAULT NULL COMMENT \'(DC2Type:json_array)\'');
        $this->loadData($schema);
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE browser DROP platform_value');
        $this->addSql('ALTER TABLE country DROP platform_value');
        $this->addSql('ALTER TABLE device DROP platform_value');
        $this->addSql('ALTER TABLE operating_system DROP platform_value');
    }

    private function loadSqlScript(string $sqlScriptName): void
    {
        $absolutePathSqlScript = sprintf(__DIR__.'/scripts/initial_migration/%s', $sqlScriptName);

        if (false === file_exists($absolutePathSqlScript)) {
            throw new \RuntimeException(sprintf('File not found at path: %s', $absolutePathSqlScript));
        }

        $sqlScript = fopen($absolutePathSqlScript, 'rb');
        $this->addSql(stream_get_contents($sqlScript));
        fclose($sqlScript);
    }

    public function loadData(Schema $schema): void
    {
        $config = [
            'smart_ad_server' => ['country','browser', 'device', 'operating_system'],
            'video_plaza' => ['browser', 'device', 'operating_system']
        ];
        $data = [];
        foreach ($config as $folder => $files) {
            $platform = strtoupper($folder);
            foreach ($files as $file) {
                $table = $file;
                $absolutePathJson = sprintf(__DIR__ . '/scripts/mapping_external_platforms/%s/%s.json', $folder, $file);

                $sqlScript = fopen($absolutePathJson, 'rb');
                $content = json_decode(stream_get_contents($sqlScript), true);
                fclose($sqlScript);

                foreach ($content['data'] as $sunmediaId => $externalId) {
                    $data[$table][$sunmediaId][$platform] = $externalId;
                }
            }
        }

        foreach ($data as $table => $items){
            $id = $table === 'country' ? 'iso3_value' : 'id';
            $query = '';
            foreach ($items as $sunMediaId => $value){
                $value = json_encode($value);
                $query .= "UPDATE {$table} SET platform_value = '{$value}' WHERE {$id} = '{$sunMediaId}';";
            }
            $this->addSql($query);
        }
    }

    private function inserts(Schema $schema)
    {
        $this->addSql("INSERT INTO browser (id, family_value, version_value) VALUES (6, 'Opera', 'All');");
    }
}
