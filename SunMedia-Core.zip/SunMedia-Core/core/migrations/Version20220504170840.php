<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220504170840 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Rename table user_salesforce by salesforce_user';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('ALTER TABLE user CHANGE salesforce_id salesforce_user_id VARCHAR(255) DEFAULT NULL COMMENT \'(DC2Type:salesforce_user_id)\'');
        $this->addSql('ALTER TABLE user_salesforce CHANGE id id VARCHAR(255) NOT NULL COMMENT \'(DC2Type:salesforce_user_id)\'');
        $this->addSql('DROP INDEX user_salesforce_email_index ON user_salesforce');
        $this->addSql('DROP INDEX user_salesforce_name_index ON user_salesforce');
        $this->addSql('ALTER TABLE user_salesforce RENAME salesforce_user');
        $this->addSql('CREATE INDEX salesforce_user_name_index ON salesforce_user (name_value)');
        $this->addSql('CREATE UNIQUE INDEX salesforce_user_email_index ON salesforce_user (email_value)');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE user CHANGE salesforce_user_id salesforce_id VARCHAR(255) CHARACTER SET utf8 DEFAULT NULL COLLATE `utf8_unicode_ci`');
        $this->addSql('DROP INDEX salesforce_user_name_index ON salesforce_user');
        $this->addSql('DROP INDEX salesforce_user_email_index ON salesforce_user');
        $this->addSql('ALTER TABLE salesforce_user RENAME user_salesforce');
        $this->addSql('ALTER TABLE user_salesforce CHANGE id id VARCHAR(255) CHARACTER SET utf8 NOT NULL COLLATE `utf8_unicode_ci`');
        $this->addSql('CREATE INDEX user_salesforce_name_index ON user_salesforce (name_value)');
        $this->addSql('CREATE UNIQUE INDEX user_salesforce_email_index ON user_salesforce (email_value)');
    }
}
