<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220420155517 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE user_salesforce ADD company_name_value VARCHAR(255) NULL COLLATE `utf8_unicode_ci`');
        $this->addSql('ALTER TABLE user_salesforce ADD department_value VARCHAR(255) NULL COLLATE `utf8_unicode_ci`');
        $this->addSql('ALTER TABLE user_salesforce ADD enabled_value TINYINT(1) NOT NULL DEFAULT 1');
        $this->addSql('ALTER TABLE user_salesforce ADD country_value VARCHAR(255) NULL COLLATE `utf8_unicode_ci`');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE user_salesforce DROP company_name_value');
        $this->addSql('ALTER TABLE user_salesforce DROP department_value');
        $this->addSql('ALTER TABLE user_salesforce DROP enabled_value');
        $this->addSql('ALTER TABLE user_salesforce DROP country_value');

    }
}
