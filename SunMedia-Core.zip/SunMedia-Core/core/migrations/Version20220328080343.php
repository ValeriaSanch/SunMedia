<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220328080343 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP INDEX api_platform_price_device_index ON api_platform_price');
        $this->addSql('DROP INDEX api_platform_price_sdk_index ON api_platform_price');
        $this->addSql('DROP INDEX api_platform_price_type_index ON api_platform_price');
        $this->addSql('ALTER TABLE api_platform_price DROP type_value, DROP domain_value, DROP sdk_value, DROP site_id_value, DROP page_id_value, DROP format_id_value, DROP device_value, DROP currency_value, DROP clk_price_value, CHANGE imp_price_value price_value DOUBLE PRECISION NOT NULL');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE api_platform_price ADD type_value VARCHAR(255) CHARACTER SET utf8 NOT NULL COLLATE `utf8_unicode_ci`, ADD domain_value VARCHAR(255) CHARACTER SET utf8 NOT NULL COLLATE `utf8_unicode_ci`, ADD sdk_value VARCHAR(255) CHARACTER SET utf8 NOT NULL COLLATE `utf8_unicode_ci`, ADD site_id_value VARCHAR(255) CHARACTER SET utf8 DEFAULT NULL COLLATE `utf8_unicode_ci`, ADD page_id_value VARCHAR(255) CHARACTER SET utf8 DEFAULT NULL COLLATE `utf8_unicode_ci`, ADD format_id_value VARCHAR(255) CHARACTER SET utf8 DEFAULT NULL COLLATE `utf8_unicode_ci`, ADD device_value VARCHAR(255) CHARACTER SET utf8 NOT NULL COLLATE `utf8_unicode_ci`, ADD currency_value VARCHAR(255) CHARACTER SET utf8 NOT NULL COLLATE `utf8_unicode_ci`, ADD clk_price_value DOUBLE PRECISION DEFAULT NULL, CHANGE price_value imp_price_value DOUBLE PRECISION NOT NULL');
        $this->addSql('CREATE INDEX api_platform_price_device_index ON api_platform_price (device_value)');
        $this->addSql('CREATE INDEX api_platform_price_sdk_index ON api_platform_price (sdk_value)');
        $this->addSql('CREATE INDEX api_platform_price_type_index ON api_platform_price (type_value)');
    }
}
