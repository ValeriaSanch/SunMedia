INSERT INTO operating_system (id, family_value, version_value) VALUES (1, 'Android', 'All');
INSERT INTO operating_system (id, family_value, version_value) VALUES (2, 'iOS', 'All');
INSERT INTO operating_system (id, family_value, version_value) VALUES (3, 'Mac OS', 'All');
INSERT INTO operating_system (id, family_value, version_value) VALUES (4, 'Windows Phone', 'All');
INSERT INTO operating_system (id, family_value, version_value) VALUES (5, 'Windows', 'All');
INSERT INTO operating_system (id, family_value, version_value) VALUES (6, 'Windows Mobile', 'All');
INSERT INTO operating_system (id, family_value, version_value) VALUES (7, 'WebOS', 'All');
INSERT INTO operating_system (id, family_value, version_value) VALUES (7, 'Linux', 'All');
INSERT INTO operating_system (id, family_value, version_value) VALUES (7, 'Other', 'All');