DELETE FROM user WHERE id LIKE 'f6d31db3-3ece-49a6-80c1-a947def245f0';
DELETE FROM user_context_role_link WHERE user_id LIKE 'f6d31db3-3ece-49a6-80c1-a947def245f0';
DELETE FROM user WHERE id LIKE '047ec47a-ec04-4c64-abf7-edfc252c5ece';
DELETE FROM user_context_role_link WHERE user_id LIKE '047ec47a-ec04-4c64-abf7-edfc252c5ece';