DELETE FROM device WHERE id = 1;
DELETE FROM device WHERE id = 2;
DELETE FROM device WHERE id = 3;
DELETE FROM device WHERE id = 4;
DELETE FROM device WHERE id = 5;
DELETE FROM device WHERE id = 6;
INSERT INTO device (id, family_value, brand_value, model_value) VALUES (1, 'Mobile', '-', '-');
INSERT INTO device (id, family_value, brand_value, model_value) VALUES (3, 'Desktop', '-', '-');
