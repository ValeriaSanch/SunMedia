INSERT INTO browser (id, family_value, version_value) VALUES (1, 'Firefox', 'All');
INSERT INTO browser (id, family_value, version_value) VALUES (2, 'Google Chrome', 'All');
INSERT INTO browser (id, family_value, version_value) VALUES (3, 'IE', 'All');
INSERT INTO browser (id, family_value, version_value) VALUES (4, 'Microsoft Edge', 'All');
INSERT INTO browser (id, family_value, version_value) VALUES (5, 'Safari', 'All');
INSERT INTO browser (id, family_value, version_value) VALUES (6, 'Opera', 'All');
INSERT INTO browser (id, family_value, version_value) VALUES (7, 'Other', 'All');