INSERT INTO currency (id, name_value, symbol_value) VALUES ('ARS', 'Argentine peso', '$');
INSERT INTO currency (id, name_value, symbol_value) VALUES ('BRL', 'Brazilian real', 'R$');
INSERT INTO currency (id, name_value, symbol_value) VALUES ('COP', 'Colombian peso', 'Col$');
INSERT INTO currency (id, name_value, symbol_value) VALUES ('EUR', 'European Euro', '€');
INSERT INTO currency (id, name_value, symbol_value) VALUES ('GBP', 'British pound', '£');
INSERT INTO currency (id, name_value, symbol_value) VALUES ('MXN', 'Mexican peso', '$');
INSERT INTO currency (id, name_value, symbol_value) VALUES ('USD', 'United States dollar', 'US$');