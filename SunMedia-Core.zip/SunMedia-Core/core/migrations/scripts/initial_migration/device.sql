INSERT INTO device (id, family_value, brand_value, model_value) VALUES (1, 'Mobile', '-', '-');
INSERT INTO device (id, family_value, brand_value, model_value) VALUES (3, 'Desktop', '-', '-');
INSERT INTO device (id, family_value, brand_value, model_value) VALUES (4, 'Android Tablet', '-', '-');
INSERT INTO device (id, family_value, brand_value, model_value) VALUES (5, 'Android Phone', '-', '-');
INSERT INTO device (id, family_value, brand_value, model_value) VALUES (6, 'IOS Tablet', '-', '-');
INSERT INTO device (id, family_value, brand_value, model_value) VALUES (7, 'IOS Phone', '-', '-');
INSERT INTO device (id, family_value, brand_value, model_value) VALUES (8, 'Smart TV', '-', '-');