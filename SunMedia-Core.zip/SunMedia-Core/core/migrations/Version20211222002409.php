<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211222002409 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Change datetime_immutable for SMDatetime';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('ALTER TABLE action CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\'');
        $this->addSql('ALTER TABLE advertiser CHANGE deleted_at deleted_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\'');
        $this->addSql('ALTER TABLE carrier CHANGE deleted_at deleted_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\'');
        $this->addSql('ALTER TABLE client CHANGE deleted_at deleted_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\'');
        $this->addSql('ALTER TABLE feed CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\'');
        $this->addSql('ALTER TABLE publisher CHANGE deleted_at deleted_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE created_at created_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\'');
        $this->addSql('ALTER TABLE user CHANGE deleted_at deleted_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\'');
        $this->addSql('ALTER TABLE user_salesforce CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:SMDatetime)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:SMDatetime)\'');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE action CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\'');
        $this->addSql('ALTER TABLE advertiser CHANGE deleted_at deleted_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\'');
        $this->addSql('ALTER TABLE carrier CHANGE deleted_at deleted_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\'');
        $this->addSql('ALTER TABLE client CHANGE deleted_at deleted_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\'');
        $this->addSql('ALTER TABLE feed CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\'');
        $this->addSql('ALTER TABLE publisher CHANGE deleted_at deleted_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE created_at created_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\'');
        $this->addSql('ALTER TABLE user CHANGE deleted_at deleted_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\'');
        $this->addSql('ALTER TABLE user_salesforce CHANGE created_at created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', CHANGE updated_at updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\'');
    }
}
