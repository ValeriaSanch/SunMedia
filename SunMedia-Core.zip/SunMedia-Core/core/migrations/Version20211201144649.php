<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211201144649 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'delete index api platform price';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('DROP INDEX index_country_idx ON api_platform_price');
        $this->addSql('DROP INDEX index_currency_idx ON api_platform_price');
        $this->addSql('DROP INDEX index_device_idx ON api_platform_price');
        $this->addSql('DROP INDEX index_date_idx ON api_platform_price');
        $this->addSql('DROP INDEX index_domain_idx ON api_platform_price');
        $this->addSql('DROP INDEX index_format_id_idx ON api_platform_price');
        $this->addSql('DROP INDEX index_page_id_idx ON api_platform_price');
        $this->addSql('DROP INDEX index_sdk_idx ON api_platform_price');
        $this->addSql('DROP INDEX index_site_id_idx ON api_platform_price');
        $this->addSql('DROP INDEX index_type_idx ON api_platform_price');

        $this->addSql('ALTER TABLE api_platform_price 
            ADD INDEX api_platform_price_date_index (date_value), 
            ADD INDEX api_platform_price_type_index (type_value), 
            ADD INDEX api_platform_price_device_index (device_value), 
            ADD INDEX api_platform_price_country_index (country_value)');
    }

    public function down(Schema $schema): void
    {
    }
}
