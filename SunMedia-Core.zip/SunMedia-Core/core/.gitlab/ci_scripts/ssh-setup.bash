#!/usr/bin/env bash
declare ssh_key=$1
declare server_domain=$2
declare server_host=$3

echo ${server_host} ${server_domain} >> /etc/hosts
mkdir -p ~/.ssh
cat ${ssh_key} >> ~/.ssh/id_rsa
chmod 600 ~/.ssh/id_rsa
ssh-keyscan -t rsa ${server_domain} >> ~/.ssh/known_hosts
