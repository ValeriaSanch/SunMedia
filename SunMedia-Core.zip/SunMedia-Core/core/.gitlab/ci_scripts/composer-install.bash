#!/usr/bin/env bash

composer global require hirak/prestissimo
composer install --no-interaction --no-scripts --no-progress --prefer-dist