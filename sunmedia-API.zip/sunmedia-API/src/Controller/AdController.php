<?php

namespace App\Controller;

use App\Entity\Ad;

use App\Entity\Component;
use Doctrine\Persistence\ManagerRegistry;
use Exception;
use http\Exception\RuntimeException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;


class AdController extends AbstractController
{

    public function post_ad(Request $request, ManagerRegistry $doctrine):Response
    {
        $ad = new Ad();
        $parameter = json_decode($request->getContent(), true);

        $ad->setName($parameter['name']);
        $ad->setCategory($parameter['category']);
        $ad->setStatus($parameter['status']);

        $em = $doctrine->getManager();
        $em->persist($ad);
        $em->flush();

        return $this->json('Ad inserted successfully');

    }
    public function update_ad(Request $request, ManagerRegistry $doctrine, $id): Response
    {

        $ad = $doctrine->getRepository(Ad::class)->find($id);
        $parameter = json_decode($request->getContent(), true);
        if ($ad->getStatus() === "publishing"){
            throw new Exception("The Ad can't update in this status");
        }
        $ad->setName($parameter['name']);
        $ad->setCategory($parameter['category']);
        $ad->setStatus($parameter['status']);

        $em = $doctrine->getManager();
        $em->persist($ad);
        $em->flush();

        return $this->json('Ad updated successfully');
    }

    public function delete_ad(ManagerRegistry  $doctrine, $id):Response{
        $ad = $doctrine->getRepository(Ad::class)->find($id);

        $em = $doctrine->getManager();
        $em->persist($ad);
        $em->flush();

        return $this->json('Ad deleted successfully');
    }
    public function fetch_all_ad(ManagerRegistry $doctrine): Response
    {
        $ad = $doctrine->getRepository(Ad::class)->findAll();
        foreach ($ad as $d){
            $res[] = [
                'id' => $d->getId(),
                'name'=> $d->getName(),
                'category'=>$d->getCategory(),
                'status' => $d->getStatus()
            ];
        }
        return $this->json($res);
    }

}