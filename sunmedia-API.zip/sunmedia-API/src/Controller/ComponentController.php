<?php

namespace App\Controller;

use App\Entity\Ad;
use App\Entity\Component;
use App\Repository\AdRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use function Symfony\Component\DependencyInjection\Loader\Configurator\param;


class ComponentController extends AbstractController
{

    public function post_comp(Request $request, ManagerRegistry $doctrine): Response
    {
        $comp = new Component();
        $parameter = json_decode($request->getContent(), true);

        $comp->setName($parameter['name']);
        $comp->setPosition($parameter['position']);
        $comp->setWidth($parameter['width']);
        $comp->setHeight($parameter['height']);
        $comp->setUrlAttribute($parameter['url']);
        $comp->setFormatAttribute($parameter['type'], $parameter['format']);
        $comp->setWeightAttribute($parameter['weight'], $parameter['storage']);
        $comp->setTextAttribute($parameter['text']);

        $em = $doctrine->getManager();
        $em->persist($comp);
        $em->flush();

        return $this->json('Component inserted successfully');
    }
    public function update_comp(Request $request, ManagerRegistry $doctrine, $id): Response
    {

        $comp = $doctrine->getRepository(Component::class)->find($id);
        $parameter = json_decode($request->getContent(), true);

        $comp->setName($parameter['name']);
        $comp->setPosition($parameter['position']);
        $comp->setWidth($parameter['width']);
        $comp->setHeight($parameter['height']);
        $comp->setUrlAttribute($parameter['url']);
        $comp->setFormatAttribute($parameter['type'], $parameter['format']);
        $comp->setWeightAttribute($parameter['weight'], $parameter['storage']);
        $comp->setTextAttribute($parameter['text']);

        $em = $doctrine->getManager();
        $em->persist($comp);
        $em->flush();

        return $this->json('Component updated successfully');

    }
    public function delete_comp(ManagerRegistry $doctrine, $id): Response
    {
        $comp = $doctrine->getRepository(Component::class)->find($id);

        $em = $doctrine->getManager();
        $em->remove($comp);
        $em->flush();

        return $this->json('Component deleted successfully');

    }
    public function fetch_all_comp(ManagerRegistry $doctrine): Response
    {
        $comp = $doctrine->getRepository(Component::class)->findAll();
        foreach ($comp as $d){
            $res[] = [
                'id' => $d->getId(),
                'ad_id' => $d->getAd(),
                'name'=> $d->getName(),
                'position'=> $d->getPosition(),
                'width' => $d->getWidth(),
                'height' => $d->getHeight(),
                'attributes' => $d->getAttributes()
            ];
        }
        return $this->json($res);
    }

    /**
     * @param Request $request
     * @param Component $comp
     * @param ManagerRegistry $doctrine
     * @return void
     */

}