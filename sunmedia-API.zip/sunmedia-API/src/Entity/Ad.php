<?php

namespace App\Entity;

use App\Repository\AdRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use http\Exception\RuntimeException;
use phpDocumentor\Reflection\Types\Nullable;


/**
 * @ORM\Entity(repositoryClass=AdRepository::class)
 */
class Ad
{
    public const STATUS_PUBLISHED = 'published';
    public const STATUS_STOPPED = 'stopped';
    public const STATUS_PUBLISHING = 'publishing'; // estas constantes son utilizadas para mantener estos 3 estatus que maneja el problema.

    private static array $statusValid = [self::STATUS_PUBLISHED, self::STATUS_STOPPED, self::STATUS_PUBLISHING];

    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $name;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $category;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $status;


    /**
     * @ORM\OneToMany(targetEntity= "App\Entity\Component", mappedBy = "ad")
     */
    private $component;


    public function __construct()
    {
        $this->component = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getCategory(): ?string
    {
        return $this->category;
    }

    public function setCategory(string $category): self
    {
        $this->category = $category;

        return $this;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function setStatus(string $status): self
    {
        if (!in_array($status, self::$statusValid, true)){

            throw new RuntimeException( sprintf("The '%s' status is not valid, the status valid are
            ('%s')", $status, implode(', ', self::$statusValid)));

        }

        $this->status = $status;

        return $this;
    }

    /**
     * @return Collection|Component[]
     */
    public function getComponent(): Collection
    {
        return $this->component;
    }
    public function addComponent(Component $component): self
    {
        if (!$this->component->contains($component)){
            $this->component[] = $component;
        }
        return $this;
    }
    public function removeComponent(Component $component): self
    {
        if ($this->component->contains($component)){
            $this->component->removeElement($component);

            if($component->getAd()===$this){
                $component->setAd($this->id);
            }
        }
        return $this;
    }


}
