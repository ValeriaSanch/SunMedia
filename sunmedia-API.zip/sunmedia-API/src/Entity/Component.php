<?php

namespace App\Entity;

use App\Repository\ComponentRepository;
use Doctrine\ORM\Mapping as ORM;
use http\Exception\RuntimeException;

/**
 * @ORM\Entity(repositoryClass=ComponentRepository::class)
 */
class Component
{

    public const VIDEO_MP4 = 'mp4';
    public const VIDEO_WEBM = 'webm';
    public static array $formatVideo = [self::VIDEO_MP4, self::VIDEO_WEBM];

    public const IMAGE_PNG = 'png';
    public const IMAGE_JPG = 'jpg';

    private static array $formatImage = [self::IMAGE_JPG, self::IMAGE_PNG];


    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $name;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $position;

    /**
     * @ORM\Column(type="float")
     */
    private $width;

    /**
     * @ORM\Column(type="float")
     */
    private $height;

    /**
     * @ORM\Column(type="array")
     */
    private $attributes = [];


    /** @ORM\ManyToOne(targetEntity="App\Entity\Ad", inversedBy="component")
     * @ORM\JoinColumn(nullable=false)
     */
    private $ad;

    public function getId(): ?int
    {
        return $this->id;
    }
    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }
    public function getAd(): ?Ad
    {
        return $this->ad;
    }
    public function setAd(?Ad $ad): self
    {
        $this->ad = $ad;
        return $this;
    }
    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getPosition(): ?string
    {
        return $this->position;
    }

    public function setPosition(string $position): self
    {
        $this->position = $position;

        return $this;
    }

    public function getWidth(): ?float
    {
        return $this->width;
    }

    public function setWidth(float $width): self
    {
        $this->width = $width;

        return $this;
    }

    public function getHeight(): ?float
    {
        return $this->height;
    }

    public function setHeight(float $height): self
    {
        $this->height = $height;

        return $this;
    }

    public function getAttributes(): ?array
    {
        return $this->attributes;
    }

    public function setAttributes(array $attributes): self
    {
        $this->attributes = $attributes;

        return $this;
    }
    public function setUrlAttribute(String $url): self
    {
        $this->attributes['url'] = $url;
        return $this;
    }

    public function setFormatAttribute(string $type, string $format): self
    {
        if (!in_array($format, self::$formatImage, true) && $type === 'image')
        {
            throw new RuntimeException(sprintf("The '%s' format is not valid, the format valid are ('%s')", $format, implode("', '", self::$formatImage)));
        }
        if (!in_array($format, self::$formatVideo, true) && $type === 'video'){
            throw new RuntimeException(sprintf("The '%s' format is not valid, the format valid are ('%s')", $format, implode("', '", self::$formatVideo)));
        }
        $this->attributes['format'] ="Type {$type} and format {$format}";
        return $this;
    }
    public function setWeightAttribute(float $weight, string $storage):self
    {
        $this->attributes['weight'] = "Weight {$weight} and Storage {$storage}";
        return $this;
    }

    public function setTextAttribute(String $text):self
    {
        $this->attributes['text'] = $text;
        return $this;
    }

}
